# Android 正式签名

正式签名密钥与经 Windows 当前账户保护的密码保存在：

```text
%LOCALAPPDATA%\DouyinMaterialSaver\signing
```

该目录不在 Git 仓库内，密钥和密码不会上传到 GitHub。

## 首次设置

在 `android` 目录运行：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\release-signing.ps1 setup
```

输入并确认至少 12 位密码后，脚本会生成项目专用密钥。建议使用 16 位以上、
由大小写字母、数字和常见符号组成的独立密码，避免中文与空格。

请将 `.jks` 密钥文件和密码分别备份到安全位置。丢失任意一项后，都无法继续
更新已经安装的正式版；不要把密钥、密码或密码文件提交到 GitHub。

## 构建正式 APK

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\release-signing.ps1 build
```

输出文件：

```text
app/build/outputs/apk/release/app-release.apk
```

脚本只在当前构建进程中解密密码并设置 Gradle 环境变量，完成后立即清除这些
环境变量。Gradle 仓库配置中不包含任何签名秘密。
