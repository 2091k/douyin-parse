# 抖音素材保存 Android 应用

当前版本：`1.1.1`（`versionCode 13`）

`1.1.1` 是公开开源准备版本：应用包名、正式签名和用户功能保持兼容；项目补充 GPL-3.0-only 许可证、隐私与安全政策、贡献规范、Gradle Wrapper 和 GitHub Actions，并将内部界面代码改为中性命名。

`1.1.0` 将解析 WebView 改为默认后台运行：成功后直接显示下载预览，只有抖音确实要求验证码或登录时才显示“完成验证”入口，验证完成后自动继续解析。验证页面会自动静音并暂停媒体。下载预览内容与固定保存栏现在属于同一块连续 Sheet，关闭时 Sheet、遮罩和系统背景模糊使用同一动画进度。深色模式、加载状态反馈和预览边缘衔接也同步优化。

手机端主流程为：在抖音点“分享 → 分享链接”复制作品链接，打开本应用后点“粘贴并解析”。应用只在用户点击按钮时读取一次剪贴板，不会后台监听；同时保留手动输入和系统文本分享入口作兼容。随后应用在后台 WebView 中打开作品页。解析器优先复用详情接口；图文接口被平台过滤时，会从当前页面的 `__pace_f`、内联 `self.__pace_f.push(...)`、`RENDER_DATA` 等数据读取与 URL 中作品 ID 完全一致的媒体对象。内联脚本只截取并解析 `push(...)` 的 JSON 参数，不通过 `eval` 执行。签名 URL 只在内存中的一次性任务里存在。

解析完成后，应用先显示原生下载预览，列出标题、作者、类型、项目数、预计文件数、远端文件大小和缩略图。图集可按原始项目序号逐项选择；只有用户点击“保存所选”后，过滤后的一次性任务才会交给前台下载服务。取消预览会立即丢弃任务。

下载结果通过 MediaStore 保存到 `DCIM/抖音素材`。应用日志不会输出签名查询参数、Cookie 或请求头，也不会把完整作品 JSON 写入磁盘。

## 本机构建

需要 JDK 17 和 Android SDK 36。仓库已包含 Gradle Wrapper，无需另外安装 Gradle。

Windows PowerShell：

```powershell
.\gradlew.bat --no-daemon :app:assembleDebug
```

macOS 或 Linux：

```bash
./gradlew --no-daemon :app:assembleDebug
```

APK 输出：`app/build/outputs/apk/debug/app-debug.apk`

## 验证

```powershell
.\gradlew.bat --no-daemon `
  :app:testDebugUnitTest :app:assembleDebug :app:lintDebug
```

当前共 19 项单元测试：`MediaSelectorTest` 覆盖旧版字段、新版网页驼峰字段、图集下载回退、实况伴随视频、`playAddr: [{src: ...}]`、视频质量排序及水印候选过滤；`DownloadPreviewTest` 还覆盖视频封面、普通图集、实况文件计数、水印候选排除、可读大小格式和按确认序号过滤图集任务。

`0.8.0-clipboard-paste` 已在 Android 16 真机完成实际抖音流程回归：抖音作品页点“分享链接”后，应用的“粘贴并解析”能读取剪贴板、填入分享文本并成功进入下载预览。

`0.5-short-link-live-fix` 已在 Android 16 真机上通过原始 `v.douyin.com` 短链冷启动回归：页面跳转到 `/note/{aweme_id}` 后成功保存 1 张 `_still.jpg` 和对应的 1 个 `_motion.mp4`，系统媒体库可正常读取两者的 MIME、尺寸和视频时长。

`0.6-download-preview` 已在同一 Android 16 真机上验证：预览页能显示真实缩略图和“实况图 · 1 项 · 2 个文件”；确认前 MediaStore 文件数不变，确认后成功保存两项媒体，再次解析并取消后文件数仍保持不变。

`0.7-selective-preview` 已使用三图作品完成真机回归：远端大小显示与最终文件字节数一致；取消第 1、3 张并只保存第 2 张后，MediaStore 只出现 `itemIndex_1`，没有下载未选项目。

`0.7.1-detail-format` 已分别用普通视频、三图作品和实况作品完成真机显示回归：详情现在为 `视频_1920×1080_9.3MB`、`静态图_1320×1750_275.5KB`，实况则分为独立的静态图与动态视频两行。

`0.7.2-video-duration` 已完成普通视频与实况真机回归：普通视频显示为 `视频_1920×1080_00:17_9.3MB`，实况动态部分显示为 `动态视频_720×960_00:02_719.0KB`。
