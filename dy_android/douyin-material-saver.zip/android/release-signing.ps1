param(
    [ValidateSet("setup", "build")]
    [string]$Action = "build",
    [string]$JavaHomePath,
    [string]$AndroidSdkPath,
    [string]$GradlePath
)

$ErrorActionPreference = "Stop"
$signingRoot = Join-Path $env:LOCALAPPDATA "DouyinMaterialSaver\signing"
$keystorePath = Join-Path $signingRoot "douyin-material-saver-release.jks"
$protectedPasswordPath = Join-Path $signingRoot "release-password.dpapi"
$toolConfigPath = Join-Path $signingRoot "tool-paths.json"
$keyAlias = "douyin-material-saver"

function Resolve-ToolPath {
    param(
        [string[]]$CandidatePaths,
        [string]$RequiredChild,
        [string]$ParameterHint
    )

    foreach ($candidatePath in $CandidatePaths) {
        if (-not [string]::IsNullOrWhiteSpace($candidatePath) -and
            (Test-Path -LiteralPath (Join-Path $candidatePath $RequiredChild))) {
            return (Resolve-Path -LiteralPath $candidatePath).Path
        }
    }
    throw "Cannot find $RequiredChild. Provide $ParameterHint."
}

function Convert-SecureStringToPlainText {
    param([Security.SecureString]$SecureValue)

    $valuePointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureValue)
    try {
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($valuePointer)
    } finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($valuePointer)
    }
}

function Protect-Password {
    param([string]$PlainTextPassword)

    $securePassword = ConvertTo-SecureString $PlainTextPassword -AsPlainText -Force
    $protectedText = $securePassword | ConvertFrom-SecureString
    [IO.File]::WriteAllText(
        $protectedPasswordPath,
        $protectedText,
        [Text.UTF8Encoding]::new($false)
    )
}

function Unprotect-Password {
    $protectedText = [IO.File]::ReadAllText($protectedPasswordPath, [Text.Encoding]::UTF8)
    $securePassword = $protectedText | ConvertTo-SecureString
    return Convert-SecureStringToPlainText $securePassword
}

function Set-PrivateAcl {
    $accountName = [Security.Principal.WindowsIdentity]::GetCurrent().Name
    & icacls.exe $signingRoot /inheritance:r /grant:r "${accountName}:(OI)(CI)F" | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "Could not restrict the signing directory permissions."
    }
}

$savedToolConfig = $null
if (Test-Path -LiteralPath $toolConfigPath) {
    $savedToolConfig = Get-Content -LiteralPath $toolConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
}

$resolvedJavaHome = Resolve-ToolPath `
    @($JavaHomePath, $env:JAVA_HOME, $savedToolConfig.javaHome) `
    "bin\java.exe" `
    "-JavaHomePath"
$resolvedAndroidSdk = Resolve-ToolPath `
    @($AndroidSdkPath, $env:ANDROID_HOME, $env:ANDROID_SDK_ROOT, $savedToolConfig.androidSdk) `
    "build-tools" `
    "-AndroidSdkPath"
$resolvedGradleHome = Resolve-ToolPath `
    @($GradlePath, $savedToolConfig.gradleHome) `
    "bin\gradle.bat" `
    "-GradlePath"
$keytoolPath = Join-Path $resolvedJavaHome "bin\keytool.exe"
$gradleExecutable = Join-Path $resolvedGradleHome "bin\gradle.bat"

if ($Action -eq "setup") {
    $keystoreExists = Test-Path -LiteralPath $keystorePath
    $protectedPasswordExists = Test-Path -LiteralPath $protectedPasswordPath
    if ($keystoreExists -and $protectedPasswordExists) {
        throw "Release signing is already configured. The keystore will not be overwritten."
    }
    if (-not $keystoreExists -and $protectedPasswordExists) {
        throw "The protected password exists but the keystore is missing. Manual recovery is required."
    }

    New-Item -ItemType Directory -Path $signingRoot -Force | Out-Null
    $firstPassword = Read-Host "Enter a release signing password of at least 12 characters" -AsSecureString
    $secondPassword = Read-Host "Enter the same password again" -AsSecureString
    $firstPlainText = Convert-SecureStringToPlainText $firstPassword
    $secondPlainText = Convert-SecureStringToPlainText $secondPassword

    try {
        if ($firstPlainText.Length -lt 12) {
            throw "The password is shorter than 12 characters. No key was created."
        }
        if ($firstPlainText -cne $secondPlainText) {
            throw "The two passwords do not match. No key was created."
        }

        $env:DOUYIN_KEYSTORE_PASSWORD = $firstPlainText
        if ($keystoreExists) {
            & $keytoolPath -list `
                -keystore $keystorePath `
                -storepass:env DOUYIN_KEYSTORE_PASSWORD `
                -alias $keyAlias | Out-Null
            if ($LASTEXITCODE -ne 0) {
                throw "The password does not unlock the existing keystore. No settings were changed."
            }
        } else {
            & $keytoolPath -genkeypair -v `
                -keystore $keystorePath `
                -storetype JKS `
                -storepass:env DOUYIN_KEYSTORE_PASSWORD `
                -keypass:env DOUYIN_KEYSTORE_PASSWORD `
                -alias $keyAlias `
                -keyalg RSA `
                -keysize 4096 `
                -sigalg SHA256withRSA `
                -validity 10000 `
                -dname "CN=LeoChen, OU=DouyinMaterialSaver, O=LeoChen-Tech, C=CN"
            if ($LASTEXITCODE -ne 0) {
                throw "keytool failed to create the release signing key."
            }
        }

        Protect-Password $firstPlainText
        $toolConfig = [ordered]@{
            javaHome = $resolvedJavaHome
            androidSdk = $resolvedAndroidSdk
            gradleHome = $resolvedGradleHome
        } | ConvertTo-Json
        [IO.File]::WriteAllText($toolConfigPath, $toolConfig, [Text.UTF8Encoding]::new($false))
        Set-PrivateAcl
        if ($keystoreExists) {
            Write-Host "SIGNING_RECOVERY_COMPLETE"
        } else {
            Write-Host "SIGNING_SETUP_COMPLETE"
        }
        Write-Host "Keystore: $keystorePath"
        Write-Host "Back up the keystore and the password separately."
    } finally {
        Remove-Item Env:DOUYIN_KEYSTORE_PASSWORD -ErrorAction SilentlyContinue
        $firstPlainText = $null
        $secondPlainText = $null
    }
    return
}

if (-not (Test-Path -LiteralPath $keystorePath) -or
    -not (Test-Path -LiteralPath $protectedPasswordPath)) {
    throw "Release signing is not configured. Run release-signing.ps1 setup first."
}

$releasePassword = Unprotect-Password
try {
    $env:JAVA_HOME = $resolvedJavaHome
    $env:ANDROID_HOME = $resolvedAndroidSdk
    $env:ANDROID_SDK_ROOT = $resolvedAndroidSdk
    $env:DOUYIN_RELEASE_STORE_FILE = $keystorePath
    $env:DOUYIN_RELEASE_STORE_PASSWORD = $releasePassword
    $env:DOUYIN_RELEASE_KEY_ALIAS = $keyAlias
    $env:DOUYIN_RELEASE_KEY_PASSWORD = $releasePassword

    Push-Location $PSScriptRoot
    try {
        & $gradleExecutable :app:assembleRelease --no-daemon
        if ($LASTEXITCODE -ne 0) {
            throw "The signed release APK build failed."
        }
    } finally {
        Pop-Location
    }
} finally {
    Remove-Item Env:DOUYIN_RELEASE_STORE_FILE -ErrorAction SilentlyContinue
    Remove-Item Env:DOUYIN_RELEASE_STORE_PASSWORD -ErrorAction SilentlyContinue
    Remove-Item Env:DOUYIN_RELEASE_KEY_ALIAS -ErrorAction SilentlyContinue
    Remove-Item Env:DOUYIN_RELEASE_KEY_PASSWORD -ErrorAction SilentlyContinue
    $releasePassword = $null
}

Write-Host "SIGNED_RELEASE_BUILD_COMPLETE"
