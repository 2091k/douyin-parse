package com.local.douyinmaterials;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

import java.util.TimeZone;

public class MediaSelectorTest {
    @Test
    public void metadataIsNormalizedAndInvalidDateUsesProvidedClock() throws Exception {
        TimeZone original = TimeZone.getDefault();
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        try {
            JSONObject detail = new JSONObject()
                    .put("aweme_id", 123456789L)
                    .put("desc", "  ")
                    .put("create_time", "invalid")
                    .put("video", new JSONObject().put(
                            "play_addr_h264",
                            address("https://cdn.example/video.mp4", null)));

            MediaSelector.WorkPlan plan = MediaSelector.select(detail, 0L);

            assertEquals("123456789", plan.awemeId);
            assertEquals("no_title", plan.title);
            assertEquals("unknown", plan.author);
            assertEquals(0L, plan.createTimeEpochSeconds);
            assertEquals("1970-01-01", plan.publishDate);
        } finally {
            TimeZone.setDefault(original);
        }
    }

    @Test
    public void highestVideoUsesResolutionBeforeBitrateAndFiltersFakeAddresses() throws Exception {
        JSONObject fake = qualityEntry(9_000_000, 3840, 2160, null, null);
        JSONObject highBitrate1080 = qualityEntry(
                8_000_000,
                1080,
                1920,
                "https://cdn.example/1080.mp4",
                null);
        JSONObject lowerBitrate1440 = qualityEntry(
                3_000_000,
                1440,
                2560,
                "https://cdn.example/1440.mp4",
                "1440-uri");

        JSONObject detail = baseDetail("video-1")
                .put("aweme_type", 4)
                .put("video", new JSONObject().put(
                        "bit_rate",
                        new JSONArray()
                                .put(fake)
                                .put(highBitrate1080)
                                .put(lowerBitrate1440)));

        MediaSelector.WorkPlan plan = MediaSelector.select(detail, 1_700_000_000_000L);

        assertEquals(MediaSelector.MediaType.VIDEO, plan.mediaType);
        assertEquals(2, plan.videoCandidates.size());
        assertEquals("https://cdn.example/1440.mp4", plan.videoCandidates.get(0).urls.get(0));
        assertEquals(1440, plan.videoCandidates.get(0).shortEdge);
        assertEquals("1440-uri", plan.videoCandidates.get(0).uri);
        assertEquals("https://cdn.example/1080.mp4", plan.videoCandidates.get(1).urls.get(0));
    }

    @Test
    public void dimensionsMissingFallsBackToBitrateAndGlobalVidSuppliesUri() throws Exception {
        JSONObject detail = baseDetail("video-2")
                .put("video", new JSONObject()
                        .put("vid", "global-clean-id")
                        .put("bit_rate", new JSONArray()
                                .put(qualityEntry(
                                        500_000, 0, 0, "https://cdn.example/low.mp4", null))
                                .put(qualityEntry(
                                        1_500_000, 0, 0, "https://cdn.example/high.mp4", null))));

        MediaSelector.WorkPlan plan = MediaSelector.select(detail);

        assertEquals("https://cdn.example/high.mp4", plan.videoCandidates.get(0).urls.get(0));
        assertEquals("global-clean-id", plan.videoCandidates.get(0).uri);
    }

    @Test
    public void galleryBeatsTopLevelVideoAndPreservesOriginalItemIndexes() throws Exception {
        JSONObject first = new JSONObject()
                .put("video", new JSONObject().put(
                        "dynamic_cover",
                        new JSONObject().put(
                                "url_list",
                                new JSONArray().put("https://cdn.example/not-live.mp4"))));
        JSONObject second = new JSONObject().put(
                "display_image",
                imageSource("https://cdn.example/real.webp", 1080, 1920));
        JSONObject detail = baseDetail("gallery-1")
                .put("aweme_type", 68)
                .put("video", new JSONObject().put(
                        "play_addr",
                        address("https://cdn.example/audio-ish.mp4", null)))
                .put("image_post_info", new JSONObject().put(
                        "images", new JSONArray().put(first).put(second)));

        MediaSelector.WorkPlan plan = MediaSelector.select(detail);

        assertEquals(MediaSelector.MediaType.GALLERY, plan.mediaType);
        assertEquals("image_post_info.images", plan.gallerySourcePath);
        assertTrue(plan.videoCandidates.isEmpty());
        assertEquals(2, plan.galleryItems.size());
        assertEquals(0, plan.galleryItems.get(0).itemIndex);
        assertTrue(plan.galleryItems.get(0).imageCandidates.isEmpty());
        assertTrue(plan.galleryItems.get(0).liveCandidates.isEmpty());
        assertEquals(1, plan.galleryItems.get(1).itemIndex);
        assertEquals("https://cdn.example/real.webp",
                plan.galleryItems.get(1).imageCandidates.get(0).url);
    }

    @Test
    public void imageCandidatesPreferCleanResolutionThenSourceAndNonWebp() throws Exception {
        JSONObject item = new JSONObject()
                .put("watermark_free_download_url_list", new JSONArray()
                        .put("https://cdn.example/clean-free-720.jpg"))
                .put("width", 720)
                .put("height", 1280)
                .put("origin_image", imageSource(
                        "https://cdn.example/origin-1440.jpg", 1440, 2560))
                .put("display_image", imageSource(
                        "https://cdn.example/display-1080.jpg", 1080, 1920))
                .put("download_url_list", new JSONArray()
                        .put("https://cdn.example/fallback.webp")
                        .put("https://cdn.example/fallback.jpeg"))
                .put("owner_watermark_image", imageSource(
                        "https://cdn.example/owner_watermark_image-2160.jpg", 2160, 3840));
        JSONObject detail = baseDetail("gallery-2").put(
                "images", new JSONArray().put(item));

        ListView images = new ListView(MediaSelector.select(detail)
                .galleryItems.get(0).imageCandidates);

        assertEquals("https://cdn.example/origin-1440.jpg", images.url(0));
        assertEquals("https://cdn.example/display-1080.jpg", images.url(1));
        assertEquals("https://cdn.example/clean-free-720.jpg", images.url(2));
        // Clean download_url_list is a valid fallback even when it has no size metadata.
        assertEquals("https://cdn.example/fallback.jpeg", images.url(3));
        assertEquals("https://cdn.example/fallback.webp", images.url(4));
        assertEquals("https://cdn.example/owner_watermark_image-2160.jpg", images.url(5));
        assertFalse(images.candidate(0).watermarked);
        assertFalse(images.candidate(4).watermarked);
        assertTrue(images.candidate(5).watermarked);
    }

    @Test
    public void galleryAcceptsStringAndObjectDownloadFallbacks() throws Exception {
        JSONObject first = new JSONObject()
                .put("download_url", "https://cdn.example/direct.jpg");
        JSONObject second = new JSONObject()
                .put("download_url_list", new JSONArray().put(
                        new JSONObject().put(
                                "url_list",
                                new JSONArray().put("https://cdn.example/nested.webp"))));
        JSONObject detail = baseDetail("gallery-download-fallbacks")
                .put("aweme_type", 68)
                .put("image_list", new JSONArray().put(first).put(second));

        MediaSelector.WorkPlan plan = MediaSelector.select(detail);

        assertTrue(plan.isGallery());
        assertEquals("https://cdn.example/direct.jpg",
                plan.galleryItems.get(0).imageCandidates.get(0).url);
        assertEquals("https://cdn.example/nested.webp",
                plan.galleryItems.get(1).imageCandidates.get(0).url);
        assertFalse(plan.galleryItems.get(0).imageCandidates.get(0).watermarked);
    }

    @Test
    public void currentWebHydrationCamelCaseGalleryIsSupported() throws Exception {
        JSONObject item = new JSONObject()
                .put("width", 1080)
                .put("height", 1440)
                .put("urlList", new JSONArray().put("https://cdn.example/display.jpeg"))
                .put("downloadUrlList", new JSONArray().put("https://cdn.example/source.jpeg"))
                .put("video", new JSONObject().put(
                        "playAddr",
                        new JSONObject().put(
                                "urlList",
                                new JSONArray().put("https://cdn.example/live.mp4"))));
        JSONObject detail = new JSONObject()
                .put("awemeId", "camel-gallery")
                .put("awemeType", 68)
                .put("desc", "current hydration")
                .put("createTime", 1_700_000_000L)
                .put("authorInfo", new JSONObject().put("nickname", "author"))
                .put("images", new JSONArray().put(item));

        MediaSelector.WorkPlan plan = MediaSelector.select(detail);

        assertTrue(plan.isGallery());
        assertEquals("camel-gallery", plan.awemeId);
        assertEquals("author", plan.author);
        assertEquals("https://cdn.example/display.jpeg",
                plan.galleryItems.get(0).imageCandidates.get(0).url);
        assertEquals("https://cdn.example/source.jpeg",
                plan.galleryItems.get(0).imageCandidates.get(1).url);
        assertEquals("https://cdn.example/live.mp4",
                plan.galleryItems.get(0).liveCandidates.get(0).urls.get(0));
    }

    @Test
    public void livePhotoAcceptsCurrentPlayAddrArrayOfSrcObjects() throws Exception {
        JSONArray highQualityPlayAddr = new JSONArray()
                .put(new JSONObject().put("src", "https://cdn.example/live-source.mp4"))
                .put(new JSONObject().put("src", "https://cdn-mirror.example/live-source.mp4"));
        JSONObject liveVideo = new JSONObject()
                .put("width", 1440)
                .put("height", 1920)
                .put("playAddr", highQualityPlayAddr)
                .put("bitRateList", new JSONArray().put(
                        new JSONObject()
                                .put("bitRate", 4_000_000)
                                .put("width", 1440)
                                .put("height", 1920)
                                .put("playAddr", highQualityPlayAddr)));
        JSONObject item = new JSONObject()
                .put("width", 1440)
                .put("height", 1920)
                .put("urlList", new JSONArray().put("https://cdn.example/still.jpg"))
                .put("clipType", 5)
                .put("livePhotoType", 1)
                .put("video", liveVideo);
        JSONObject detail = new JSONObject()
                .put("awemeId", "current-live-photo")
                .put("awemeType", 68)
                .put("images", new JSONArray().put(item));

        MediaSelector.GalleryItemPlan selected = MediaSelector.select(detail)
                .galleryItems.get(0);

        assertEquals("https://cdn.example/live-source.mp4",
                selected.liveCandidates.get(0).urls.get(0));
        assertEquals(1440, selected.liveCandidates.get(0).shortEdge);
        assertEquals(2, selected.liveCandidates.get(0).urls.size());
    }

    @Test
    public void liveCandidatesPreferHighestQualityAndNeverUseCovers() throws Exception {
        JSONObject liveVideo = new JSONObject()
                .put("bit_rate", new JSONArray()
                        .put(qualityEntry(
                                3_000_000,
                                720,
                                1280,
                                "https://cdn.example/live-720.mp4",
                                null))
                        .put(qualityEntry(
                                2_000_000,
                                1080,
                                1920,
                                "https://cdn.example/live-1080.mp4",
                                null)))
                .put("dynamic_cover", address("https://cdn.example/dynamic-cover.mp4", null))
                .put("cover", address("https://cdn.example/cover.jpg", null));
        JSONObject item = new JSONObject()
                .put("display_image", imageSource("https://cdn.example/still.jpg", 1080, 1920))
                .put("video", liveVideo);
        JSONObject detail = baseDetail("gallery-3").put(
                "image_post_info",
                new JSONObject().put("images", new JSONArray().put(item)));

        MediaSelector.GalleryItemPlan galleryItem = MediaSelector.select(detail)
                .galleryItems.get(0);

        assertEquals("https://cdn.example/live-1080.mp4",
                galleryItem.liveCandidates.get(0).urls.get(0));
        for (MediaSelector.VideoCandidate candidate : galleryItem.liveCandidates) {
            for (String url : candidate.urls) {
                assertFalse(url.contains("cover"));
            }
        }
    }

    @Test
    public void noteWithoutGalleryAssetsFallsBackToH264Video() throws Exception {
        JSONObject detail = baseDetail("note-video")
                .put("aweme_type", 68)
                .put("video", new JSONObject().put(
                        "play_addr_h264",
                        address("https://cdn.example/note-h264.mp4", null)));

        MediaSelector.WorkPlan plan = MediaSelector.select(detail);

        assertEquals(MediaSelector.MediaType.VIDEO, plan.mediaType);
        assertEquals("https://cdn.example/note-h264.mp4",
                plan.videoCandidates.get(0).urls.get(0));
    }

    @Test
    public void imageResponseMimeOverridesTemplateUrlExtension() {
        assertEquals(
                ".png",
                MediaSelector.resolveImageExtension(
                        "https://cdn.example/photo.image?x=1",
                        "image/png; charset=binary"));
        assertEquals(
                "image/png",
                MediaSelector.resolveImageMimeType(
                        "https://cdn.example/photo.image?x=1",
                        "image/png; charset=binary"));
        assertEquals(
                ".jpeg",
                MediaSelector.resolveImageExtension(
                        "https://cdn.example/photo.jpeg~tplv-resize.image",
                        null));
    }

    @Test
    public void videoUrlOrderingKeepsCleanBeforeWatermarkedFallback() throws Exception {
        JSONObject detail = baseDetail("video-3").put(
                "video",
                new JSONObject().put(
                        "play_addr",
                        new JSONObject()
                                .put("uri", "clean-uri")
                                .put("url_list", new JSONArray()
                                        .put("https://cdn.example/playwm/a.mp4?watermark=1")
                                        .put("https://cdn.example/direct.mp4")
                                        .put("https://www.douyin.com/play?watermark=0"))));

        MediaSelector.VideoCandidate selected = MediaSelector.select(detail)
                .videoCandidates.get(0);

        assertEquals("https://www.douyin.com/play?watermark=0", selected.urls.get(0));
        assertEquals("https://cdn.example/direct.mp4", selected.urls.get(1));
        assertEquals("https://cdn.example/playwm/a.mp4?watermark=1", selected.urls.get(2));
        assertTrue(selected.hasCleanUrl());
        assertFalse(selected.isWatermarkedFallbackOnly());
    }

    private static JSONObject baseDetail(String awemeId) throws Exception {
        return new JSONObject()
                .put("aweme_id", awemeId)
                .put("desc", " test title ")
                .put("create_time", 1_700_000_000L)
                .put("author", new JSONObject().put("nickname", "test author"));
    }

    private static JSONObject qualityEntry(
            int bitrate,
            int width,
            int height,
            String url,
            String uri) throws Exception {
        JSONObject playAddress = new JSONObject()
                .put("width", width)
                .put("height", height);
        if (url != null) {
            playAddress.put("url_list", new JSONArray().put(url));
        }
        if (uri != null) {
            playAddress.put("uri", uri);
        }
        return new JSONObject()
                .put("bit_rate", bitrate)
                .put("play_addr", playAddress);
    }

    private static JSONObject address(String url, String uri) throws Exception {
        JSONObject address = new JSONObject();
        if (url != null) {
            address.put("url_list", new JSONArray().put(url));
        }
        if (uri != null) {
            address.put("uri", uri);
        }
        return address;
    }

    private static JSONObject imageSource(String url, int width, int height) throws Exception {
        return new JSONObject()
                .put("url_list", new JSONArray().put(url))
                .put("width", width)
                .put("height", height);
    }

    private static final class ListView {
        private final java.util.List<MediaSelector.ImageCandidate> values;

        ListView(java.util.List<MediaSelector.ImageCandidate> values) {
            this.values = values;
        }

        String url(int index) {
            return candidate(index).url;
        }

        MediaSelector.ImageCandidate candidate(int index) {
            return values.get(index);
        }
    }
}
