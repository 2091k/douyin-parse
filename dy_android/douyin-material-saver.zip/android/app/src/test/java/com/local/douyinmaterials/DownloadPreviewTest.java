package com.local.douyinmaterials;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

import java.util.Collections;

public class DownloadPreviewTest {
    @Test
    public void videoPreviewUsesCoverAndCountsOneDownload() throws Exception {
        JSONObject video = new JSONObject()
                .put("width", 1080)
                .put("height", 1920)
                .put("duration", 24_400)
                .put("play_addr", address("https://cdn.example/video.mp4"))
                .put("cover", image("https://cdn.example/cover.jpg", 720, 1280));
        DownloadPreview preview = DownloadPreview.from(MediaSelector.select(
                baseDetail("preview-video").put("video", video)));

        assertEquals("视频", preview.kindLabel);
        assertEquals(1, preview.assetCount);
        assertEquals(1, preview.items.size());
        assertEquals("https://cdn.example/cover.jpg",
                preview.items.get(0).previewImageUrl);
        assertEquals("1080×1920", preview.items.get(0).assets.get(0).dimensionText());
        assertEquals("00:24", DownloadPreview.formatDuration(
                preview.items.get(0).assets.get(0).durationMs));
    }

    @Test
    public void mixedGalleryPreviewCountsStillAndLiveFilesExactly() throws Exception {
        JSONObject still = new JSONObject().put(
                "display_image", image("https://cdn.example/still-1.jpg", 1080, 1440));
        JSONObject live = new JSONObject()
                .put("display_image", image("https://cdn.example/still-2.jpg", 1440, 1920))
                .put("video", new JSONObject()
                        .put("width", 720)
                        .put("height", 960)
                        .put("duration", 2_234)
                        .put("playAddr",
                                new JSONArray().put(new JSONObject().put(
                                        "src", "https://cdn.example/motion-2.mp4"))));
        DownloadPreview preview = DownloadPreview.from(MediaSelector.select(
                baseDetail("preview-gallery")
                        .put("aweme_type", 68)
                        .put("images", new JSONArray().put(still).put(live))));

        assertEquals("图集（含实况）", preview.kindLabel);
        assertEquals(2, preview.items.size());
        assertEquals(3, preview.assetCount);
        assertEquals(1, preview.liveItemCount);
        assertEquals(1, preview.items.get(0).assetCount);
        assertEquals(2, preview.items.get(1).assetCount);
        assertEquals(0, preview.items.get(0).galleryItemIndex);
        assertEquals(1, preview.items.get(1).galleryItemIndex);
        assertEquals("静态图", preview.items.get(1).assets.get(0).label);
        assertEquals("动态视频", preview.items.get(1).assets.get(1).label);
        assertEquals("1440×1920", preview.items.get(1).assets.get(0).dimensionText());
        assertEquals("720×960", preview.items.get(1).assets.get(1).dimensionText());
        assertEquals("00:02", DownloadPreview.formatDuration(
                preview.items.get(1).assets.get(1).durationMs));
    }

    @Test
    public void singleLivePhotoIsClearlyLabelledAsLive() throws Exception {
        JSONObject live = new JSONObject()
                .put("urlList", new JSONArray().put("https://cdn.example/still.jpg"))
                .put("width", 1440)
                .put("height", 1920)
                .put("video", new JSONObject().put(
                        "playAddr",
                        new JSONArray().put(new JSONObject().put(
                                "src", "https://cdn.example/motion.mp4"))));
        DownloadPreview preview = DownloadPreview.from(MediaSelector.select(
                baseDetail("preview-live")
                        .put("awemeType", 68)
                        .put("images", new JSONArray().put(live))));

        assertEquals("实况图", preview.kindLabel);
        assertEquals(2, preview.assetCount);
        assertEquals("实况 1", preview.items.get(0).label);
    }

    @Test
    public void watermarkedOnlyVideoIsNotOfferedForConfirmation() throws Exception {
        JSONObject detail = baseDetail("preview-watermark").put(
                "video",
                new JSONObject().put(
                        "play_addr",
                        address("https://cdn.example/playwm/video.mp4?watermark=1")));

        DownloadPreview preview = DownloadPreview.from(MediaSelector.select(detail));

        assertEquals(0, preview.assetCount);
        assertTrue(preview.items.isEmpty());
    }

    @Test
    public void peekingConfirmationJobDoesNotConsumeIt() throws Exception {
        String jobId = DownloadJobStore.enqueueDetail(baseDetail("preview-job").put(
                "video",
                new JSONObject().put(
                        "play_addr", address("https://cdn.example/video.mp4"))));
        try {
            assertNotNull(DownloadJobStore.peek(jobId));
            assertNotNull(DownloadJobStore.take(jobId));
            assertNull(DownloadJobStore.take(jobId));
        } finally {
            DownloadJobStore.discard(jobId);
        }
    }

    @Test
    public void galleryJobCanBeRestrictedToConfirmedItemIndexes() throws Exception {
        JSONObject first = new JSONObject().put(
                "display_image", image("https://cdn.example/first.jpg", 1080, 1440));
        JSONObject second = new JSONObject().put(
                "display_image", image("https://cdn.example/second.jpg", 1080, 1440));
        JSONObject third = new JSONObject().put(
                "display_image", image("https://cdn.example/third.jpg", 1080, 1440));
        String jobId = DownloadJobStore.enqueueDetail(baseDetail("selective-gallery")
                .put("aweme_type", 68)
                .put("images", new JSONArray().put(first).put(second).put(third)));
        try {
            assertEquals(1, DownloadJobStore.selectGalleryItems(
                    jobId, Collections.singleton(1)));
            MediaSelector.WorkPlan selected = DownloadJobStore.take(jobId);
            assertNotNull(selected);
            assertEquals(1, selected.galleryItems.size());
            assertEquals(1, selected.galleryItems.get(0).itemIndex);
            assertEquals("https://cdn.example/second.jpg",
                    selected.galleryItems.get(0).imageCandidates.get(0).url);
        } finally {
            DownloadJobStore.discard(jobId);
        }
    }

    @Test
    public void byteSizesUseReadableUnits() {
        assertEquals("0B", DownloadPreview.formatBytes(0L));
        assertEquals("1.0KB", DownloadPreview.formatBytes(1024L));
        assertEquals("1.5MB", DownloadPreview.formatBytes(1572864L));
        assertEquals("大小未知", DownloadPreview.formatBytes(-1L));
        assertEquals("时长未知", DownloadPreview.formatDuration(0L));
        assertEquals("00:02", DownloadPreview.formatDuration(2_234L));
        assertEquals("01:05", DownloadPreview.formatDuration(65_000L));
        assertEquals("1:02:03", DownloadPreview.formatDuration(3_723_000L));
    }

    private static JSONObject baseDetail(String awemeId) throws Exception {
        return new JSONObject()
                .put("aweme_id", awemeId)
                .put("desc", "preview title")
                .put("create_time", 1_700_000_000L)
                .put("author", new JSONObject().put("nickname", "preview author"));
    }

    private static JSONObject address(String url) throws Exception {
        return new JSONObject().put("url_list", new JSONArray().put(url));
    }

    private static JSONObject image(String url, int width, int height) throws Exception {
        return address(url).put("width", width).put("height", height);
    }
}
