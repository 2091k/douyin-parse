package com.local.douyinmaterials;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Ephemeral, process-local handoff from the WebView capture flow to the foreground service.
 * Signed media URLs live only inside the in-memory WorkPlan and are removed on first take.
 */
public final class DownloadJobStore {
    private static final int MAX_SEARCH_DEPTH = 16;
    private static final int MAX_PENDING_JOBS = 8;
    private static final long JOB_TTL_MS = 15L * 60L * 1000L;
    private static final Object LOCK = new Object();
    private static final LinkedHashMap<String, Entry> JOBS = new LinkedHashMap<>();

    private DownloadJobStore() {
    }

    /** Parses raw response/page JSON entirely in memory and returns an opaque one-use job id. */
    public static String enqueueJson(String rawJson) throws JSONException {
        return enqueueJson(rawJson, null);
    }

    /**
     * Parses raw response/page JSON and requires the selected detail to match the shared work.
     * This prevents a recommendation embedded in hydration data from being downloaded by mistake.
     */
    public static String enqueueJson(String rawJson, String expectedAwemeId) throws JSONException {
        if (rawJson == null || rawJson.trim().isEmpty()) {
            throw new JSONException("详情 JSON 为空");
        }
        Object root = new JSONTokener(rawJson).nextValue();
        JSONObject detail = findDetail(root, 0, expectedAwemeId);
        if (detail == null) {
            throw new JSONException(expectedAwemeId == null
                    ? "JSON 中未找到 aweme_detail"
                    : "JSON 中未找到当前作品 " + expectedAwemeId);
        }
        return enqueueDetail(detail);
    }

    /** Creates an immutable selection plan without persisting the supplied JSONObject. */
    public static String enqueueDetail(JSONObject awemeDetail) {
        MediaSelector.WorkPlan plan = MediaSelector.select(awemeDetail);
        String jobId = UUID.randomUUID().toString();
        synchronized (LOCK) {
            purgeExpiredLocked(System.currentTimeMillis());
            while (JOBS.size() >= MAX_PENDING_JOBS) {
                Iterator<String> keys = JOBS.keySet().iterator();
                if (!keys.hasNext()) {
                    break;
                }
                keys.next();
                keys.remove();
            }
            JOBS.put(jobId, new Entry(plan, System.currentTimeMillis() + JOB_TTL_MS));
        }
        return jobId;
    }

    public static void discard(String jobId) {
        if (jobId == null) {
            return;
        }
        synchronized (LOCK) {
            JOBS.remove(jobId);
        }
    }

    /** Returns the immutable plan for confirmation without consuming its one-use job id. */
    static MediaSelector.WorkPlan peek(String jobId) {
        if (jobId == null) {
            return null;
        }
        synchronized (LOCK) {
            long now = System.currentTimeMillis();
            purgeExpiredLocked(now);
            Entry entry = JOBS.get(jobId);
            return entry == null || entry.expiresAtEpochMs <= now ? null : entry.plan;
        }
    }

    /** Restricts a gallery job to the item indexes explicitly confirmed by the user. */
    static int selectGalleryItems(String jobId, Set<Integer> selectedItemIndexes) {
        if (jobId == null || selectedItemIndexes == null) {
            return 0;
        }
        synchronized (LOCK) {
            long now = System.currentTimeMillis();
            purgeExpiredLocked(now);
            Entry entry = JOBS.get(jobId);
            if (entry == null || entry.expiresAtEpochMs <= now || !entry.plan.isGallery()) {
                return 0;
            }
            List<MediaSelector.GalleryItemPlan> selected = new ArrayList<>();
            for (MediaSelector.GalleryItemPlan item : entry.plan.galleryItems) {
                if (selectedItemIndexes.contains(item.itemIndex)) {
                    selected.add(item);
                }
            }
            if (selected.isEmpty()) {
                return 0;
            }
            MediaSelector.WorkPlan plan = entry.plan;
            MediaSelector.WorkPlan filtered = new MediaSelector.WorkPlan(
                    plan.mediaType,
                    plan.awemeId,
                    plan.title,
                    plan.author,
                    plan.createTimeEpochSeconds,
                    plan.publishDate,
                    plan.videoCandidates,
                    plan.previewImageCandidates,
                    selected,
                    plan.gallerySourcePath);
            JOBS.put(jobId, new Entry(filtered, entry.expiresAtEpochMs));
            return selected.size();
        }
    }

    static MediaSelector.WorkPlan take(String jobId) {
        if (jobId == null) {
            return null;
        }
        synchronized (LOCK) {
            long now = System.currentTimeMillis();
            purgeExpiredLocked(now);
            Entry entry = JOBS.remove(jobId);
            return entry == null || entry.expiresAtEpochMs <= now ? null : entry.plan;
        }
    }

    private static JSONObject findDetail(Object value, int depth, String expectedAwemeId) {
        if (value == null || value == JSONObject.NULL || depth > MAX_SEARCH_DEPTH) {
            return null;
        }
        if (value instanceof JSONObject) {
            JSONObject object = (JSONObject) value;
            if (looksLikeDetail(object, expectedAwemeId)) {
                return object;
            }
            String[] priorityKeys = {"aweme_detail", "awemeDetail", "detail", "data"};
            for (String key : priorityKeys) {
                JSONObject found = findDetail(object.opt(key), depth + 1, expectedAwemeId);
                if (found != null) {
                    return found;
                }
            }
            Iterator<String> keys = object.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                Object child = object.opt(key);
                JSONObject found = findDetail(child, depth + 1, expectedAwemeId);
                if (found != null) {
                    return found;
                }
                if (child instanceof String && ("content".equals(key) || "json".equals(key))) {
                    found = parseNestedString((String) child, depth + 1, expectedAwemeId);
                    if (found != null) {
                        return found;
                    }
                }
            }
        } else if (value instanceof JSONArray) {
            JSONArray array = (JSONArray) value;
            for (int index = 0; index < array.length(); index++) {
                JSONObject found = findDetail(array.opt(index), depth + 1, expectedAwemeId);
                if (found != null) {
                    return found;
                }
            }
        }
        return null;
    }

    private static JSONObject parseNestedString(
            String value,
            int depth,
            String expectedAwemeId) {
        String trimmed = value == null ? "" : value.trim();
        if (trimmed.isEmpty() || (trimmed.charAt(0) != '{' && trimmed.charAt(0) != '[')) {
            return null;
        }
        try {
            return findDetail(new JSONTokener(trimmed).nextValue(), depth, expectedAwemeId);
        } catch (JSONException ignored) {
            return null;
        }
    }

    private static boolean looksLikeDetail(JSONObject object, String expectedAwemeId) {
        Object awemeId = object.opt("aweme_id");
        if (awemeId == null || awemeId == JSONObject.NULL) {
            awemeId = object.opt("awemeId");
        }
        if (awemeId == null || awemeId == JSONObject.NULL
                || String.valueOf(awemeId).trim().isEmpty()) {
            return false;
        }
        if (expectedAwemeId != null
                && !expectedAwemeId.equals(String.valueOf(awemeId).trim())) {
            return false;
        }
        return object.has("video")
                || object.has("images")
                || object.has("image_list")
                || object.has("imageList")
                || object.has("image_post_info")
                || object.has("imagePostInfo")
                || object.has("aweme_type")
                || object.has("awemeType");
    }

    private static void purgeExpiredLocked(long now) {
        Iterator<Map.Entry<String, Entry>> entries = JOBS.entrySet().iterator();
        while (entries.hasNext()) {
            if (entries.next().getValue().expiresAtEpochMs <= now) {
                entries.remove();
            }
        }
    }

    private static final class Entry {
        final MediaSelector.WorkPlan plan;
        final long expiresAtEpochMs;

        Entry(MediaSelector.WorkPlan plan, long expiresAtEpochMs) {
            this.plan = plan;
            this.expiresAtEpochMs = expiresAtEpochMs;
        }
    }
}
