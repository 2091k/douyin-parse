package com.local.douyinmaterials;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URI;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Converts one unwrapped Douyin {@code aweme_detail} object into a deterministic media plan.
 *
 * <p>The selector is deliberately field-whitelisted. In particular, cover, dynamic_cover,
 * origin_cover, and animated_cover are never considered primary media. It has no Android runtime
 * dependency, which keeps the selection rules independently testable.</p>
 */
final class MediaSelector {
    private static final Set<Integer> GALLERY_AWEME_TYPES;
    private static final String[] PLAY_ADDR_KEYS = {
            "play_addr_h264", "playAddrH264",
            "play_addr_265", "playAddrH265",
            "play_addr_256", "playAddr256",
            "play_addr", "playAddr"
    };
    private static final String[] WATERMARK_HINTS = {
            "tplv-dy-water",
            "dy-water",
            "owner_watermark",
            "watermark_image",
            "watermark=1",
            "playwm"
    };
    private static final Pattern IMAGE_EXTENSION_PATTERN = Pattern.compile(
            "\\.(?:jpe?g|png|webp|gif)(?=[^a-z0-9]|$)",
            Pattern.CASE_INSENSITIVE);
    private static final Map<String, String> IMAGE_MIME_EXTENSIONS;
    private static final Map<String, String> IMAGE_EXTENSION_MIMES;

    static {
        Set<Integer> galleryTypes = new HashSet<>();
        galleryTypes.add(2);
        galleryTypes.add(68);
        galleryTypes.add(150);
        GALLERY_AWEME_TYPES = Collections.unmodifiableSet(galleryTypes);

        Map<String, String> mimeExtensions = new LinkedHashMap<>();
        mimeExtensions.put("image/gif", ".gif");
        mimeExtensions.put("image/jpeg", ".jpg");
        mimeExtensions.put("image/jpg", ".jpg");
        mimeExtensions.put("image/png", ".png");
        mimeExtensions.put("image/webp", ".webp");
        IMAGE_MIME_EXTENSIONS = Collections.unmodifiableMap(mimeExtensions);

        Map<String, String> extensionMimes = new LinkedHashMap<>();
        extensionMimes.put(".gif", "image/gif");
        extensionMimes.put(".jpg", "image/jpeg");
        extensionMimes.put(".jpeg", "image/jpeg");
        extensionMimes.put(".png", "image/png");
        extensionMimes.put(".webp", "image/webp");
        IMAGE_EXTENSION_MIMES = Collections.unmodifiableMap(extensionMimes);
    }

    private MediaSelector() {
    }

    enum MediaType {
        VIDEO,
        GALLERY
    }

    static final class WorkPlan {
        final MediaType mediaType;
        final String awemeId;
        final String title;
        final String author;
        final long createTimeEpochSeconds;
        final String publishDate;
        final List<VideoCandidate> videoCandidates;
        final List<ImageCandidate> previewImageCandidates;
        final List<GalleryItemPlan> galleryItems;
        final String gallerySourcePath;

        WorkPlan(
                MediaType mediaType,
                String awemeId,
                String title,
                String author,
                long createTimeEpochSeconds,
                String publishDate,
                List<VideoCandidate> videoCandidates,
                List<ImageCandidate> previewImageCandidates,
                List<GalleryItemPlan> galleryItems,
                String gallerySourcePath) {
            this.mediaType = mediaType;
            this.awemeId = awemeId;
            this.title = title;
            this.author = author;
            this.createTimeEpochSeconds = createTimeEpochSeconds;
            this.publishDate = publishDate;
            this.videoCandidates = immutableCopy(videoCandidates);
            this.previewImageCandidates = immutableCopy(previewImageCandidates);
            this.galleryItems = immutableCopy(galleryItems);
            this.gallerySourcePath = gallerySourcePath;
        }

        boolean isGallery() {
            return mediaType == MediaType.GALLERY;
        }
    }

    /** A gallery item keeps its original zero-based JSON array index. */
    static final class GalleryItemPlan {
        final int itemIndex;
        final List<ImageCandidate> imageCandidates;
        final List<VideoCandidate> liveCandidates;

        GalleryItemPlan(
                int itemIndex,
                List<ImageCandidate> imageCandidates,
                List<VideoCandidate> liveCandidates) {
            this.itemIndex = itemIndex;
            this.imageCandidates = immutableCopy(imageCandidates);
            this.liveCandidates = immutableCopy(liveCandidates);
        }
    }

    static final class ImageCandidate {
        final String url;
        final String sourcePath;
        final int sourceRank;
        final boolean watermarked;
        final int width;
        final int height;
        final long resolutionScore;
        final String extensionHint;
        final String mimeTypeHint;
        private final int traversalOrder;

        ImageCandidate(
                String url,
                String sourcePath,
                int sourceRank,
                boolean watermarked,
                int width,
                int height,
                long resolutionScore,
                String extensionHint,
                String mimeTypeHint,
                int traversalOrder) {
            this.url = url;
            this.sourcePath = sourcePath;
            this.sourceRank = sourceRank;
            this.watermarked = watermarked;
            this.width = width;
            this.height = height;
            this.resolutionScore = resolutionScore;
            this.extensionHint = extensionHint;
            this.mimeTypeHint = mimeTypeHint;
            this.traversalOrder = traversalOrder;
        }
    }

    static final class VideoCandidate {
        final List<String> urls;
        final String uri;
        final String sourcePath;
        final int bitrate;
        final int width;
        final int height;
        final int shortEdge;
        final long pixels;
        final long durationMs;
        private final int traversalOrder;

        VideoCandidate(
                List<String> urls,
                String uri,
                String sourcePath,
                int bitrate,
                int width,
                int height,
                int shortEdge,
                long pixels,
                long durationMs,
                int traversalOrder) {
            this.urls = immutableCopy(urls);
            this.uri = uri;
            this.sourcePath = sourcePath;
            this.bitrate = bitrate;
            this.width = width;
            this.height = height;
            this.shortEdge = shortEdge;
            this.pixels = pixels;
            this.durationMs = durationMs;
            this.traversalOrder = traversalOrder;
        }

        boolean hasCleanUrl() {
            for (String url : urls) {
                if (!isWatermarkedMediaUrl(url)) {
                    return true;
                }
            }
            return false;
        }

        boolean isWatermarkedFallbackOnly() {
            return uri == null && !urls.isEmpty() && !hasCleanUrl();
        }
    }

    static WorkPlan select(JSONObject awemeDetail) {
        return select(awemeDetail, System.currentTimeMillis());
    }

    /** Visible for deterministic tests of missing/invalid create_time. */
    static WorkPlan select(JSONObject awemeDetail, long nowEpochMillis) {
        if (awemeDetail == null) {
            throw new IllegalArgumentException("aweme_detail is required");
        }

        String awemeId = stringValue(optEither(awemeDetail, "aweme_id", "awemeId"));
        if (awemeId == null) {
            throw new IllegalArgumentException("aweme_detail.aweme_id is required");
        }

        String title = trimmedString(awemeDetail.opt("desc"));
        if (title == null) {
            title = "no_title";
        }
        JSONObject authorObject = optObjectEither(awemeDetail, "author", "authorInfo");
        String author = authorObject == null
                ? null
                : trimmedString(authorObject.opt("nickname"));
        if (author == null && authorObject != null) {
            author = trimmedString(authorObject.opt("name"));
        }
        if (author == null) {
            author = "unknown";
        }

        long createTime = positiveLong(optEither(awemeDetail, "create_time", "createTime"));
        long dateEpochMillis = epochSecondsToMillis(createTime, nowEpochMillis);
        String publishDate = new SimpleDateFormat("yyyy-MM-dd", Locale.US)
                .format(new Date(dateEpochMillis));

        GalleryArray galleryArray = findGalleryArray(awemeDetail);
        JSONObject video = awemeDetail.optJSONObject("video");
        List<VideoCandidate> normalVideoCandidates = collectNormalVideoCandidates(video, "video");
        List<ImageCandidate> previewImageCandidates = collectPreviewImageCandidates(video, "video");
        MediaType mediaType;
        if (galleryArray != null) {
            mediaType = MediaType.GALLERY;
        } else {
            int awemeType = integerValue(
                    optEither(awemeDetail, "aweme_type", "awemeType"),
                    Integer.MIN_VALUE);
            if (GALLERY_AWEME_TYPES.contains(awemeType)) {
                mediaType = normalVideoCandidates.isEmpty() ? MediaType.GALLERY : MediaType.VIDEO;
            } else {
                mediaType = MediaType.VIDEO;
            }
        }

        List<GalleryItemPlan> galleryItems = new ArrayList<>();
        String gallerySourcePath = null;
        if (mediaType == MediaType.GALLERY && galleryArray != null) {
            gallerySourcePath = galleryArray.path;
            for (int itemIndex = 0; itemIndex < galleryArray.items.length(); itemIndex++) {
                JSONObject item = galleryArray.items.optJSONObject(itemIndex);
                String itemPath = galleryArray.path + "[" + itemIndex + "]";
                List<ImageCandidate> images = item == null
                        ? Collections.<ImageCandidate>emptyList()
                        : collectImageCandidates(item, itemPath);
                List<VideoCandidate> live = item == null
                        ? Collections.<VideoCandidate>emptyList()
                        : collectLiveCandidates(item, itemPath);
                galleryItems.add(new GalleryItemPlan(itemIndex, images, live));
            }
        }

        return new WorkPlan(
                mediaType,
                awemeId,
                title,
                author,
                createTime,
                publishDate,
                mediaType == MediaType.VIDEO
                        ? normalVideoCandidates
                        : Collections.<VideoCandidate>emptyList(),
                mediaType == MediaType.VIDEO
                        ? previewImageCandidates
                        : Collections.<ImageCandidate>emptyList(),
                galleryItems,
                gallerySourcePath);
    }

    private static List<ImageCandidate> collectPreviewImageCandidates(
            JSONObject video,
            String videoPath) {
        if (video == null) {
            return Collections.emptyList();
        }
        List<ImageCandidate> candidates = new ArrayList<>();
        int[] traversalOrder = {0};
        String[][] keys = {
                {"cover", "cover"},
                {"origin_cover", "originCover"},
                {"dynamic_cover", "dynamicCover"},
                {"animated_cover", "animatedCover"}
        };
        for (int rank = 0; rank < keys.length; rank++) {
            Object source = optEither(video, keys[rank][0], keys[rank][1]);
            addImageSource(
                    candidates,
                    source,
                    asObject(source),
                    rank,
                    videoPath + "." + keys[rank][0],
                    traversalOrder);
        }
        Collections.sort(candidates, IMAGE_COMPARATOR);
        List<ImageCandidate> deduplicated = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        for (ImageCandidate candidate : candidates) {
            if (seen.add(candidate.url)) {
                deduplicated.add(candidate);
            }
        }
        return immutableCopy(deduplicated);
    }

    static boolean isWatermarkedMediaUrl(String url) {
        if (url == null) {
            return false;
        }
        String normalized = url.toLowerCase(Locale.ROOT);
        for (String hint : WATERMARK_HINTS) {
            if (normalized.contains(hint)) {
                return true;
            }
        }
        return false;
    }

    static String resolveImageExtension(String imageUrl, String responseContentType) {
        String normalizedMime = normalizeMimeType(responseContentType);
        String mimeExtension = IMAGE_MIME_EXTENSIONS.get(normalizedMime);
        return mimeExtension == null ? inferImageExtension(imageUrl) : mimeExtension;
    }

    static String resolveImageMimeType(String imageUrl, String responseContentType) {
        String normalizedMime = normalizeMimeType(responseContentType);
        if (IMAGE_MIME_EXTENSIONS.containsKey(normalizedMime)) {
            return normalizedMime.equals("image/jpg") ? "image/jpeg" : normalizedMime;
        }
        return IMAGE_EXTENSION_MIMES.get(inferImageExtension(imageUrl));
    }

    private static GalleryArray findGalleryArray(JSONObject awemeDetail) {
        JSONObject imagePostInfo = optObjectEither(
                awemeDetail, "image_post_info", "imagePostInfo");
        if (imagePostInfo != null) {
            JSONArray images = nonEmptyArray(imagePostInfo.optJSONArray("images"));
            if (images != null) {
                return new GalleryArray(images, "image_post_info.images");
            }
            JSONArray imageList = nonEmptyArray(optArrayEither(
                    imagePostInfo, "image_list", "imageList"));
            if (imageList != null) {
                return new GalleryArray(imageList, "image_post_info.image_list");
            }
        }

        JSONArray images = nonEmptyArray(awemeDetail.optJSONArray("images"));
        if (images != null) {
            return new GalleryArray(images, "images");
        }
        JSONArray imageList = nonEmptyArray(optArrayEither(
                awemeDetail, "image_list", "imageList"));
        if (imageList != null) {
            return new GalleryArray(imageList, "image_list");
        }
        return null;
    }

    private static JSONArray nonEmptyArray(JSONArray candidate) {
        return candidate != null && candidate.length() > 0 ? candidate : null;
    }

    private static List<VideoCandidate> collectNormalVideoCandidates(
            JSONObject video,
            String videoPath) {
        if (video == null) {
            return Collections.emptyList();
        }

        List<VideoCandidate> qualityCandidates = collectQualityCandidates(video, videoPath);
        if (!qualityCandidates.isEmpty()) {
            String globalUri = firstNonBlank(
                    trimmedString(video.opt("vid")),
                    nestedUri(optObjectEither(video, "download_addr", "downloadAddr")));
            if (qualityCandidates.get(0).uri == null && globalUri != null) {
                qualityCandidates.set(0, withUri(qualityCandidates.get(0), globalUri));
            }
            return immutableCopy(qualityCandidates);
        }

        List<VideoCandidate> candidates = new ArrayList<>();
        int traversalOrder = 0;
        Object primary = optEither(video, "play_addr", "playAddr");
        addDistinctVideoCandidate(
                candidates,
                videoCandidateFromSource(
                        primary,
                        video,
                        null,
                        videoPath + ".play_addr",
                        traversalOrder++));
        for (String key : PLAY_ADDR_KEYS) {
            VideoCandidate candidate = videoCandidateFromSource(
                    video.opt(key),
                    video,
                    null,
                    videoPath + "." + key,
                    traversalOrder++);
            addDistinctVideoCandidate(candidates, candidate);
        }

        String videoVid = trimmedString(video.opt("vid"));
        String downloadAddressUri = nestedUri(
                optObjectEither(video, "download_addr", "downloadAddr"));
        String globalUri = firstNonBlank(videoVid, downloadAddressUri);
        if (candidates.isEmpty() && globalUri != null) {
            candidates.add(new VideoCandidate(
                    Collections.<String>emptyList(),
                    globalUri,
                    videoVid == null ? videoPath + ".download_addr.uri" : videoPath + ".vid",
                    0,
                    0,
                    0,
                    0,
                    0L,
                    mediaDurationMillis(video),
                    traversalOrder));
        } else if (!candidates.isEmpty()
                && candidates.get(0).uri == null
                && globalUri != null) {
            candidates.set(0, withUri(candidates.get(0), globalUri));
        }
        return immutableCopy(candidates);
    }

    private static List<VideoCandidate> collectQualityCandidates(
            JSONObject video,
            String videoPath) {
        JSONArray bitRates = optArrayEither(video, "bit_rate", "bitRateList");
        if (bitRates == null || bitRates.length() == 0) {
            return new ArrayList<>();
        }

        List<VideoCandidate> candidates = new ArrayList<>();
        long globalDurationMs = mediaDurationMillis(video);
        for (int index = 0; index < bitRates.length(); index++) {
            JSONObject entry = bitRates.optJSONObject(index);
            if (entry == null) {
                continue;
            }
            Object playAddress = optEither(entry, "play_addr", "playAddr");
            VideoCandidate candidate = videoCandidateFromSource(
                    playAddress,
                    entry,
                    entry,
                    videoPath + ".bit_rate[" + index + "].play_addr",
                    index);
            if (candidate != null) {
                if (candidate.durationMs == 0L && globalDurationMs > 0L) {
                    candidate = withDuration(candidate, globalDurationMs);
                }
                candidates.add(candidate);
            }
        }
        Collections.sort(candidates, VIDEO_QUALITY_COMPARATOR);
        return candidates;
    }

    private static List<VideoCandidate> collectLiveCandidates(JSONObject item, String itemPath) {
        JSONObject video = item.optJSONObject("video");
        List<VideoCandidate> candidates = new ArrayList<>();
        int traversalOrder = 0;
        if (video != null) {
            List<VideoCandidate> qualityCandidates = collectQualityCandidates(
                    video, itemPath + ".video");
            for (VideoCandidate candidate : qualityCandidates) {
                addDistinctVideoCandidate(candidates, candidate);
            }

            if (qualityCandidates.isEmpty()) {
                addDistinctVideoCandidate(
                        candidates,
                        videoCandidateFromSource(
                                optEither(video, "play_addr", "playAddr"),
                                video,
                                null,
                                itemPath + ".video.play_addr",
                                traversalOrder++));
            }

            for (String key : PLAY_ADDR_KEYS) {
                addDistinctVideoCandidate(
                        candidates,
                        videoCandidateFromSource(
                                video.opt(key),
                                video,
                                null,
                                itemPath + ".video." + key,
                                traversalOrder++));
            }
            addDistinctVideoCandidate(
                    candidates,
                    videoCandidateFromSource(
                            optEither(video, "download_addr", "downloadAddr"),
                            video,
                            null,
                            itemPath + ".video.download_addr",
                            traversalOrder++));
        }

        addDistinctVideoCandidate(
                candidates,
                videoCandidateFromAnySource(
                        optEither(item, "video_play_addr", "videoPlayAddr"),
                        itemPath + ".video_play_addr",
                        traversalOrder++));
        addDistinctVideoCandidate(
                candidates,
                videoCandidateFromAnySource(
                        optEither(item, "video_download_addr", "videoDownloadAddr"),
                        itemPath + ".video_download_addr",
                        traversalOrder));
        return immutableCopy(candidates);
    }

    private static VideoCandidate videoCandidateFromAnySource(
            Object source,
            String sourcePath,
            int traversalOrder) {
        return videoCandidateFromSource(
                source, asObject(source), null, sourcePath, traversalOrder);
    }

    private static VideoCandidate videoCandidateFromAddress(
            JSONObject address,
            JSONObject entry,
            String sourcePath,
            int traversalOrder) {
        return videoCandidateFromSource(
                address, address, entry, sourcePath, traversalOrder);
    }

    /**
     * Current Douyin hydration may represent playAddr either as an address object or as
     * an array of {src: "https://..."} entries. Keep metadata separate from the URL source
     * so both shapes retain their dimensions and bitrate ranking.
     */
    private static VideoCandidate videoCandidateFromSource(
            Object address,
            JSONObject metadata,
            JSONObject entry,
            String sourcePath,
            int traversalOrder) {
        if (address == null) {
            return null;
        }
        List<String> urls = orderedVideoUrls(extractUrls(address));
        JSONObject addressObject = asObject(address);
        String uri = addressObject == null ? null : trimmedString(addressObject.opt("uri"));
        if (uri == null && metadata != null) {
            uri = trimmedString(metadata.opt("uri"));
        }
        if (urls.isEmpty() && uri == null) {
            return null;
        }

        int width = addressObject == null ? 0 : positiveInt(addressObject.opt("width"));
        int height = addressObject == null ? 0 : positiveInt(addressObject.opt("height"));
        if (metadata != null) {
            if (width == 0) {
                width = positiveInt(metadata.opt("width"));
            }
            if (height == 0) {
                height = positiveInt(metadata.opt("height"));
            }
        }
        if (entry != null) {
            if (width == 0) {
                width = positiveInt(entry.opt("width"));
            }
            if (height == 0) {
                height = positiveInt(entry.opt("height"));
            }
        }
        Resolution resolution = videoResolution(width, height);
        long durationMs = firstPositiveLong(
                mediaDurationMillis(addressObject),
                mediaDurationMillis(metadata),
                mediaDurationMillis(entry));
        int bitrate = entry == null
                ? 0
                : nonNegativeInt(optEither(entry, "bit_rate", "bitRate"));
        return new VideoCandidate(
                urls,
                uri,
                sourcePath,
                bitrate,
                width,
                height,
                resolution.shortEdge,
                resolution.pixels,
                durationMs,
                traversalOrder);
    }

    private static List<ImageCandidate> collectImageCandidates(
            JSONObject item,
            String itemPath) {
        List<ImageCandidate> candidates = new ArrayList<>();
        int[] traversalOrder = {0};

        addImageSource(
                candidates,
                optEither(item,
                        "watermark_free_download_url_list",
                        "watermarkFreeDownloadUrlList"),
                item,
                0,
                itemPath + ".watermark_free_download_url_list",
                traversalOrder);
        Object originImage = optEither(item, "origin_image", "originImage");
        addImageSource(
                candidates,
                originImage,
                asObject(originImage),
                1,
                itemPath + ".origin_image",
                traversalOrder);
        Object displayImage = optEither(item, "display_image", "displayImage");
        addImageSource(
                candidates,
                displayImage,
                asObject(displayImage),
                2,
                itemPath + ".display_image",
                traversalOrder);
        addImageSource(
                candidates,
                item,
                item,
                3,
                itemPath + ".url_list",
                traversalOrder);
        Object downloadUrl = optEither(item, "download_url", "downloadUrl");
        addImageSource(
                candidates,
                downloadUrl,
                asObject(downloadUrl),
                4,
                itemPath + ".download_url",
                traversalOrder);
        Object downloadAddress = optEither(item, "download_addr", "downloadAddr");
        addImageSource(
                candidates,
                downloadAddress,
                asObject(downloadAddress),
                5,
                itemPath + ".download_addr",
                traversalOrder);
        addImageSource(
                candidates,
                optEither(item, "download_url_list", "downloadUrlList"),
                item,
                6,
                itemPath + ".download_url_list",
                traversalOrder);
        Object ownerWatermark = optEither(
                item, "owner_watermark_image", "ownerWatermarkImage");
        addImageSource(
                candidates,
                ownerWatermark,
                asObject(ownerWatermark),
                7,
                itemPath + ".owner_watermark_image",
                traversalOrder);

        Collections.sort(candidates, IMAGE_COMPARATOR);
        List<ImageCandidate> deduplicated = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        for (ImageCandidate candidate : candidates) {
            if (seen.add(candidate.url)) {
                deduplicated.add(candidate);
            }
        }
        return immutableCopy(deduplicated);
    }

    private static void addImageSource(
            List<ImageCandidate> output,
            Object source,
            JSONObject metadata,
            int sourceRank,
            String sourcePath,
            int[] traversalOrder) {
        int width = metadata == null ? 0 : positiveInt(metadata.opt("width"));
        int height = metadata == null ? 0 : positiveInt(metadata.opt("height"));
        if (metadata != null && width == 0) {
            width = positiveInt(metadata.opt("w"));
        }
        if (metadata != null && height == 0) {
            height = positiveInt(metadata.opt("h"));
        }
        long resolutionScore = imageResolutionScore(width, height);

        for (String url : extractUrls(source)) {
            String extension = inferImageExtension(url);
            output.add(new ImageCandidate(
                    url,
                    sourcePath,
                    sourceRank,
                    sourceRank == 7 || isWatermarkedMediaUrl(url),
                    width,
                    height,
                    resolutionScore,
                    extension,
                    IMAGE_EXTENSION_MIMES.get(extension),
                    traversalOrder[0]++));
        }
    }

    private static final Comparator<VideoCandidate> VIDEO_QUALITY_COMPARATOR =
            new Comparator<VideoCandidate>() {
                @Override
                public int compare(VideoCandidate left, VideoCandidate right) {
                    int result = Long.compare(right.pixels, left.pixels);
                    if (result != 0) {
                        return result;
                    }
                    result = Integer.compare(right.bitrate, left.bitrate);
                    if (result != 0) {
                        return result;
                    }
                    result = Integer.compare(right.shortEdge, left.shortEdge);
                    if (result != 0) {
                        return result;
                    }
                    return Integer.compare(left.traversalOrder, right.traversalOrder);
                }
            };

    private static final Comparator<ImageCandidate> IMAGE_COMPARATOR =
            new Comparator<ImageCandidate>() {
                @Override
                public int compare(ImageCandidate left, ImageCandidate right) {
                    int result = Boolean.compare(left.watermarked, right.watermarked);
                    if (result != 0) {
                        return result;
                    }
                    result = Long.compare(right.resolutionScore, left.resolutionScore);
                    if (result != 0) {
                        return result;
                    }
                    result = Integer.compare(left.sourceRank, right.sourceRank);
                    if (result != 0) {
                        return result;
                    }
                    result = Integer.compare(imageFormatRank(left.url), imageFormatRank(right.url));
                    if (result != 0) {
                        return result;
                    }
                    return Integer.compare(left.traversalOrder, right.traversalOrder);
                }
            };

    private static void addDistinctVideoCandidate(
            List<VideoCandidate> output,
            VideoCandidate candidate) {
        if (candidate == null) {
            return;
        }
        String identity = candidate.urls.isEmpty() ? candidate.uri : candidate.urls.get(0);
        for (VideoCandidate existing : output) {
            String existingIdentity = existing.urls.isEmpty() ? existing.uri : existing.urls.get(0);
            if (identity != null && identity.equals(existingIdentity)) {
                return;
            }
        }
        output.add(candidate);
    }

    private static VideoCandidate withUri(VideoCandidate candidate, String uri) {
        return new VideoCandidate(
                candidate.urls,
                uri,
                candidate.sourcePath,
                candidate.bitrate,
                candidate.width,
                candidate.height,
                candidate.shortEdge,
                candidate.pixels,
                candidate.durationMs,
                candidate.traversalOrder);
    }

    private static VideoCandidate withDuration(VideoCandidate candidate, long durationMs) {
        return new VideoCandidate(
                candidate.urls,
                candidate.uri,
                candidate.sourcePath,
                candidate.bitrate,
                candidate.width,
                candidate.height,
                candidate.shortEdge,
                candidate.pixels,
                durationMs,
                candidate.traversalOrder);
    }

    private static List<String> extractUrls(Object source) {
        LinkedHashSet<String> urls = new LinkedHashSet<>();
        collectUrls(source, urls, 0);
        return new ArrayList<>(urls);
    }

    private static void collectUrls(Object source, LinkedHashSet<String> urls, int depth) {
        if (source == null || source == JSONObject.NULL || depth > 4) {
            return;
        }
        if (source instanceof JSONObject) {
            JSONObject object = (JSONObject) source;
            Object actual = object.opt("url_list");
            if (actual == null || actual == JSONObject.NULL
                    || (actual instanceof JSONArray && ((JSONArray) actual).length() == 0)) {
                actual = object.opt("urlList");
            }
            if (actual != null && actual != JSONObject.NULL) {
                collectUrls(actual, urls, depth + 1);
                return;
            }
            collectUrls(object.opt("url"), urls, depth + 1);
            collectUrls(object.opt("src"), urls, depth + 1);
            collectUrls(object.opt("download_url"), urls, depth + 1);
            collectUrls(object.opt("downloadUrl"), urls, depth + 1);
            return;
        }
        if (source instanceof JSONArray) {
            JSONArray array = (JSONArray) source;
            for (int index = 0; index < array.length(); index++) {
                collectUrls(array.opt(index), urls, depth + 1);
            }
            return;
        }
        String url = trimmedString(source);
        if (url != null && (url.startsWith("https://") || url.startsWith("http://"))) {
            urls.add(url);
        }
    }

    private static JSONObject asObject(Object value) {
        return value instanceof JSONObject ? (JSONObject) value : null;
    }

    private static Object optEither(JSONObject object, String snakeCase, String camelCase) {
        Object value = object.opt(snakeCase);
        return value == null || value == JSONObject.NULL ? object.opt(camelCase) : value;
    }

    private static JSONObject optObjectEither(
            JSONObject object,
            String snakeCase,
            String camelCase) {
        Object value = optEither(object, snakeCase, camelCase);
        return value instanceof JSONObject ? (JSONObject) value : null;
    }

    private static JSONArray optArrayEither(
            JSONObject object,
            String snakeCase,
            String camelCase) {
        Object value = optEither(object, snakeCase, camelCase);
        return value instanceof JSONArray ? (JSONArray) value : null;
    }

    private static List<String> orderedVideoUrls(List<String> sourceUrls) {
        List<String> explicitNoWatermark = new ArrayList<>();
        List<String> clean = new ArrayList<>();
        List<String> watermarked = new ArrayList<>();
        for (String url : sourceUrls) {
            if (url.contains("watermark=0") && !isWatermarkedMediaUrl(url)) {
                explicitNoWatermark.add(url);
            } else if (isWatermarkedMediaUrl(url)) {
                watermarked.add(url);
            } else {
                clean.add(url);
            }
        }
        List<String> ordered = new ArrayList<>(sourceUrls.size());
        ordered.addAll(explicitNoWatermark);
        ordered.addAll(clean);
        ordered.addAll(watermarked);
        return ordered;
    }

    private static Resolution videoResolution(int width, int height) {
        if (width > 0 && height > 0) {
            return new Resolution(Math.min(width, height), ((long) width) * height);
        }
        int longEdge = Math.max(width, height);
        if (longEdge <= 0) {
            return new Resolution(0, 0L);
        }

        int[] longEdges = {2560, 1920, 1280, 960, 854, 640};
        int[] shortEdges = {1440, 1080, 720, 540, 480, 360};
        int best = 0;
        long bestDistance = Math.abs((long) longEdge - longEdges[0]);
        for (int index = 1; index < longEdges.length; index++) {
            long distance = Math.abs((long) longEdge - longEdges[index]);
            if (distance < bestDistance) {
                best = index;
                bestDistance = distance;
            }
        }
        return new Resolution(shortEdges[best], ((long) longEdge) * shortEdges[best]);
    }

    private static long imageResolutionScore(int width, int height) {
        if (width > 0 && height > 0) {
            return ((long) width) * height;
        }
        return Math.max(width, height);
    }

    private static int imageFormatRank(String url) {
        return urlPath(url).toLowerCase(Locale.ROOT).contains(".webp") ? 1 : 0;
    }

    private static String inferImageExtension(String url) {
        String path = urlPath(url).toLowerCase(Locale.ROOT);
        Matcher matcher = IMAGE_EXTENSION_PATTERN.matcher(path);
        String extension = null;
        while (matcher.find()) {
            extension = matcher.group().toLowerCase(Locale.ROOT);
        }
        return extension == null ? ".jpg" : extension;
    }

    private static String urlPath(String url) {
        if (url == null) {
            return "";
        }
        try {
            String path = new URI(url).getPath();
            return path == null ? "" : path;
        } catch (URISyntaxException ignored) {
            int query = url.indexOf('?');
            int fragment = url.indexOf('#');
            int end = url.length();
            if (query >= 0) {
                end = Math.min(end, query);
            }
            if (fragment >= 0) {
                end = Math.min(end, fragment);
            }
            return url.substring(0, end);
        }
    }

    private static String normalizeMimeType(String contentType) {
        if (contentType == null) {
            return "";
        }
        int delimiter = contentType.indexOf(';');
        String base = delimiter < 0 ? contentType : contentType.substring(0, delimiter);
        return base.trim().toLowerCase(Locale.ROOT);
    }

    private static String nestedUri(JSONObject object) {
        return object == null ? null : trimmedString(object.opt("uri"));
    }

    private static String firstNonBlank(String first, String second) {
        return first == null ? second : first;
    }

    private static String stringValue(Object value) {
        if (value == null || value == JSONObject.NULL) {
            return null;
        }
        String result = String.valueOf(value).trim();
        return result.isEmpty() ? null : result;
    }

    private static String trimmedString(Object value) {
        return stringValue(value);
    }

    private static int integerValue(Object value, int fallback) {
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        return fallback;
    }

    private static int positiveInt(Object value) {
        try {
            if (value == null || value == JSONObject.NULL) {
                return 0;
            }
            int result;
            if (value instanceof Number) {
                result = (int) ((Number) value).doubleValue();
            } else {
                result = (int) Double.parseDouble(String.valueOf(value).trim());
            }
            return result > 0 ? result : 0;
        } catch (NumberFormatException exception) {
            return 0;
        }
    }

    private static int nonNegativeInt(Object value) {
        int result = positiveInt(value);
        return Math.max(result, 0);
    }

    private static long positiveLong(Object value) {
        try {
            if (value == null || value == JSONObject.NULL) {
                return 0L;
            }
            long result = value instanceof Number
                    ? ((Number) value).longValue()
                    : Long.parseLong(String.valueOf(value).trim());
            return result > 0L ? result : 0L;
        } catch (NumberFormatException exception) {
            return 0L;
        }
    }

    private static long mediaDurationMillis(JSONObject object) {
        if (object == null) {
            return 0L;
        }
        String[] keys = {
                "duration", "duration_ms", "durationMs", "video_duration", "videoDuration"
        };
        for (String key : keys) {
            long value = positiveLong(object.opt(key));
            if (value > 0L) {
                return value;
            }
        }
        return 0L;
    }

    private static long firstPositiveLong(long... values) {
        for (long value : values) {
            if (value > 0L) {
                return value;
            }
        }
        return 0L;
    }

    private static long epochSecondsToMillis(long epochSeconds, long fallbackMillis) {
        if (epochSeconds <= 0L || epochSeconds > Long.MAX_VALUE / 1000L) {
            return fallbackMillis;
        }
        return epochSeconds * 1000L;
    }

    private static <T> List<T> immutableCopy(List<T> values) {
        return Collections.unmodifiableList(new ArrayList<>(values));
    }

    private static final class GalleryArray {
        final JSONArray items;
        final String path;

        GalleryArray(JSONArray items, String path) {
            this.items = items;
            this.path = path;
        }
    }

    private static final class Resolution {
        final int shortEdge;
        final long pixels;

        Resolution(int shortEdge, long pixels) {
            this.shortEdge = shortEdge;
            this.pixels = pixels;
        }
    }
}
