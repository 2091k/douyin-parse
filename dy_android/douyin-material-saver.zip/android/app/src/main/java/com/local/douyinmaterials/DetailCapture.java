package com.local.douyinmaterials;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

final class DetailCapture {
    final long capturedAtEpochMs;
    final String url;
    final String method;
    final Map<String, String> headers;
    final String cookie;
    final String awemeId;

    DetailCapture(String url, String method, Map<String, String> headers, String cookie) {
        this.capturedAtEpochMs = System.currentTimeMillis();
        this.url = url;
        this.method = method == null ? "GET" : method;
        this.headers = Collections.unmodifiableMap(new LinkedHashMap<>(headers));
        this.cookie = cookie;
        this.awemeId = ShareLinkParser.extractAwemeId(url);
    }
}
