package com.local.douyinmaterials;

import android.net.Uri;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class ShareLinkParser {
    private static final Pattern URL_PATTERN = Pattern.compile(
            "https?://[^\\s\\u0000-\\u001f<>\\\"']+",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern PATH_AWEME_PATTERN = Pattern.compile(
            "/(?:video|note|slides)/(\\d{8,})",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern JSON_AWEME_PATTERN = Pattern.compile(
            "[\\\"']aweme_id[\\\"']\\s*[:=]\\s*[\\\"']?(\\d{8,})",
            Pattern.CASE_INSENSITIVE);

    private ShareLinkParser() {
    }

    static String extractDouyinUrl(String text) {
        if (text == null) {
            return null;
        }
        Matcher matcher = URL_PATTERN.matcher(text);
        while (matcher.find()) {
            String candidate = trimTrailingPunctuation(matcher.group());
            Uri uri = Uri.parse(candidate);
            if (isHttp(uri) && isDouyinHost(uri.getHost())) {
                // Old share texts can still contain http links.  The public Douyin endpoints
                // support HTTPS, so normalize before the URL reaches WebView.
                return "http".equalsIgnoreCase(uri.getScheme())
                        ? "https" + candidate.substring(4)
                        : candidate;
            }
        }
        return null;
    }

    static boolean isDouyinHost(String host) {
        if (host == null) {
            return false;
        }
        String normalized = host.toLowerCase(Locale.US);
        return normalized.equals("douyin.com")
                || normalized.endsWith(".douyin.com")
                || normalized.equals("iesdouyin.com")
                || normalized.endsWith(".iesdouyin.com");
    }

    static String extractAwemeId(String value) {
        if (value == null || value.isEmpty()) {
            return null;
        }
        try {
            Uri uri = Uri.parse(value);
            String queryId = uri.getQueryParameter("aweme_id");
            if (looksLikeAwemeId(queryId)) {
                return queryId;
            }
            Matcher pathMatcher = PATH_AWEME_PATTERN.matcher(uri.getPath() == null ? "" : uri.getPath());
            if (pathMatcher.find()) {
                return pathMatcher.group(1);
            }
        } catch (RuntimeException ignored) {
            // The value may be page JSON rather than a URL.
        }
        Matcher jsonMatcher = JSON_AWEME_PATTERN.matcher(value);
        return jsonMatcher.find() ? jsonMatcher.group(1) : null;
    }

    static String pathOnly(String url) {
        try {
            String path = Uri.parse(url).getEncodedPath();
            return path == null || path.isEmpty() ? "/" : path;
        } catch (RuntimeException ignored) {
            return "/";
        }
    }

    static boolean isHttp(Uri uri) {
        String scheme = uri == null ? null : uri.getScheme();
        return "https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme);
    }

    static boolean isTrustedHttpsDouyinUri(Uri uri) {
        return uri != null
                && "https".equalsIgnoreCase(uri.getScheme())
                && isDouyinHost(uri.getHost());
    }

    static boolean isWebDetailEndpoint(Uri uri) {
        return isTrustedHttpsDouyinUri(uri)
                && "/aweme/v1/web/aweme/detail/".equals(uri.getPath());
    }

    private static boolean looksLikeAwemeId(String value) {
        return value != null && value.matches("\\d{8,}");
    }

    private static String trimTrailingPunctuation(String value) {
        int end = value.length();
        while (end > 0) {
            char c = value.charAt(end - 1);
            if (c == '.' || c == ',' || c == ';' || c == ':' || c == '!' || c == '?'
                    || c == ')' || c == ']' || c == '}' || c == '\uff0c' || c == '\u3002'
                    || c == '\uff1b' || c == '\uff1a' || c == '\uff01' || c == '\uff1f'
                    || c == '\uff09' || c == '\u3011' || c == '\u300b') {
                end--;
            } else {
                break;
            }
        }
        return value.substring(0, end);
    }
}
