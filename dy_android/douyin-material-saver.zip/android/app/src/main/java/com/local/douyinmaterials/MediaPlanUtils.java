package com.local.douyinmaterials;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Shared rules for turning a selected work plan into downloadable clean media assets. */
final class MediaPlanUtils {
    private MediaPlanUtils() {
    }

    static List<String> bestCleanVideoMirrors(
            List<MediaSelector.VideoCandidate> candidates) {
        for (MediaSelector.VideoCandidate candidate : candidates) {
            List<String> clean = cleanUrls(candidate.urls);
            if (!clean.isEmpty()) {
                return clean;
            }
        }
        return new ArrayList<>();
    }

    static MediaSelector.VideoCandidate bestCleanVideoCandidate(
            List<MediaSelector.VideoCandidate> candidates) {
        for (MediaSelector.VideoCandidate candidate : candidates) {
            if (!cleanUrls(candidate.urls).isEmpty()) {
                return candidate;
            }
        }
        return null;
    }

    static List<String> cleanImageMirrors(
            List<MediaSelector.ImageCandidate> candidates) {
        Set<String> clean = new LinkedHashSet<>();
        for (MediaSelector.ImageCandidate candidate : candidates) {
            if (!candidate.watermarked
                    && candidate.url != null
                    && !MediaSelector.isWatermarkedMediaUrl(candidate.url)) {
                clean.add(candidate.url);
            }
        }
        return new ArrayList<>(clean);
    }

    static String firstCleanImageUrl(List<MediaSelector.ImageCandidate> candidates) {
        List<String> mirrors = cleanImageMirrors(candidates);
        return mirrors.isEmpty() ? null : mirrors.get(0);
    }

    private static List<String> cleanUrls(List<String> values) {
        Set<String> clean = new LinkedHashSet<>();
        for (String value : values) {
            if (value != null && !MediaSelector.isWatermarkedMediaUrl(value)) {
                clean.add(value);
            }
        }
        return new ArrayList<>(clean);
    }
}
