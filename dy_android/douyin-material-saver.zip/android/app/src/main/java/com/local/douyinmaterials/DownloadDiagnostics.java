package com.local.douyinmaterials;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Stores only a small, non-sensitive result summary so failures remain visible after reopening.
 * No URL, query signature, cookie, request header, title or author is recorded.
 */
final class DownloadDiagnostics {
    private static final String PREFS = "download_diagnostics";
    private static final String KEY_STATE = "state";
    private static final String KEY_MESSAGE = "message";
    private static final String KEY_ERROR = "error";
    private static final String KEY_AWEME_ID = "aweme_id";
    private static final String KEY_TIME = "time";

    private DownloadDiagnostics() {
    }

    static void reset(Context context, String awemeId) {
        prefs(context).edit()
                .putString(KEY_STATE, "parsing")
                .putString(KEY_MESSAGE, "正在解析作品")
                .remove(KEY_ERROR)
                .putString(KEY_AWEME_ID, safeAwemeId(awemeId))
                .putLong(KEY_TIME, System.currentTimeMillis())
                .apply();
    }

    static void record(
            Context context,
            String state,
            String message,
            String awemeId,
            boolean isErrorDetail) {
        SharedPreferences.Editor editor = prefs(context).edit()
                .putString(KEY_STATE, safeText(state, 40))
                .putString(KEY_MESSAGE, safeText(message, 240))
                .putString(KEY_AWEME_ID, safeAwemeId(awemeId))
                .putLong(KEY_TIME, System.currentTimeMillis());
        if (isErrorDetail) {
            editor.putString(KEY_ERROR, safeText(message, 240));
        } else if (MediaDownloadContract.STATE_COMPLETED.equals(state)) {
            editor.remove(KEY_ERROR);
        }
        editor.apply();
    }

    static String latestSummary(Context context) {
        SharedPreferences preferences = prefs(context);
        long time = preferences.getLong(KEY_TIME, 0L);
        if (time <= 0L) {
            return null;
        }
        String when = new SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(new Date(time));
        String awemeId = preferences.getString(KEY_AWEME_ID, "");
        String message = preferences.getString(KEY_MESSAGE, "");
        String error = preferences.getString(KEY_ERROR, "");
        StringBuilder result = new StringBuilder("上次 ").append(when);
        if (awemeId != null && !awemeId.isEmpty()) {
            result.append(" · ").append(awemeId);
        }
        if (message != null && !message.isEmpty()) {
            result.append(" · ").append(message);
        }
        if (error != null && !error.isEmpty() && !error.equals(message)) {
            result.append("；原因：").append(error);
        }
        return result.toString();
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static String safeAwemeId(String value) {
        return value != null && value.matches("\\d{8,}") ? value : "";
    }

    private static String safeText(String value, int maximum) {
        if (value == null) {
            return "";
        }
        String safe = value.replaceAll("https?://\\S+", "[地址已隐藏]")
                .replaceAll("[\\r\\n\\t]+", " ")
                .trim();
        return safe.length() <= maximum ? safe : safe.substring(0, maximum);
    }
}
