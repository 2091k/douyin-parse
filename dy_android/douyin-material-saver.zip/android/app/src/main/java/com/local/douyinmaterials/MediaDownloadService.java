package com.local.douyinmaterials;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/** Foreground data-sync service that saves a local aweme detail JSON plan into MediaStore. */
public final class MediaDownloadService extends Service {
    public static final String ACTION_START =
            "com.local.douyinmaterials.action.START_MEDIA_DOWNLOAD";
    public static final String ACTION_CANCEL =
            "com.local.douyinmaterials.action.CANCEL_MEDIA_DOWNLOAD";
    public static final String EXTRA_JOB_ID = "job_id";

    private static final String CHANNEL_ID = "douyin_material_downloads";
    private static final int NOTIFICATION_ID = 2107;

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Set<AtomicBoolean> activeCancellations = Collections.newSetFromMap(
            new ConcurrentHashMap<AtomicBoolean, Boolean>());
    private final AtomicInteger activeRuns = new AtomicInteger();
    private NotificationManager notificationManager;
    private MediaStoreDownloader downloader;

    public static void start(Context context, String jobId) {
        Intent intent = new Intent(context, MediaDownloadService.class)
                .setAction(ACTION_START)
                .putExtra(EXTRA_JOB_ID, jobId);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent);
        } else {
            context.startService(intent);
        }
    }

    public static void cancel(Context context) {
        context.startService(new Intent(context, MediaDownloadService.class).setAction(ACTION_CANCEL));
    }

    @Override
    public void onCreate() {
        super.onCreate();
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        downloader = new MediaStoreDownloader(this);
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_CANCEL.equals(action)) {
            for (AtomicBoolean cancellation : activeCancellations) {
                cancellation.set(true);
            }
            if (activeRuns.get() == 0) {
                stopForegroundCompat();
                stopSelf(startId);
            }
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(action)) {
            stopSelf(startId);
            return START_NOT_STICKY;
        }

        startAsDataSyncForeground("正在准备素材下载", 0, 0, true);
        String jobId = intent.getStringExtra(EXTRA_JOB_ID);
        AtomicBoolean cancellation = new AtomicBoolean(false);
        activeCancellations.add(cancellation);
        activeRuns.incrementAndGet();
        worker.execute(() -> {
            try {
                runDownload(jobId, cancellation);
            } finally {
                activeCancellations.remove(cancellation);
                if (activeRuns.decrementAndGet() == 0) {
                    stopForegroundCompat();
                    stopSelf();
                }
            }
        });
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        for (AtomicBoolean cancellation : activeCancellations) {
            cancellation.set(true);
        }
        worker.shutdownNow();
        super.onDestroy();
    }

    @Override
    public void onTimeout(int startId, int fgsType) {
        for (AtomicBoolean cancellation : activeCancellations) {
            cancellation.set(true);
        }
        sendStatus(
                MediaDownloadContract.STATE_FAILED,
                "系统终止了超时的数据同步任务",
                null,
                null,
                0,
                0,
                0,
                null);
        stopForegroundCompat();
        stopSelf(startId);
    }

    private void runDownload(String jobId, AtomicBoolean cancellation) {
        MediaSelector.WorkPlan plan = DownloadJobStore.take(jobId);
        if (plan == null) {
            sendStatus(
                    MediaDownloadContract.STATE_FAILED,
                    "下载任务不存在、已使用或已过期",
                    null,
                    null,
                    0,
                    0,
                    0,
                    null);
            return;
        }

        List<AssetJob> jobs = createJobs(plan);
        if (jobs.isEmpty()) {
            String emptyDetail = plan.isGallery()
                    ? "图集共 " + plan.galleryItems.size() + " 项，但没有提取到可用图片或动效地址"
                    : "视频详情中没有可用播放地址";
            sendStatus(
                    MediaDownloadContract.STATE_FAILED,
                    emptyDetail,
                    plan.awemeId,
                    null,
                    0,
                    0,
                    0,
                    null);
            return;
        }

        sendStatus(
                MediaDownloadContract.STATE_STARTED,
                "已生成 " + jobs.size() + " 个本机保存任务",
                plan.awemeId,
                null,
                0,
                0,
                jobs.size(),
                null);

        int succeeded = 0;
        int failed = 0;
        int processed = 0;
        for (AssetJob job : jobs) {
            if (cancellation.get()) {
                sendStatus(
                        MediaDownloadContract.STATE_CANCELLED,
                        "下载已取消",
                        plan.awemeId,
                        job,
                        processed,
                        processed,
                        jobs.size(),
                        null);
                return;
            }

            sendStatus(
                    MediaDownloadContract.STATE_ITEM_STARTED,
                    job.label + "：开始下载",
                    plan.awemeId,
                    job,
                    processed,
                    processed,
                    jobs.size(),
                    null);
            updateNotification(job.label, processed, jobs.size(), false);

            ProgressReporter reporter = new ProgressReporter(
                    plan.awemeId,
                    job,
                    processed,
                    jobs.size());
            try {
                MediaStoreDownloader.Result result = downloader.download(
                        new MediaStoreDownloader.Request(job.mirrors, job.baseName, job.expectedKind),
                        cancellation,
                        reporter);
                succeeded++;
                processed++;
                sendStatus(
                        MediaDownloadContract.STATE_ITEM_SUCCEEDED,
                        job.label + "：已保存到 DCIM/抖音素材",
                        plan.awemeId,
                        job,
                        processed,
                        processed,
                        jobs.size(),
                        result);
            } catch (MediaStoreDownloader.DownloadFailure exception) {
                failed++;
                processed++;
                sendStatus(
                        MediaDownloadContract.STATE_ITEM_FAILED,
                        job.label + "：" + exception.getMessage(),
                        plan.awemeId,
                        job,
                        processed,
                        processed,
                        jobs.size(),
                        null);
            }
            updateNotification("已处理 " + processed + "/" + jobs.size(), processed, jobs.size(), false);
        }

        String state;
        String message;
        if (failed == 0) {
            state = MediaDownloadContract.STATE_COMPLETED;
            message = "全部 " + succeeded + " 个素材已保存";
        } else if (succeeded > 0) {
            state = MediaDownloadContract.STATE_PARTIAL;
            message = "已保存 " + succeeded + " 个，失败 " + failed + " 个";
        } else {
            state = MediaDownloadContract.STATE_FAILED;
            message = "全部 " + failed + " 个素材下载失败";
        }
        sendStatus(state, message, plan.awemeId, null, processed, processed, jobs.size(), null);
    }

    private List<AssetJob> createJobs(MediaSelector.WorkPlan plan) {
        List<AssetJob> jobs = new ArrayList<>();
        String workToken = plan.publishDate + "_" + plan.awemeId;
        if (!plan.isGallery()) {
            List<String> mirrors = MediaPlanUtils.bestCleanVideoMirrors(plan.videoCandidates);
            if (!mirrors.isEmpty()) {
                jobs.add(new AssetJob(
                        "video",
                        -1,
                        "视频",
                        workToken + "_video",
                        mirrors,
                        MediaStoreDownloader.ExpectedKind.VIDEO));
            }
            return jobs;
        }

        for (MediaSelector.GalleryItemPlan item : plan.galleryItems) {
            String itemToken = workToken + "_itemIndex_" + item.itemIndex;
            List<String> imageMirrors = MediaPlanUtils.cleanImageMirrors(item.imageCandidates);
            if (!imageMirrors.isEmpty()) {
                jobs.add(new AssetJob(
                        "gallery_still",
                        item.itemIndex,
                        "图片 " + (item.itemIndex + 1),
                        itemToken + "_still",
                        imageMirrors,
                        MediaStoreDownloader.ExpectedKind.STILL));
            }

            List<String> motionMirrors = MediaPlanUtils.bestCleanVideoMirrors(item.liveCandidates);
            if (!motionMirrors.isEmpty()) {
                jobs.add(new AssetJob(
                        "live_motion",
                        item.itemIndex,
                        "实况动效 " + (item.itemIndex + 1),
                        itemToken + "_motion",
                        motionMirrors,
                        MediaStoreDownloader.ExpectedKind.MOTION));
            }
        }
        return jobs;
    }

    private void sendStatus(
            String state,
            String message,
            String awemeId,
            AssetJob job,
            int itemOrdinal,
            int completed,
            int total,
            MediaStoreDownloader.Result result) {
        Intent status = new Intent(MediaDownloadContract.ACTION_STATUS)
                .setPackage(getPackageName())
                .putExtra(MediaDownloadContract.EXTRA_STATE, state)
                .putExtra(MediaDownloadContract.EXTRA_MESSAGE, message)
                .putExtra(MediaDownloadContract.EXTRA_AWEME_ID, awemeId)
                .putExtra(MediaDownloadContract.EXTRA_COMPLETED, completed)
                .putExtra(MediaDownloadContract.EXTRA_TOTAL, total);
        if (job != null) {
            status.putExtra(MediaDownloadContract.EXTRA_MEDIA_KIND, job.kind);
            status.putExtra(MediaDownloadContract.EXTRA_ITEM_INDEX, job.itemIndex);
        }
        if (result != null) {
            status.putExtra(MediaDownloadContract.EXTRA_URI, result.uri.toString());
            status.putExtra(MediaDownloadContract.EXTRA_SHA256, result.sha256);
            status.putExtra(MediaDownloadContract.EXTRA_FILE_NAME, result.displayName);
            status.putExtra(MediaDownloadContract.EXTRA_BYTES, result.bytes);
            status.putExtra(MediaDownloadContract.EXTRA_MIRROR_INDEX, result.mirrorIndex + 1);
        }
        boolean errorDetail = MediaDownloadContract.STATE_ITEM_FAILED.equals(state)
                || MediaDownloadContract.STATE_FAILED.equals(state);
        DownloadDiagnostics.record(this, state, message, awemeId, errorDetail);
        sendBroadcast(status, MediaDownloadContract.STATUS_PERMISSION);
    }

    private void sendProgress(
            String state,
            String message,
            String awemeId,
            AssetJob job,
            int completed,
            int total,
            long bytes,
            long contentLength,
            int mirrorIndex,
            int mirrorCount) {
        Intent status = new Intent(MediaDownloadContract.ACTION_STATUS)
                .setPackage(getPackageName())
                .putExtra(MediaDownloadContract.EXTRA_STATE, state)
                .putExtra(MediaDownloadContract.EXTRA_MESSAGE, message)
                .putExtra(MediaDownloadContract.EXTRA_AWEME_ID, awemeId)
                .putExtra(MediaDownloadContract.EXTRA_MEDIA_KIND, job.kind)
                .putExtra(MediaDownloadContract.EXTRA_ITEM_INDEX, job.itemIndex)
                .putExtra(MediaDownloadContract.EXTRA_COMPLETED, completed)
                .putExtra(MediaDownloadContract.EXTRA_TOTAL, total)
                .putExtra(MediaDownloadContract.EXTRA_BYTES, bytes)
                .putExtra(MediaDownloadContract.EXTRA_CONTENT_LENGTH, contentLength)
                .putExtra(MediaDownloadContract.EXTRA_MIRROR_INDEX, mirrorIndex)
                .putExtra(MediaDownloadContract.EXTRA_MIRROR_COUNT, mirrorCount);
        sendBroadcast(status, MediaDownloadContract.STATUS_PERMISSION);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "抖音素材下载",
                    NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("在本机流式保存原图和原视频");
            notificationManager.createNotificationChannel(channel);
        }
    }

    private void startAsDataSyncForeground(
            String message,
            int completed,
            int total,
            boolean indeterminate) {
        Notification notification = buildNotification(message, completed, total, indeterminate);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void updateNotification(String message, int completed, int total, boolean indeterminate) {
        // Updating through startForeground does not require POST_NOTIFICATIONS permission.
        startAsDataSyncForeground(message, completed, total, indeterminate);
    }

    private Notification buildNotification(
            String message,
            int completed,
            int total,
            boolean indeterminate) {
        PendingIntent openApp = PendingIntent.getActivity(
                this,
                0,
                new Intent(this, MainActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("抖音素材保存")
                .setContentText(message)
                .setContentIntent(openApp)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_PROGRESS);
        if (total > 0) {
            builder.setProgress(total, Math.min(completed, total), indeterminate);
        } else {
            builder.setProgress(0, 0, true);
        }
        return builder.build();
    }

    private void stopForegroundCompat() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE);
        } else {
            stopForeground(true);
        }
    }

    private final class ProgressReporter implements MediaStoreDownloader.ProgressCallback {
        private final String awemeId;
        private final AssetJob job;
        private final int completed;
        private final int total;
        private long lastUpdateEpochMs;
        private int mirrorIndex;
        private int mirrorCount;

        ProgressReporter(String awemeId, AssetJob job, int completed, int total) {
            this.awemeId = awemeId;
            this.job = job;
            this.completed = completed;
            this.total = total;
        }

        @Override
        public void onMirrorAttempt(int zeroBasedMirrorIndex, int count) {
            mirrorIndex = zeroBasedMirrorIndex + 1;
            mirrorCount = count;
            sendProgress(
                    MediaDownloadContract.STATE_MIRROR_RETRY,
                    job.label + "：尝试镜像 " + mirrorIndex + "/" + count,
                    awemeId,
                    job,
                    completed,
                    total,
                    0L,
                    -1L,
                    mirrorIndex,
                    mirrorCount);
        }

        @Override
        public void onProgress(long bytesWritten, long contentLength) {
            long now = System.currentTimeMillis();
            if (now - lastUpdateEpochMs < 500L
                    && (contentLength < 0L || bytesWritten != contentLength)) {
                return;
            }
            lastUpdateEpochMs = now;
            String progress = contentLength > 0L
                    ? String.format(Locale.US, "%s：%.1f%%", job.label,
                    (100.0 * bytesWritten) / contentLength)
                    : job.label + "：" + bytesWritten + " 字节";
            sendProgress(
                    MediaDownloadContract.STATE_PROGRESS,
                    progress,
                    awemeId,
                    job,
                    completed,
                    total,
                    bytesWritten,
                    contentLength,
                    mirrorIndex,
                    mirrorCount);
            updateNotification(progress, completed, total, total <= 0);
        }
    }

    private static final class AssetJob {
        final String kind;
        final int itemIndex;
        final String label;
        final String baseName;
        final List<String> mirrors;
        final MediaStoreDownloader.ExpectedKind expectedKind;

        AssetJob(
                String kind,
                int itemIndex,
                String label,
                String baseName,
                List<String> mirrors,
                MediaStoreDownloader.ExpectedKind expectedKind) {
            this.kind = kind;
            this.itemIndex = itemIndex;
            this.label = label;
            this.baseName = baseName;
            this.mirrors = mirrors;
            this.expectedKind = expectedKind;
        }
    }
}
