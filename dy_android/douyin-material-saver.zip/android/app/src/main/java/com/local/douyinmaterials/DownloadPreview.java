package com.local.douyinmaterials;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Immutable, display-only summary of what a confirmed download will save. */
public final class DownloadPreview {
    public final String awemeId;
    public final String title;
    public final String author;
    public final String kindLabel;
    public final boolean gallery;
    public final int assetCount;
    public final int liveItemCount;
    public final List<Item> items;

    private DownloadPreview(
            String awemeId,
            String title,
            String author,
            String kindLabel,
            boolean gallery,
            int assetCount,
            int liveItemCount,
            List<Item> items) {
        this.awemeId = awemeId;
        this.title = title;
        this.author = author;
        this.kindLabel = kindLabel;
        this.gallery = gallery;
        this.assetCount = assetCount;
        this.liveItemCount = liveItemCount;
        this.items = Collections.unmodifiableList(new ArrayList<>(items));
    }

    static DownloadPreview from(MediaSelector.WorkPlan plan) {
        if (plan == null) {
            throw new IllegalArgumentException("work plan is required");
        }
        List<Item> items = new ArrayList<>();
        int assetCount = 0;
        int liveItemCount = 0;

        if (!plan.isGallery()) {
            List<String> videoMirrors = MediaPlanUtils.bestCleanVideoMirrors(
                    plan.videoCandidates);
            if (!videoMirrors.isEmpty()) {
                MediaSelector.VideoCandidate video = MediaPlanUtils.bestCleanVideoCandidate(
                        plan.videoCandidates);
                items.add(new Item(
                        -1,
                        "视频",
                        MediaPlanUtils.firstCleanImageUrl(plan.previewImageCandidates),
                        Collections.singletonList(new Asset(
                                "视频",
                                video == null ? 0 : video.width,
                                video == null ? 0 : video.height,
                                video == null ? 0L : video.durationMs,
                                videoMirrors))));
                assetCount = 1;
            }
            return new DownloadPreview(
                    plan.awemeId,
                    plan.title,
                    plan.author,
                    "视频",
                    false,
                    assetCount,
                    0,
                    items);
        }

        for (MediaSelector.GalleryItemPlan galleryItem : plan.galleryItems) {
            List<String> stillMirrors = MediaPlanUtils.cleanImageMirrors(
                    galleryItem.imageCandidates);
            List<String> motionMirrors = MediaPlanUtils.bestCleanVideoMirrors(
                    galleryItem.liveCandidates);
            boolean hasStill = !stillMirrors.isEmpty();
            boolean hasMotion = !motionMirrors.isEmpty();
            if (!hasStill && !hasMotion) {
                continue;
            }

            int fileCount = (hasStill ? 1 : 0) + (hasMotion ? 1 : 0);
            assetCount += fileCount;
            if (hasMotion) {
                liveItemCount++;
            }
            MediaSelector.ImageCandidate still = firstCleanImageCandidate(
                    galleryItem.imageCandidates);
            MediaSelector.VideoCandidate motion = MediaPlanUtils.bestCleanVideoCandidate(
                    galleryItem.liveCandidates);
            String label = hasMotion
                    ? "实况 " + (galleryItem.itemIndex + 1)
                    : "图片 " + (galleryItem.itemIndex + 1);
            List<Asset> assets = new ArrayList<>();
            if (hasStill) {
                assets.add(new Asset(
                        "静态图",
                        still == null ? 0 : still.width,
                        still == null ? 0 : still.height,
                        -1L,
                        stillMirrors));
            }
            if (hasMotion) {
                assets.add(new Asset(
                        "动态视频",
                        motion == null ? 0 : motion.width,
                        motion == null ? 0 : motion.height,
                        motion == null ? 0L : motion.durationMs,
                        motionMirrors));
            }
            items.add(new Item(
                    galleryItem.itemIndex,
                    label,
                    hasStill ? stillMirrors.get(0) : null,
                    assets));
        }

        String kindLabel = liveItemCount == 0
                ? "图集"
                : liveItemCount == items.size() ? "实况图" : "图集（含实况）";
        return new DownloadPreview(
                plan.awemeId,
                plan.title,
                plan.author,
                kindLabel,
                true,
                assetCount,
                liveItemCount,
                items);
    }

    private static MediaSelector.ImageCandidate firstCleanImageCandidate(
            List<MediaSelector.ImageCandidate> candidates) {
        for (MediaSelector.ImageCandidate candidate : candidates) {
            if (!candidate.watermarked
                    && candidate.url != null
                    && !MediaSelector.isWatermarkedMediaUrl(candidate.url)) {
                return candidate;
            }
        }
        return null;
    }

    public static String formatBytes(long bytes) {
        if (bytes < 0L) {
            return "大小未知";
        }
        if (bytes < 1024L) {
            return bytes + "B";
        }
        double kib = bytes / 1024.0;
        if (kib < 1024.0) {
            return String.format(Locale.US, "%.1fKB", kib);
        }
        double mib = kib / 1024.0;
        if (mib < 1024.0) {
            return String.format(Locale.US, "%.1fMB", mib);
        }
        return String.format(Locale.US, "%.2fGB", mib / 1024.0);
    }

    public static String formatDuration(long durationMs) {
        if (durationMs <= 0L) {
            return "时长未知";
        }
        long totalSeconds = Math.max(1L, (durationMs + 500L) / 1000L);
        long hours = totalSeconds / 3600L;
        long minutes = (totalSeconds % 3600L) / 60L;
        long seconds = totalSeconds % 60L;
        return hours > 0L
                ? String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
                : String.format(Locale.US, "%02d:%02d", minutes, seconds);
    }

    public static final class Item {
        public final int galleryItemIndex;
        public final String label;
        public final String previewImageUrl;
        public final int assetCount;
        public final List<Asset> assets;

        Item(
                int galleryItemIndex,
                String label,
                String previewImageUrl,
                List<Asset> assets) {
            this.galleryItemIndex = galleryItemIndex;
            this.label = label;
            this.previewImageUrl = previewImageUrl;
            this.assets = Collections.unmodifiableList(new ArrayList<>(assets));
            this.assetCount = this.assets.size();
        }
    }

    public static final class Asset {
        public final String label;
        public final int width;
        public final int height;
        public final long durationMs;
        public final List<String> mirrors;

        Asset(
                String label,
                int width,
                int height,
                long durationMs,
                List<String> mirrors) {
            this.label = label;
            this.width = width;
            this.height = height;
            this.durationMs = durationMs;
            this.mirrors = Collections.unmodifiableList(new ArrayList<>(mirrors));
        }

        public String dimensionText() {
            return width > 0 && height > 0 ? width + "×" + height : "尺寸未知";
        }

        public boolean hasDurationField() {
            return durationMs >= 0L;
        }
    }
}
