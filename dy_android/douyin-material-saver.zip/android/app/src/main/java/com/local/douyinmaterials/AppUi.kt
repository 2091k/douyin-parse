package com.local.douyinmaterials

import android.animation.ValueAnimator
import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowInsetsController
import android.view.WindowManager
import android.webkit.WebView
import androidx.activity.compose.BackHandler
import androidx.activity.ComponentDialog
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.zIndex
import kotlinx.coroutines.Job
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import java.util.LinkedHashSet
import kotlin.math.abs
import kotlin.math.roundToInt

private class AutoFitWebViewContainer(
    context: Context,
    private val webView: WebView,
) : ViewGroup(context) {
    private var contentScale = 1f

    init {
        clipChildren = true
        webView.pivotX = 0f
        webView.pivotY = 0f
        addView(webView)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = MeasureSpec.getSize(widthMeasureSpec)
        val height = MeasureSpec.getSize(heightMeasureSpec)
        val widthDp = width / resources.displayMetrics.density
        contentScale = (widthDp / 600f).coerceIn(0.70f, 1f)
        webView.scaleX = contentScale
        webView.scaleY = contentScale
        setMeasuredDimension(
            resolveSize(width, widthMeasureSpec),
            resolveSize(height, heightMeasureSpec),
        )
        val childWidth = (width / contentScale).roundToInt()
        val childHeight = (height / contentScale).roundToInt()
        getChildAt(0).measure(
            MeasureSpec.makeMeasureSpec(childWidth, MeasureSpec.EXACTLY),
            MeasureSpec.makeMeasureSpec(childHeight, MeasureSpec.EXACTLY),
        )
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        val child = getChildAt(0)
        child.layout(0, 0, child.measuredWidth, child.measuredHeight)
    }
}

enum class UiTone {
    NEUTRAL,
    PRIMARY,
    SUCCESS,
    ERROR,
}

@Stable
class HomeUiState {
    var inputText by mutableStateOf("")
    var stepText by mutableStateOf("在抖音复制分享链接，然后粘贴解析")
    var stepTone by mutableStateOf(UiTone.NEUTRAL)
    var pageText by mutableStateOf("页面路径：—")
    var awemeText by mutableStateOf("作品 ID：未识别")
    var awemeTone by mutableStateOf(UiTone.NEUTRAL)
    var captureText by mutableStateOf("媒体信息：尚未解析")
    var captureTone by mutableStateOf(UiTone.NEUTRAL)
    var downloadText by mutableStateOf("下载：尚未开始")
    var downloadTone by mutableStateOf(UiTone.NEUTRAL)
    var storageText by mutableStateOf("保存位置：相册 / DCIM / 抖音素材")
    var historyText by mutableStateOf("上次结果：暂无")
    var isParsing by mutableStateOf(false)
    var verificationRequired by mutableStateOf(false)
    var verificationVisible by mutableStateOf(false)
    var verificationMessage by mutableStateOf(
        "请在抖音页面完成验证码或登录，完成后会自动继续解析",
    )

    fun beginBackgroundParse() {
        isParsing = false
        verificationRequired = false
        verificationVisible = false
    }

    fun requestVerification(message: String) {
        isParsing = false
        verificationRequired = true
        verificationMessage = message
    }

    fun showVerification() {
        if (verificationRequired) {
            verificationVisible = true
        }
    }

    fun hideVerification() {
        verificationVisible = false
    }

    fun completeVerification() {
        isParsing = false
        verificationRequired = false
        verificationVisible = false
    }
}

interface HomeUiCallbacks {
    fun onPasteAndParse()
    fun onParse(text: String)
    fun onShowVerification()
    fun onHideVerification()
    fun onRetryVerification()
}

fun installAppHome(
    composeView: ComposeView,
    state: HomeUiState,
    webView: WebView,
    callbacks: HomeUiCallbacks,
) {
    composeView.setViewCompositionStrategy(
        ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed,
    )
    composeView.setContent {
        AppTheme {
            AppHomeScreen(state, webView, callbacks)
        }
    }
}

@Composable
private fun AppTheme(content: @Composable () -> Unit) {
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    val colors = if (dark) {
        darkColorScheme(
            primary = AccentBlueDark,
            background = DarkBackground,
            surface = DarkSurface,
            onPrimary = Color.White,
            onBackground = DarkText,
            onSurface = DarkText,
        )
    } else {
        lightColorScheme(
            primary = AccentBlue,
            background = LightBackground,
            surface = LightSurface,
            onPrimary = Color.White,
            onBackground = LightText,
            onSurface = LightText,
        )
    }
    MaterialTheme(colorScheme = colors) {
        // Background modifiers do not provide a LocalContentColor. Without an explicit
        // value, Text instances that rely on inheritance fall back to black in dark mode.
        CompositionLocalProvider(LocalContentColor provides colors.onBackground) {
            content()
        }
    }
}

@Composable
private fun AppHomeScreen(
    state: HomeUiState,
    webView: WebView,
    callbacks: HomeUiCallbacks,
) {
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val inputFocusRequester = remember { FocusRequester() }
    val homeScrollState = rememberScrollState()
    val backgroundBrush = if (dark) {
        Brush.verticalGradient(listOf(Color(0xFF08090B), Color(0xFF15171C)))
    } else {
        Brush.verticalGradient(listOf(Color(0xFFF7F8FC), Color(0xFFEFF2F8)))
    }
    var diagnosticsExpanded by remember { mutableStateOf(false) }
    var inputFocused by remember { mutableStateOf(false) }
    var rootCoordinates by remember { mutableStateOf<LayoutCoordinates?>(null) }
    var inputBoundsInWindow by remember { mutableStateOf<Rect?>(null) }

    fun finishTextInput() {
        focusManager.clearFocus(force = true)
        keyboardController?.hide()
    }

    LaunchedEffect(inputFocused) {
        if (inputFocused) {
            androidx.compose.runtime.withFrameNanos { }
            keyboardController?.show()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundBrush),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
            .onGloballyPositioned { rootCoordinates = it }
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        val down = event.changes.firstOrNull {
                            it.pressed && !it.previousPressed
                        } ?: continue
                        val windowPosition = rootCoordinates?.localToWindow(down.position)
                            ?: continue
                        val inputBounds = inputBoundsInWindow
                        if (inputBounds == null || !inputBounds.contains(windowPosition)) {
                            finishTextInput()
                        }
                    }
                }
            }
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .imePadding()
            .verticalScroll(homeScrollState)
            .padding(horizontal = 18.dp),
        ) {
        Spacer(Modifier.height(10.dp))
        Text(
            text = "抖音素材保存",
            style = TextStyle(
                fontSize = 30.sp,
                lineHeight = 34.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.sp,
            ),
            color = MaterialTheme.colorScheme.onBackground,
        )
        Text(
            text = "先预览，再把最高可用素材保存到本机相册",
            modifier = Modifier.padding(top = 3.dp, bottom = 14.dp),
            fontSize = 14.sp,
            lineHeight = 20.sp,
            color = secondaryTextColor(dark),
        )

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(AccentBlue.copy(alpha = 0.12f), CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("↓", color = AccentBlue, fontSize = 25.sp, fontWeight = FontWeight.SemiBold)
                }
                Column(modifier = Modifier.padding(start = 12.dp)) {
                    Text(
                        text = "粘贴抖音分享内容",
                        fontSize = 17.sp,
                        lineHeight = 22.sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        text = "链接只用于本机解析，不会上传到第三方服务",
                        modifier = Modifier.padding(top = 2.dp),
                        fontSize = 12.sp,
                        lineHeight = 17.sp,
                        color = secondaryTextColor(dark),
                    )
                }
            }

            val inputTextStyle = TextStyle(
                color = MaterialTheme.colorScheme.onSurface,
                fontSize = 14.sp,
                lineHeight = 18.sp,
            )
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 14.dp)
                    .background(
                        if (dark) Color.White.copy(alpha = 0.07f) else Color.Black.copy(alpha = 0.045f),
                        RoundedCornerShape(14.dp),
                    )
                    .onGloballyPositioned { inputBoundsInWindow = it.boundsInWindow() }
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false)
                            inputFocusRequester.requestFocus()
                            keyboardController?.show()
                        }
                    },
            ) {
                BasicTextField(
                    value = state.inputText,
                    onValueChange = { state.inputText = it.take(16_384) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(inputFocusRequester)
                        .onFocusChanged { inputFocused = it.isFocused }
                        .padding(horizontal = 13.dp, vertical = 11.dp),
                    textStyle = inputTextStyle,
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                    maxLines = 2,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Uri,
                        imeAction = ImeAction.Done,
                    ),
                    keyboardActions = KeyboardActions(onDone = { finishTextInput() }),
                    decorationBox = { inner ->
                        Box {
                            if (state.inputText.isEmpty()) {
                                Text(
                                    "抖音分享文案或 douyin.com 链接",
                                    style = inputTextStyle.copy(color = secondaryTextColor(dark)),
                                )
                            }
                            inner()
                        }
                    },
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                PressButton(
                    text = "粘贴并解析",
                    modifier = Modifier.weight(1f),
                    primary = true,
                    onClick = {
                        finishTextInput()
                        callbacks.onPasteAndParse()
                    },
                )
                PressButton(
                    text = "解析输入",
                    modifier = Modifier.weight(1f),
                    primary = false,
                    enabled = state.inputText.isNotBlank(),
                    onClick = {
                        finishTextInput()
                        callbacks.onParse(state.inputText)
                    },
                )
            }
        }

        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp),
            contentPadding = 13,
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ToneDot(state.stepTone, state.isParsing)
                Column(modifier = Modifier.weight(1f).padding(start = 9.dp)) {
                    Text(
                        text = state.stepText.removePrefix("步骤："),
                        fontSize = 14.sp,
                        lineHeight = 19.sp,
                        fontWeight = FontWeight.Medium,
                        color = toneColor(state.stepTone, dark),
                        maxLines = if (diagnosticsExpanded) 4 else 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = state.downloadText,
                        modifier = Modifier.padding(top = 2.dp),
                        fontSize = 12.sp,
                        lineHeight = 17.sp,
                        color = toneColor(state.downloadTone, dark),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                TextAction(
                    text = if (diagnosticsExpanded) "收起" else "详情",
                    onClick = { diagnosticsExpanded = !diagnosticsExpanded },
                )
            }
            AnimatedVisibility(visible = diagnosticsExpanded) {
                Column(modifier = Modifier.padding(top = 11.dp)) {
                    DiagnosticLine(state.pageText)
                    DiagnosticLine(state.awemeText, state.awemeTone)
                    DiagnosticLine(state.captureText, state.captureTone)
                    DiagnosticLine(state.storageText)
                    DiagnosticLine(state.historyText)
                }
            }
            AnimatedVisibility(visible = state.verificationRequired) {
                PressButton(
                    text = "完成验证",
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 11.dp),
                    primary = true,
                    onClick = callbacks::onShowVerification,
                )
            }
        }

            Spacer(Modifier.height(18.dp))
        }

        VerificationBrowserLayer(
            visible = state.verificationVisible,
            message = state.verificationMessage,
            webView = webView,
            onClose = callbacks::onHideVerification,
            onRetry = callbacks::onRetryVerification,
        )
    }
}

@Composable
private fun VerificationBrowserLayer(
    visible: Boolean,
    message: String,
    webView: WebView,
    onClose: () -> Unit,
    onRetry: () -> Unit,
) {
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    BackHandler(enabled = visible, onBack = onClose)

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .zIndex(if (visible) 10f else -1f)
            .graphicsLayer { alpha = if (visible) 1f else 0f }
            .background(Color.Black.copy(alpha = if (dark) 0.58f else 0.32f))
            .padding(horizontal = 14.dp, vertical = 18.dp),
        contentAlignment = Alignment.Center,
    ) {
        val browserHeight = (maxHeight - 170.dp).coerceIn(160.dp, 620.dp)
        Column(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxWidth()
                .heightIn(max = maxHeight)
                .shadow(24.dp, RoundedCornerShape(24.dp))
                .background(
                    if (dark) Color(0xFF202124) else Color(0xFFF9F9FB),
                    RoundedCornerShape(24.dp),
                )
                .border(
                    0.7.dp,
                    if (dark) Color.White.copy(alpha = 0.12f) else Color.White.copy(alpha = 0.9f),
                    RoundedCornerShape(24.dp),
                )
                .padding(14.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "完成验证",
                        fontSize = 19.sp,
                        lineHeight = 24.sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        message,
                        modifier = Modifier.padding(top = 3.dp, end = 8.dp),
                        fontSize = 12.sp,
                        lineHeight = 17.sp,
                        color = secondaryTextColor(dark),
                    )
                }
                TextAction("关闭", onClose)
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(browserHeight)
                    .padding(top = 12.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (dark) Color(0xFF1C1C1E) else Color.White),
            ) {
                AndroidView(
                    factory = { context -> AutoFitWebViewContainer(context, webView) },
                    update = { container ->
                        container.alpha = if (visible) 1f else 0f
                        container.isEnabled = visible
                        webView.isEnabled = visible
                    },
                    modifier = Modifier.fillMaxSize(),
                )
            }

            PressButton(
                text = "重试解析",
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 11.dp),
                primary = true,
                onClick = onRetry,
            )
        }
    }
}

@Composable
private fun GlassCard(
    modifier: Modifier = Modifier,
    contentPadding: Int = 16,
    content: @Composable ColumnScope.() -> Unit,
) {
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    Column(
        modifier = modifier
            .shadow(12.dp, RoundedCornerShape(22.dp), ambientColor = Color.Black.copy(alpha = 0.08f))
            .background(
                if (dark) Color(0xE626272B) else Color(0xEFFFFFFF),
                RoundedCornerShape(22.dp),
            )
            .border(
                0.7.dp,
                if (dark) Color.White.copy(alpha = 0.10f) else Color.White.copy(alpha = 0.88f),
                RoundedCornerShape(22.dp),
            )
            .padding(contentPadding.dp),
        content = content,
    )
}

@Composable
private fun PressButton(
    text: String,
    modifier: Modifier = Modifier,
    primary: Boolean,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale = remember { Animatable(1f) }
    val motionEnabled = ValueAnimator.areAnimatorsEnabled()
    LaunchedEffect(pressed, enabled, motionEnabled) {
        if (!enabled) {
            scale.snapTo(1f)
        } else if (pressed) {
            scale.stop()
            scale.snapTo(0.97f)
        } else if (motionEnabled) {
            scale.animateTo(
                1f,
                spring(dampingRatio = 1f, stiffness = 1200f),
            )
        } else {
            scale.snapTo(1f)
        }
    }
    Box(
        modifier = modifier
            .height(48.dp)
            .graphicsLayer {
                scaleX = scale.value
                scaleY = scale.value
                alpha = if (enabled) 1f else 0.45f
            }
            .background(
                if (primary) AccentBlue else if (dark) Color.White.copy(alpha = 0.09f) else Color.Black.copy(alpha = 0.055f),
                RoundedCornerShape(14.dp),
            )
            .clickable(
                enabled = enabled,
                interactionSource = interaction,
                indication = null,
                role = Role.Button,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text,
            color = if (primary) Color.White else MaterialTheme.colorScheme.onSurface,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

@Composable
private fun TextAction(text: String, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    Text(
        text = text,
        modifier = Modifier
            .graphicsLayer {
                scaleX = if (pressed) 0.96f else 1f
                scaleY = if (pressed) 0.96f else 1f
            }
            .clip(RoundedCornerShape(12.dp))
            .clickable(
                interactionSource = interaction,
                indication = null,
                role = Role.Button,
                onClick = onClick,
            )
            .padding(horizontal = 10.dp, vertical = 8.dp),
        color = AccentBlue,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
    )
}

@Composable
private fun ToneDot(tone: UiTone, loading: Boolean) {
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    val animationsEnabled = Build.VERSION.SDK_INT < 26 || ValueAnimator.areAnimatorsEnabled()
    val animatedScale = remember { Animatable(1f) }
    val animatedAlpha = remember { Animatable(1f) }
    val breathing = loading && animationsEnabled

    LaunchedEffect(breathing) {
        if (!breathing) {
            animatedScale.snapTo(1f)
            animatedAlpha.snapTo(1f)
            return@LaunchedEffect
        }
        while (true) {
            coroutineScope {
                launch {
                    animatedScale.animateTo(
                        0.82f,
                        tween(600, easing = FastOutSlowInEasing),
                    )
                }
                launch {
                    animatedAlpha.animateTo(
                        0.45f,
                        tween(600, easing = FastOutSlowInEasing),
                    )
                }
            }
            coroutineScope {
                launch {
                    animatedScale.animateTo(
                        1f,
                        tween(600, easing = FastOutSlowInEasing),
                    )
                }
                launch {
                    animatedAlpha.animateTo(
                        1f,
                        tween(600, easing = FastOutSlowInEasing),
                    )
                }
            }
        }
    }

    Box(
        Modifier
            .size(9.dp)
            .graphicsLayer {
                scaleX = animatedScale.value
                scaleY = animatedScale.value
                alpha = animatedAlpha.value
            }
            .background(
                if (loading) MaterialTheme.colorScheme.primary else toneColor(tone, dark),
                CircleShape,
            ),
    )
}

@Composable
private fun DiagnosticLine(text: String, tone: UiTone = UiTone.NEUTRAL) {
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    Text(
        text = text,
        modifier = Modifier.padding(vertical = 2.dp),
        color = toneColor(tone, dark),
        fontSize = 11.sp,
        lineHeight = 16.sp,
    )
}

@Stable
class AppPreviewState(preview: DownloadPreview) {
    val awemeId: String = preview.awemeId
    val title: String = preview.title
    val author: String = preview.author
    val kindLabel: String = preview.kindLabel
    val gallery: Boolean = preview.gallery
    val items: List<AppPreviewItemState> = preview.items.map(::AppPreviewItemState)

    fun selectedGalleryIndexes(): Set<Int> {
        val result = LinkedHashSet<Int>()
        for (item in items) {
            if (item.selected && item.galleryItemIndex >= 0) {
                result.add(item.galleryItemIndex)
            }
        }
        return result
    }

    fun selectedItemCount(): Int = items.count { it.selected }

    fun selectedFileCount(): Int = items.filter { it.selected }.sumOf { it.assets.size }

    fun summaryText(): String {
        val selected = items.filter { it.selected }
        val sizes = selected.flatMap { it.assetSizes }
        val pending = sizes.count { it == AppPreviewItemState.SIZE_PENDING }
        val unknown = sizes.count { it < 0L && it != AppPreviewItemState.SIZE_PENDING }
        val known = sizes.filter { it >= 0L }.sum()
        return buildString {
            append(kindLabel)
            append(" · 已选 ")
            append(selected.size)
            append('/')
            append(items.size)
            append(" 项 · ")
            append(selectedFileCount())
            append(" 个文件")
            when {
                sizes.isEmpty() -> Unit
                pending > 0 -> append(" · 大小读取中…")
                unknown == 0 -> append(" · 预计 ${DownloadPreview.formatBytes(known)}")
                known > 0L -> append(" · 已知 ${DownloadPreview.formatBytes(known)} + $unknown 个未知")
                else -> append(" · 大小未知")
            }
        }
    }

    fun setAllSelected(selected: Boolean) {
        items.forEach { it.selected = selected }
    }
}

@Stable
class AppPreviewItemState(private val item: DownloadPreview.Item) {
    companion object {
        const val SIZE_PENDING: Long = Long.MIN_VALUE
    }

    val galleryItemIndex: Int = item.galleryItemIndex
    val label: String = item.label
    val previewImageUrl: String? = item.previewImageUrl
    val assets: List<DownloadPreview.Asset> = item.assets
    val assetSizes = mutableStateListOf<Long>().apply {
        repeat(item.assets.size) { add(SIZE_PENDING) }
    }
    var selected by mutableStateOf(true)
    var bitmap by mutableStateOf<Bitmap?>(null)

    fun setAssetSize(index: Int, size: Long) {
        if (index in assetSizes.indices) {
            assetSizes[index] = size
        }
    }

    fun detailText(): String = buildString {
        assets.forEachIndexed { index, asset ->
            if (index > 0) append('\n')
            append(asset.label)
            append(" · ")
            append(asset.dimensionText())
            if (asset.hasDurationField()) {
                append(" · ")
                append(DownloadPreview.formatDuration(asset.durationMs))
            }
            append(" · ")
            append(
                if (assetSizes[index] == SIZE_PENDING) {
                    "大小读取中…"
                } else {
                    DownloadPreview.formatBytes(assetSizes[index])
                },
            )
        }
    }
}

interface AppPreviewCallbacks {
    fun onSave(selectedIndexes: Set<Int>)
    fun onCancel()
    fun onDismissed()
}

@Suppress("DEPRECATION")
fun showAppPreviewDialog(
    activity: Activity,
    state: AppPreviewState,
    callbacks: AppPreviewCallbacks,
): Dialog {
    val dialog = ComponentDialog(activity, android.R.style.Theme_Material_NoActionBar)
    val composeView = ComposeView(activity)
    composeView.setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
    composeView.setContent {
        AppTheme {
            AppPreviewOverlay(
                state = state,
                backgroundWindow = dialog.window,
                onSave = { callbacks.onSave(state.selectedGalleryIndexes()) },
                onCancel = {
                    callbacks.onCancel()
                    dialog.dismiss()
                },
            )
        }
    }
    dialog.setContentView(
        composeView,
        ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
        ),
    )
    dialog.setCancelable(false)
    dialog.setCanceledOnTouchOutside(false)
    dialog.setOnDismissListener { callbacks.onDismissed() }
    dialog.window?.apply {
        setBackgroundDrawable(ColorDrawable(AndroidColor.TRANSPARENT))
        clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        statusBarColor = AndroidColor.TRANSPARENT
        navigationBarColor = AndroidColor.TRANSPARENT
        configureSystemBarAppearance(
            this,
            (activity.resources.configuration.uiMode and
                Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES,
        )
        if (Build.VERSION.SDK_INT >= 31) {
            addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
            val params = attributes
            params.setBlurBehindRadius(0)
            attributes = params
        }
    }
    dialog.show()
    dialog.window?.setLayout(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.MATCH_PARENT,
    )
    return dialog
}

@Suppress("DEPRECATION")
private fun configureSystemBarAppearance(window: Window, dark: Boolean) {
    val lightFlags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
        View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
    if (Build.VERSION.SDK_INT >= 30) {
        val mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
            WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        window.insetsController?.setSystemBarsAppearance(if (dark) 0 else mask, mask)
    } else {
        window.decorView.systemUiVisibility = if (dark) {
            window.decorView.systemUiVisibility and lightFlags.inv()
        } else {
            window.decorView.systemUiVisibility or lightFlags
        }
    }
}

@Composable
private fun AppPreviewOverlay(
    state: AppPreviewState,
    backgroundWindow: Window?,
    onSave: () -> Unit,
    onCancel: () -> Unit,
) {
    val density = LocalDensity.current
    val context = LocalContext.current
    val motionEnabled = remember(context) { ValueAnimator.areAnimatorsEnabled() }
    val scope = rememberCoroutineScope()
    val offset = remember { Animatable(10_000f) }
    val screenHeight = with(density) {
        context.resources.displayMetrics.heightPixels.toFloat()
    }
    val sheetHeight = screenHeight * 0.92f
    val expandedAnchor = 0f
    val halfAnchor = sheetHeight * 0.37f
    val hiddenAnchor = sheetHeight + with(density) { 40.dp.toPx() }
    val preferredAnchor = if (state.items.size > 3) expandedAnchor else halfAnchor
    val visibleSheetHeight = with(density) {
        (sheetHeight - offset.value).coerceIn(0f, sheetHeight).toDp()
    }
    var closeRequested by remember { mutableStateOf(false) }

    fun closeSheet() {
        if (closeRequested) return
        closeRequested = true
        scope.launch {
            if (motionEnabled) {
                offset.animateTo(
                    hiddenAnchor,
                    spring(dampingRatio = 0.86f, stiffness = 520f),
                )
            } else {
                offset.snapTo(hiddenAnchor)
            }
            onCancel()
        }
    }

    BackHandler(onBack = ::closeSheet)
    LaunchedEffect(sheetHeight, motionEnabled, preferredAnchor) {
        offset.snapTo(hiddenAnchor)
        if (motionEnabled) {
            offset.animateTo(
                preferredAnchor,
                spring(dampingRatio = 0.82f, stiffness = 480f),
            )
        } else {
            offset.snapTo(preferredAnchor)
        }
    }

    val progress = ((offset.value - expandedAnchor) / (hiddenAnchor - expandedAnchor))
        .coerceIn(0f, 1f)
    val materialProgress = 1f - progress
    val scrimAlpha = 0.34f * materialProgress

    if (Build.VERSION.SDK_INT >= 31) {
        SideEffect {
            backgroundWindow?.let { window ->
                val params = window.attributes
                params.setBlurBehindRadius((28f * materialProgress).roundToInt())
                window.attributes = params
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = scrimAlpha))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = ::closeSheet,
                ),
        )

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(visibleSheetHeight)
                .shadow(28.dp, RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .background(
                    MaterialTheme.colorScheme.surface.copy(alpha = 0.97f),
                    RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
                )
                .border(
                    0.7.dp,
                    Color.White.copy(alpha = 0.26f),
                    RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
                ),
        ) {
            PreviewDragHeader(
                state = state,
                modifier = Modifier
                    .fillMaxWidth()
                    .fluidVerticalDrag(
                        offset = offset,
                        expandedAnchor = expandedAnchor,
                        halfAnchor = halfAnchor,
                        hiddenAnchor = hiddenAnchor,
                        motionEnabled = motionEnabled,
                        onDismissed = onCancel,
                    ),
                onClose = ::closeSheet,
            )

            PreviewList(
                state = state,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
            )

            PreviewActionBar(
                state = state,
                onSave = onSave,
            )
        }
    }
}

@Composable
private fun PreviewActionBar(
    state: AppPreviewState,
    onSave: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 8.dp)
            .windowInsetsPadding(WindowInsets.navigationBars),
    ) {
        Text(
            state.summaryText(),
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.62f),
            fontSize = 12.sp,
            lineHeight = 17.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        PressButton(
            text = if (state.gallery) {
                "保存所选（${state.selectedItemCount()}）"
            } else {
                "保存到相册"
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 6.dp),
            primary = true,
            enabled = state.selectedItemCount() > 0,
            onClick = onSave,
        )
    }
}

@Composable
private fun PreviewDragHeader(
    state: AppPreviewState,
    modifier: Modifier,
    onClose: () -> Unit,
) {
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    Column(modifier = modifier.padding(horizontal = 18.dp, vertical = 10.dp)) {
        Box(
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .width(38.dp)
                .height(5.dp)
                .background(
                    MaterialTheme.colorScheme.onSurface.copy(alpha = 0.20f),
                    RoundedCornerShape(99.dp),
                ),
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp),
            verticalAlignment = Alignment.Top,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    "下载预览",
                    fontSize = 24.sp,
                    lineHeight = 29.sp,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    state.title,
                    modifier = Modifier.padding(top = 4.dp),
                    fontSize = 15.sp,
                    lineHeight = 20.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    "${state.author} · ${state.kindLabel}",
                    modifier = Modifier.padding(top = 2.dp),
                    color = secondaryTextColor(dark),
                    fontSize = 12.sp,
                )
            }
            TextAction("取消", onClose)
        }
        if (state.gallery) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "轻点卡片选择；实况图会成组保存",
                    color = secondaryTextColor(dark),
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                )
                TextAction(
                    if (state.items.all { it.selected }) "取消全选" else "全选",
                ) {
                    state.setAllSelected(!state.items.all { it.selected })
                }
            }
        }
    }
}

@Composable
private fun PreviewList(
    state: AppPreviewState,
    modifier: Modifier = Modifier,
) {
    LazyColumn(
        modifier = modifier,
        contentPadding = androidx.compose.foundation.layout.PaddingValues(
            start = 18.dp,
            end = 18.dp,
            top = 4.dp,
            bottom = 12.dp,
        ),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        items(state.items, key = { it.galleryItemIndex }) { item ->
            PreviewItemCard(item, selectable = state.gallery)
        }
        item {
            Text(
                "作品 ID：${state.awemeId}",
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp),
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.42f),
                fontSize = 10.sp,
            )
        }
    }
}

@Composable
private fun PreviewItemCard(item: AppPreviewItemState, selectable: Boolean) {
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale = remember { Animatable(1f) }
    LaunchedEffect(pressed) {
        if (pressed) {
            scale.stop()
            scale.snapTo(0.975f)
        } else if (ValueAnimator.areAnimatorsEnabled()) {
            scale.animateTo(1f, spring(dampingRatio = 1f, stiffness = 1050f))
        } else {
            scale.snapTo(1f)
        }
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                scaleX = scale.value
                scaleY = scale.value
                alpha = if (item.selected) 1f else 0.54f
            }
            .background(
                if (dark) Color.White.copy(alpha = 0.07f) else Color.Black.copy(alpha = 0.035f),
                RoundedCornerShape(18.dp),
            )
            .border(
                if (item.selected) 1.2.dp else 0.7.dp,
                if (item.selected) AccentBlue.copy(alpha = 0.72f)
                else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f),
                RoundedCornerShape(18.dp),
            )
            .clickable(
                enabled = selectable,
                interactionSource = interaction,
                indication = null,
                role = Role.Checkbox,
            ) { item.selected = !item.selected }
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(82.dp)
                .clip(RoundedCornerShape(13.dp))
                .background(if (dark) Color(0xFF303238) else Color(0xFFE6EAF0)),
            contentAlignment = Alignment.Center,
        ) {
            val bitmap = item.bitmap
            if (bitmap != null && !bitmap.isRecycled) {
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = "${item.label}预览图",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                )
            } else {
                Text("预览", color = secondaryTextColor(dark), fontSize = 12.sp)
            }
            if (selectable) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .size(23.dp)
                        .background(
                            if (item.selected) AccentBlue else Color.Black.copy(alpha = 0.32f),
                            CircleShape,
                        )
                        .border(1.dp, Color.White.copy(alpha = 0.76f), CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    if (item.selected) {
                        Text("✓", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(item.label, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(
                item.detailText(),
                modifier = Modifier.padding(top = 4.dp),
                color = secondaryTextColor(dark),
                fontSize = 11.sp,
                lineHeight = 16.sp,
            )
        }
    }
}

private fun Modifier.fluidVerticalDrag(
    offset: Animatable<Float, *>,
    expandedAnchor: Float,
    halfAnchor: Float,
    hiddenAnchor: Float,
    motionEnabled: Boolean,
    onDismissed: () -> Unit,
): Modifier = pointerInput(expandedAnchor, halfAnchor, hiddenAnchor, motionEnabled) {
    coroutineScope {
        var settleJob: Job? = null
        var dragUpdateJob: Job? = null
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            // Keep the release spring running while we wait for the next gesture. Only a
            // real pointer-down should interrupt it and take over from its live position.
            settleJob?.cancel()
            dragUpdateJob?.cancel()
            val tracker = VelocityTracker()
            var moved = false
            tracker.addPosition(down.uptimeMillis, down.position)
            drag(down.id) { change ->
                val delta = change.positionChange().y
                if (abs(delta) > 0.5f) {
                    moved = true
                }
                tracker.addPosition(change.uptimeMillis, change.position)
                val proposed = offset.value + delta
                val adjusted = when {
                    proposed < expandedAnchor -> expandedAnchor - rubberBand(
                        expandedAnchor - proposed,
                        180f,
                    )
                    proposed > hiddenAnchor -> hiddenAnchor + rubberBand(
                        proposed - hiddenAnchor,
                        120f,
                    )
                    else -> proposed
                }
                dragUpdateJob?.cancel()
                dragUpdateJob = launch(start = CoroutineStart.UNDISPATCHED) {
                    offset.snapTo(adjusted)
                }
                change.consume()
            }
            if (!moved) {
                return@awaitEachGesture
            }
            val velocity = tracker.calculateVelocity().y
            val projected = offset.value + projectMomentum(velocity)
            val allowDismiss = projected > halfAnchor + (hiddenAnchor - halfAnchor) * 0.38f ||
                velocity > 1_250f
            val candidateAnchors = if (allowDismiss) {
                listOf(expandedAnchor, halfAnchor, hiddenAnchor)
            } else {
                listOf(expandedAnchor, halfAnchor)
            }
            val target = candidateAnchors.minBy { abs(projected - it) }
            settleJob = launch {
                if (motionEnabled) {
                    offset.animateTo(
                        target,
                        spring(dampingRatio = 0.82f, stiffness = 500f),
                        initialVelocity = velocity,
                    )
                } else {
                    offset.snapTo(target)
                }
                if (target == hiddenAnchor) {
                    onDismissed()
                }
            }
        }
    }
}

private fun rubberBand(overshoot: Float, dimension: Float, constant: Float = 0.55f): Float {
    return (overshoot * dimension * constant) / (dimension + constant * abs(overshoot))
}

private fun projectMomentum(velocityPixelsPerSecond: Float, decelerationRate: Float = 0.998f): Float {
    return (velocityPixelsPerSecond / 1000f) * decelerationRate / (1f - decelerationRate)
}

@Composable
private fun secondaryTextColor(dark: Boolean): Color {
    return if (dark) Color(0xFFAEB0B7) else Color(0xFF6E6E73)
}

@Composable
private fun toneColor(tone: UiTone, dark: Boolean): Color = when (tone) {
    UiTone.PRIMARY -> if (dark) AccentBlueDark else AccentBlue
    UiTone.SUCCESS -> if (dark) Color(0xFF30D158) else Color(0xFF168B47)
    UiTone.ERROR -> if (dark) Color(0xFFFF6961) else Color(0xFFC9342C)
    UiTone.NEUTRAL -> if (dark) DarkText.copy(alpha = 0.72f) else LightText.copy(alpha = 0.64f)
}

private val AccentBlue = Color(0xFF007AFF)
private val AccentBlueDark = Color(0xFF0A84FF)
private val LightBackground = Color(0xFFF2F2F7)
private val LightSurface = Color(0xFFFFFFFF)
private val LightText = Color(0xFF1C1C1E)
private val DarkBackground = Color(0xFF000000)
private val DarkSurface = Color(0xFF1C1C1E)
private val DarkText = Color(0xFFF5F5F7)
