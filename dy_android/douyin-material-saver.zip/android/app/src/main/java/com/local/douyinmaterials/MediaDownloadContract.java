package com.local.douyinmaterials;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

/** Public in-app status contract for {@link MediaDownloadService}. */
public final class MediaDownloadContract {
    public static final String STATUS_PERMISSION =
            "com.local.douyinmaterials.permission.DOWNLOAD_STATUS";
    public static final String ACTION_STATUS =
            "com.local.douyinmaterials.action.MEDIA_DOWNLOAD_STATUS";

    public static final String STATE_STARTED = "started";
    public static final String STATE_ITEM_STARTED = "item_started";
    public static final String STATE_MIRROR_RETRY = "mirror_retry";
    public static final String STATE_PROGRESS = "progress";
    public static final String STATE_ITEM_SUCCEEDED = "item_succeeded";
    public static final String STATE_ITEM_FAILED = "item_failed";
    public static final String STATE_COMPLETED = "completed";
    public static final String STATE_PARTIAL = "partial";
    public static final String STATE_FAILED = "failed";
    public static final String STATE_CANCELLED = "cancelled";

    public static final String EXTRA_STATE = "state";
    public static final String EXTRA_MESSAGE = "message";
    public static final String EXTRA_AWEME_ID = "aweme_id";
    public static final String EXTRA_MEDIA_KIND = "media_kind";
    public static final String EXTRA_ITEM_INDEX = "item_index";
    public static final String EXTRA_COMPLETED = "completed";
    public static final String EXTRA_TOTAL = "total";
    public static final String EXTRA_BYTES = "bytes";
    public static final String EXTRA_CONTENT_LENGTH = "content_length";
    public static final String EXTRA_URI = "uri";
    public static final String EXTRA_SHA256 = "sha256";
    public static final String EXTRA_FILE_NAME = "file_name";
    public static final String EXTRA_MIRROR_INDEX = "mirror_index";
    public static final String EXTRA_MIRROR_COUNT = "mirror_count";

    private MediaDownloadContract() {
    }

    public static IntentFilter intentFilter() {
        return new IntentFilter(ACTION_STATUS);
    }

    /** Convenience receiver; register it as not exported from the Activity. */
    public abstract static class StatusReceiver extends BroadcastReceiver {
        @Override
        public final void onReceive(Context context, Intent intent) {
            if (intent != null && ACTION_STATUS.equals(intent.getAction())) {
                onStatus(Status.from(intent));
            }
        }

        public abstract void onStatus(Status status);
    }

    public static final class Status {
        public final String state;
        public final String message;
        public final String awemeId;
        public final String mediaKind;
        public final int itemIndex;
        public final int completed;
        public final int total;
        public final long bytes;
        public final long contentLength;
        public final String uri;
        public final String sha256;
        public final String fileName;
        public final int mirrorIndex;
        public final int mirrorCount;

        private Status(Intent intent) {
            state = intent.getStringExtra(EXTRA_STATE);
            message = intent.getStringExtra(EXTRA_MESSAGE);
            awemeId = intent.getStringExtra(EXTRA_AWEME_ID);
            mediaKind = intent.getStringExtra(EXTRA_MEDIA_KIND);
            itemIndex = intent.getIntExtra(EXTRA_ITEM_INDEX, -1);
            completed = intent.getIntExtra(EXTRA_COMPLETED, 0);
            total = intent.getIntExtra(EXTRA_TOTAL, 0);
            bytes = intent.getLongExtra(EXTRA_BYTES, 0L);
            contentLength = intent.getLongExtra(EXTRA_CONTENT_LENGTH, -1L);
            uri = intent.getStringExtra(EXTRA_URI);
            sha256 = intent.getStringExtra(EXTRA_SHA256);
            fileName = intent.getStringExtra(EXTRA_FILE_NAME);
            mirrorIndex = intent.getIntExtra(EXTRA_MIRROR_INDEX, -1);
            mirrorCount = intent.getIntExtra(EXTRA_MIRROR_COUNT, 0);
        }

        static Status from(Intent intent) {
            return new Status(intent);
        }
    }
}
