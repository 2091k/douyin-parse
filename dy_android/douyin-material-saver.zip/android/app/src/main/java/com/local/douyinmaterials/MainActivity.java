package com.local.douyinmaterials;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.webkit.WebView;
import android.widget.Toast;

import androidx.compose.ui.platform.ComposeView;
import androidx.activity.ComponentActivity;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONException;

public final class MainActivity extends ComponentActivity implements DouyinInspector.Listener {
    private static final int MAX_SHARED_TEXT_CHARS = 16_384;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 1001;
    private HomeUiState homeUiState;
    private WebView webView;
    private DouyinInspector inspector;
    private MediaStoreDownloader previewDownloader;
    private final ExecutorService previewWorker = Executors.newFixedThreadPool(3);
    private Dialog previewDialog;
    private String pendingPreviewJobId;
    private int previewGeneration;
    private boolean statusReceiverRegistered;
    private final MediaDownloadContract.StatusReceiver statusReceiver =
            new MediaDownloadContract.StatusReceiver() {
                @Override
                public void onStatus(MediaDownloadContract.Status status) {
                    showDownloadStatus(status);
                }
            };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        clearLegacyCaptureFiles();
        buildInterface();
        inspector = new DouyinInspector(this, webView, this);
        previewDownloader = new MediaStoreDownloader(this);
        homeUiState.setStorageText("保存位置：相册 / DCIM / 抖音素材");
        requestNotificationPermissionIfNeeded();
        configureBackNavigation();
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private void buildInterface() {
        homeUiState = new HomeUiState();
        webView = new WebView(this);
        int nightMode = getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK;
        webView.setBackgroundColor(nightMode == Configuration.UI_MODE_NIGHT_YES
                ? Color.rgb(28, 28, 30)
                : Color.WHITE);
        ComposeView composeView = new ComposeView(this);
        AppUiKt.installAppHome(
                composeView,
                homeUiState,
                webView,
                new HomeUiCallbacks() {
                    @Override
                    public void onPasteAndParse() {
                        pasteAndOpenClipboard();
                    }

                    @Override
                    public void onParse(String text) {
                        openText(text);
                    }

                    @Override
                    public void onShowVerification() {
                        homeUiState.showVerification();
                    }

                    @Override
                    public void onHideVerification() {
                        hideVerification();
                    }

                    @Override
                    public void onRetryVerification() {
                        if (inspector != null) {
                            homeUiState.setParsing(true);
                            inspector.reload();
                        }
                    }
                });
        setContentView(composeView);
    }

    private void handleIntent(Intent intent) {
        if (intent == null) {
            return;
        }
        String action = intent.getAction();
        if (!Intent.ACTION_SEND.equals(action) && !Intent.ACTION_PROCESS_TEXT.equals(action)) {
            return;
        }
        CharSequence shared = Intent.ACTION_PROCESS_TEXT.equals(action)
                ? intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)
                : intent.getCharSequenceExtra(Intent.EXTRA_TEXT);
        if (shared == null) {
            ClipData clipData = intent.getClipData();
            if (clipData != null && clipData.getItemCount() > 0) {
                shared = clipData.getItemAt(0).coerceToText(this);
            }
        }
        if (shared == null) {
            onStep("未收到文本；请在抖音点“分享链接”复制后粘贴");
            toast("没有收到链接文本");
            return;
        }
        String text = limitSharedText(shared.toString());
        homeUiState.setInputText(text);
        openText(text);
    }

    private void pasteAndOpenClipboard() {
        ClipboardManager clipboard = getSystemService(ClipboardManager.class);
        ClipData clipData;
        try {
            clipData = clipboard == null ? null : clipboard.getPrimaryClip();
        } catch (SecurityException error) {
            homeUiState.setStepTone(UiTone.ERROR);
            onStep("系统暂时不允许读取剪贴板，请长按输入框手动粘贴");
            toast("无法读取剪贴板");
            return;
        }
        if (clipData == null || clipData.getItemCount() == 0) {
            homeUiState.setStepTone(UiTone.ERROR);
            onStep("剪贴板为空；请先在抖音点“分享链接”复制");
            toast("剪贴板里没有可粘贴的内容");
            return;
        }

        CharSequence clipboardText = clipData.getItemAt(0).coerceToText(this);
        if (clipboardText == null || clipboardText.toString().trim().isEmpty()) {
            homeUiState.setStepTone(UiTone.ERROR);
            onStep("剪贴板没有文本；请重新复制抖音分享链接");
            toast("剪贴板里没有文本");
            return;
        }

        String text = limitSharedText(clipboardText.toString());
        homeUiState.setInputText(text);
        onStep("已粘贴剪贴板内容，正在解析");
        openText(text);
    }

    private void openText(String text) {
        clearPendingPreview();
        homeUiState.beginBackgroundParse();
        text = limitSharedText(text);
        String url = ShareLinkParser.extractDouyinUrl(text);
        if (url == null) {
            homeUiState.setStepTone(UiTone.ERROR);
            onStep("未找到 douyin.com 链接；请在抖音点“分享链接”重新复制");
            toast("没有识别到有效的抖音链接");
            return;
        }
        homeUiState.setStepTone(UiTone.NEUTRAL);
        homeUiState.setPageText("页面路径：" + ShareLinkParser.pathOnly(url));
        homeUiState.setAwemeText("作品 ID：未识别");
        homeUiState.setAwemeTone(UiTone.NEUTRAL);
        homeUiState.setCaptureTone(UiTone.NEUTRAL);
        homeUiState.setCaptureText("媒体信息：尚未解析");
        homeUiState.setDownloadTone(UiTone.NEUTRAL);
        homeUiState.setDownloadText("下载：尚未开始");
        homeUiState.setParsing(true);
        DownloadDiagnostics.reset(this, ShareLinkParser.extractAwemeId(url));
        inspector.start(url);
    }

    @Override
    public void onStep(String step) {
        homeUiState.setStepText("步骤：" + step);
    }

    @Override
    public void onPagePath(String path) {
        homeUiState.setPageText("页面路径：" + path);
    }

    @Override
    public void onAwemeId(String awemeId) {
        homeUiState.setAwemeText("作品 ID：" + awemeId);
        homeUiState.setAwemeTone(UiTone.SUCCESS);
    }

    @Override
    public void onDetailCaptured(String path) {
        homeUiState.setCaptureTone(UiTone.SUCCESS);
        homeUiState.setCaptureText("媒体信息：正在读取最高可用源");
    }

    @Override
    public void onDetailJson(String source, String expectedAwemeId, String rawJson) {
        inspector.suspendAfterSuccess();
        homeUiState.completeVerification();
        try {
            String jobId = DownloadJobStore.enqueueJson(rawJson, expectedAwemeId);
            MediaSelector.WorkPlan plan = DownloadJobStore.peek(jobId);
            DownloadPreview preview = DownloadPreview.from(plan);
            if (preview.assetCount <= 0) {
                DownloadJobStore.discard(jobId);
                throw new IllegalStateException("没有可预览的无明确水印素材");
            }
            homeUiState.setCaptureTone(UiTone.SUCCESS);
            homeUiState.setCaptureText("媒体信息：已从" + source + "选择最高可用源");
            homeUiState.setDownloadTone(UiTone.PRIMARY);
            homeUiState.setDownloadText("下载：等待你确认预览（尚未写入相册）");
            homeUiState.setStorageText("保存位置：相册 / DCIM / 抖音素材");
            showDownloadPreview(jobId, preview);
        } catch (JSONException | RuntimeException exception) {
            homeUiState.setDownloadTone(UiTone.ERROR);
            homeUiState.setDownloadText("创建预览失败：" + exception.getClass().getSimpleName());
            toast("创建下载预览失败");
        }
    }

    private void showDownloadPreview(String jobId, DownloadPreview preview) {
        clearPendingPreview();
        pendingPreviewJobId = jobId;
        int generation = ++previewGeneration;
        AppPreviewState previewState = new AppPreviewState(preview);
        previewDialog = AppUiKt.showAppPreviewDialog(
                this,
                previewState,
                new AppPreviewCallbacks() {
                    @Override
                    public void onSave(Set<Integer> selectedIndexes) {
                        confirmPreview(jobId, preview, selectedIndexes);
                    }

                    @Override
                    public void onCancel() {
                        cancelPreview(jobId);
                    }

                    @Override
                    public void onDismissed() {
                        previewDialog = null;
                    }
                });
        loadPreviewImages(generation, previewState.getItems());
        loadPreviewSizes(generation, previewState.getItems());
    }

    private void confirmPreview(
            String jobId,
            DownloadPreview preview,
            Set<Integer> selectedIndexes) {
        if (!jobId.equals(pendingPreviewJobId)) {
            return;
        }
        if (preview.gallery) {
            if (selectedIndexes.isEmpty()) {
                toast("请至少选择一个图集项目");
                return;
            }
            if (DownloadJobStore.selectGalleryItems(jobId, selectedIndexes)
                    != selectedIndexes.size()) {
                toast("预览任务已失效，请重新解析");
                return;
            }
        }
        pendingPreviewJobId = null;
        previewGeneration++;
        Dialog dialog = previewDialog;
        if (dialog != null) {
            dialog.dismiss();
        }
        MediaDownloadService.start(this, jobId);
        homeUiState.setDownloadTone(UiTone.PRIMARY);
        homeUiState.setDownloadText("下载：已确认，正在保存到系统相册");
        toast("开始保存到系统相册");
    }

    private void cancelPreview(String jobId) {
        if (!jobId.equals(pendingPreviewJobId)) {
            return;
        }
        pendingPreviewJobId = null;
        previewGeneration++;
        DownloadJobStore.discard(jobId);
        homeUiState.setDownloadTone(UiTone.NEUTRAL);
        homeUiState.setDownloadText("下载：已取消（未写入相册）");
        toast("已取消，本次没有保存文件");
    }

    private void clearPendingPreview() {
        String jobId = pendingPreviewJobId;
        pendingPreviewJobId = null;
        previewGeneration++;
        if (previewDialog != null) {
            previewDialog.dismiss();
            previewDialog = null;
        }
        if (jobId != null) {
            DownloadJobStore.discard(jobId);
        }
    }

    private void loadPreviewImages(
            int generation,
            List<AppPreviewItemState> items) {
        for (AppPreviewItemState item : items) {
            String previewUrl = item.getPreviewImageUrl();
            if (previewUrl == null) {
                continue;
            }
            previewWorker.execute(() -> {
                Bitmap bitmap = null;
                try {
                    bitmap = previewDownloader.loadPreviewBitmap(previewUrl, dp(256));
                } catch (IOException | RuntimeException ignored) {
                    // The placeholder and text summary remain usable when a CDN preview fails.
                }
                Bitmap loaded = bitmap;
                runOnUiThread(() -> {
                    if (loaded != null && generation == previewGeneration) {
                        item.setBitmap(loaded);
                    } else if (loaded != null) {
                        loaded.recycle();
                    }
                });
            });
        }
    }

    private void loadPreviewSizes(
            int generation,
            List<AppPreviewItemState> items) {
        for (AppPreviewItemState item : items) {
            for (int assetIndex = 0; assetIndex < item.getAssets().size(); assetIndex++) {
                int resolvedIndex = assetIndex;
                DownloadPreview.Asset asset = item.getAssets().get(assetIndex);
                previewWorker.execute(() -> {
                    long size = -1L;
                    for (String mirror : asset.mirrors) {
                        try {
                            size = previewDownloader.probeRemoteSize(mirror);
                            if (size > 0L) {
                                break;
                            }
                        } catch (IOException | RuntimeException ignored) {
                            // Try the next clean mirror without exposing its signed URL.
                        }
                    }
                    long resolvedSize = size;
                    runOnUiThread(() -> {
                        if (generation != previewGeneration) {
                            return;
                        }
                        item.setAssetSize(resolvedIndex, resolvedSize);
                    });
                });
            }
        }
    }

    @Override
    public void onParseFailure(String message) {
        hideVerification();
        homeUiState.setParsing(false);
        homeUiState.setDownloadTone(UiTone.ERROR);
        homeUiState.setDownloadText("解析失败：" + message);
        DownloadDiagnostics.record(this, "parse_failed", message,
                ShareLinkParser.extractAwemeId(homeUiState.getInputText()), true);
        refreshHistory();
        toast("解析失败，可点“重试解析”");
    }

    @Override
    public void onVerificationRequired(String message) {
        homeUiState.requestVerification(message);
        homeUiState.setStepTone(UiTone.PRIMARY);
        onStep("抖音需要先完成验证，验证后会自动继续解析");
        homeUiState.setDownloadTone(UiTone.PRIMARY);
        homeUiState.setDownloadText("解析：等待完成验证码或登录（尚未写入相册）");
        toast("需要先完成抖音验证");
    }

    private void hideVerification() {
        if (inspector != null) {
            inspector.pauseMedia();
        }
        homeUiState.hideVerification();
    }

    private void showDownloadStatus(MediaDownloadContract.Status status) {
        if (status == null || status.message == null) {
            return;
        }
        String state = status.state;
        boolean failure = MediaDownloadContract.STATE_FAILED.equals(state)
                || MediaDownloadContract.STATE_ITEM_FAILED.equals(state)
                || MediaDownloadContract.STATE_CANCELLED.equals(state);
        boolean finished = MediaDownloadContract.STATE_COMPLETED.equals(state)
                || MediaDownloadContract.STATE_PARTIAL.equals(state);
        homeUiState.setDownloadTone(
                failure ? UiTone.ERROR : finished ? UiTone.SUCCESS : UiTone.PRIMARY);
        homeUiState.setDownloadText("下载：" + status.message);
        if (MediaDownloadContract.STATE_ITEM_SUCCEEDED.equals(state) && status.fileName != null) {
            homeUiState.setStorageText("已保存：" + status.fileName);
        } else if (finished) {
            homeUiState.setStorageText("保存位置：相册 / DCIM / 抖音素材");
            toast(status.message);
        }
        refreshHistory();
    }

    private String limitSharedText(String value) {
        if (value == null) {
            return "";
        }
        return value.length() <= MAX_SHARED_TEXT_CHARS
                ? value
                : value.substring(0, MAX_SHARED_TEXT_CHARS);
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    NOTIFICATION_PERMISSION_REQUEST);
        }
    }

    private void configureBackNavigation() {
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                    () -> {
                        if (homeUiState != null && homeUiState.getVerificationVisible()) {
                            hideVerification();
                        } else if (webView != null && webView.canGoBack()) {
                            webView.goBack();
                        } else {
                            finish();
                        }
                    });
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        refreshHistory();
        if (!statusReceiverRegistered) {
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(
                        statusReceiver,
                        MediaDownloadContract.intentFilter(),
                        Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(
                        statusReceiver,
                        MediaDownloadContract.intentFilter(),
                        MediaDownloadContract.STATUS_PERMISSION,
                        null);
            }
            statusReceiverRegistered = true;
        }
    }

    private void refreshHistory() {
        String summary = DownloadDiagnostics.latestSummary(this);
        if (homeUiState != null) {
            homeUiState.setHistoryText(summary == null ? "上次结果：暂无" : summary);
        }
    }

    private void clearLegacyCaptureFiles() {
        File legacyDirectory = new File(getFilesDir(), "captures");
        File[] files = legacyDirectory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isFile()) {
                    file.delete();
                }
            }
        }
        legacyDirectory.delete();
    }

    @Override
    protected void onStop() {
        if (statusReceiverRegistered) {
            unregisterReceiver(statusReceiver);
            statusReceiverRegistered = false;
        }
        super.onStop();
    }

    @Override
    @SuppressLint("GestureBackNavigation") // API 33+ is handled by OnBackInvokedDispatcher above.
    public void onBackPressed() {
        if (Build.VERSION.SDK_INT >= 33) {
            super.onBackPressed();
            return;
        }
        if (homeUiState != null && homeUiState.getVerificationVisible()) {
            hideVerification();
        } else if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        clearPendingPreview();
        previewWorker.shutdownNow();
        if (inspector != null) {
            inspector.destroy();
        }
        super.onDestroy();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

}
