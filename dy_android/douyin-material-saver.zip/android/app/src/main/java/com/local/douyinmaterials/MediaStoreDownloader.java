package com.local.douyinmaterials;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

/** Streams one logical media item from ordered mirrors directly into pending MediaStore storage. */
final class MediaStoreDownloader {
    private static final String RELATIVE_DIRECTORY = Environment.DIRECTORY_DCIM + "/抖音素材/";
    private static final int CONNECT_TIMEOUT_MS = 12_000;
    private static final int READ_TIMEOUT_MS = 25_000;
    private static final int MAGIC_PREFIX_BYTES = 32;
    private static final int MAX_PREVIEW_IMAGE_BYTES = 12 * 1024 * 1024;
    private static final int MAX_REDIRECTS = 5;
    private static final long MAX_MEDIA_BYTES = 4L * 1024L * 1024L * 1024L;

    enum ExpectedKind {
        STILL,
        VIDEO,
        MOTION
    }

    interface ProgressCallback {
        void onMirrorAttempt(int mirrorIndex, int mirrorCount);

        void onProgress(long bytesWritten, long contentLength);
    }

    static final class Request {
        final List<String> mirrors;
        final String baseName;
        final ExpectedKind expectedKind;

        Request(List<String> mirrors, String baseName, ExpectedKind expectedKind) {
            this.mirrors = cleanMirrors(mirrors);
            this.baseName = sanitizeBaseName(baseName);
            this.expectedKind = expectedKind;
        }

        private static List<String> cleanMirrors(List<String> source) {
            if (source == null) {
                return Collections.emptyList();
            }
            Set<String> unique = new LinkedHashSet<>();
            for (String value : source) {
                if (value == null) {
                    continue;
                }
                String trimmed = value.trim();
                if (!trimmed.isEmpty() && !MediaSelector.isWatermarkedMediaUrl(trimmed)) {
                    unique.add(trimmed);
                }
            }
            return Collections.unmodifiableList(new ArrayList<>(unique));
        }

        private static String sanitizeBaseName(String value) {
            String source = value == null ? "douyin_media" : value;
            String sanitized = source.replaceAll("[^A-Za-z0-9_-]", "_");
            return sanitized.isEmpty() ? "douyin_media" : sanitized;
        }
    }

    static final class Result {
        final Uri uri;
        final String displayName;
        final String mimeType;
        final long bytes;
        final String sha256;
        final int mirrorIndex;

        Result(
                Uri uri,
                String displayName,
                String mimeType,
                long bytes,
                String sha256,
                int mirrorIndex) {
            this.uri = uri;
            this.displayName = displayName;
            this.mimeType = mimeType;
            this.bytes = bytes;
            this.sha256 = sha256;
            this.mirrorIndex = mirrorIndex;
        }
    }

    static final class DownloadFailure extends Exception {
        DownloadFailure(String safeMessage) {
            super(safeMessage);
        }
    }

    private final ContentResolver resolver;
    private final String userAgent;

    MediaStoreDownloader(Context context) {
        resolver = context.getApplicationContext().getContentResolver();
        String systemAgent = System.getProperty("http.agent");
        userAgent = systemAgent == null || systemAgent.trim().isEmpty()
                ? "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Mobile Safari/537.36"
                : systemAgent;
    }

    /** Downloads a bounded, downsampled image for the confirmation UI without writing MediaStore. */
    Bitmap loadPreviewBitmap(String sourceUrl, int targetEdgePx) throws IOException {
        HttpURLConnection connection = null;
        try {
            connection = openFollowingSafeRedirects(sourceUrl);
            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) {
                throw new SafeIOException("预览图片 HTTP " + status);
            }
            long expectedLength = connection.getContentLengthLong();
            if (expectedLength > MAX_PREVIEW_IMAGE_BYTES) {
                throw new SafeIOException("预览图片超过 12 MiB 安全限制");
            }

            byte[] bytes;
            try (InputStream input = connection.getInputStream();
                    ByteArrayOutputStream output = new ByteArrayOutputStream(
                            expectedLength > 0L ? (int) expectedLength : 32 * 1024)) {
                byte[] buffer = new byte[16 * 1024];
                int read;
                int total = 0;
                while ((read = input.read(buffer)) != -1) {
                    total += read;
                    if (total > MAX_PREVIEW_IMAGE_BYTES) {
                        throw new SafeIOException("预览图片超过 12 MiB 安全限制");
                    }
                    output.write(buffer, 0, read);
                }
                bytes = output.toByteArray();
            }

            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
                throw new SafeIOException("预览响应不是可显示图片");
            }
            int target = Math.max(96, targetEdgePx);
            BitmapFactory.Options decode = new BitmapFactory.Options();
            decode.inSampleSize = 1;
            while (Math.max(bounds.outWidth / decode.inSampleSize,
                    bounds.outHeight / decode.inSampleSize) > target * 2) {
                decode.inSampleSize *= 2;
            }
            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, decode);
            if (bitmap == null) {
                throw new SafeIOException("预览图片解码失败");
            }
            return bitmap;
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    /** Reads the remote total length with a one-byte range request and never stores the body. */
    long probeRemoteSize(String sourceUrl) throws IOException {
        HttpURLConnection connection = null;
        try {
            connection = openFollowingSafeRedirects(sourceUrl, true);
            int status = connection.getResponseCode();
            if (status != HttpURLConnection.HTTP_OK
                    && status != HttpURLConnection.HTTP_PARTIAL) {
                throw new SafeIOException("大小探测 HTTP " + status);
            }
            if (status == HttpURLConnection.HTTP_PARTIAL) {
                long rangedTotal = contentRangeTotal(connection.getHeaderField("Content-Range"));
                return rangedTotal > 0L ? rangedTotal : -1L;
            }
            long fullLength = connection.getContentLengthLong();
            return fullLength > 0L ? fullLength : -1L;
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    Result download(
            Request request,
            AtomicBoolean cancelled,
            ProgressCallback callback) throws DownloadFailure {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            throw new DownloadFailure("保存原图需要 Android 10 或更高版本");
        }
        if (request.mirrors.isEmpty()) {
            throw new DownloadFailure("没有可用的无明确水印地址");
        }

        String lastSafeFailure = "未知网络错误";
        for (int index = 0; index < request.mirrors.size(); index++) {
            if (isCancelled(cancelled)) {
                throw new DownloadFailure("下载已取消");
            }
            callback.onMirrorAttempt(index, request.mirrors.size());
            try {
                return downloadOne(request, request.mirrors.get(index), index, cancelled, callback);
            } catch (SafeIOException exception) {
                lastSafeFailure = exception.getMessage();
            } catch (IOException | RuntimeException exception) {
                // Network exceptions can embed the signed URL in their message; expose class only.
                lastSafeFailure = exception.getClass().getSimpleName();
            }
        }
        throw new DownloadFailure("所有 " + request.mirrors.size()
                + " 个镜像均失败；最后错误：" + lastSafeFailure);
    }

    @SuppressLint("NewApi")
    private Result downloadOne(
            Request request,
            String mirror,
            int mirrorIndex,
            AtomicBoolean cancelled,
            ProgressCallback callback) throws IOException {
        HttpURLConnection connection = null;
        Uri pendingUri = null;
        boolean published = false;
        try {
            connection = openFollowingSafeRedirects(mirror);

            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) {
                throw new SafeIOException("HTTP " + status);
            }
            String responseContentType = normalizeContentType(connection.getContentType());
            long expectedLength = connection.getContentLengthLong();
            if (expectedLength == 0L) {
                throw new SafeIOException("响应 Content-Length 为 0");
            }
            if (expectedLength > MAX_MEDIA_BYTES) {
                throw new SafeIOException("媒体文件超过 4 GiB 安全限制");
            }

            try (InputStream input = connection.getInputStream()) {
                byte[] prefix = readPrefix(input, MAGIC_PREFIX_BYTES, cancelled);
                DetectedType detected = DetectedType.fromMagic(prefix);
                if (detected == null) {
                    throw new SafeIOException("响应不是支持的图片或 MP4 文件");
                }
                validateExpectedKind(request.expectedKind, detected);
                validateContentType(responseContentType, detected);

                String displayName = request.baseName + detected.extension;
                pendingUri = createPendingItem(displayName, detected);
                if (pendingUri == null) {
                    throw new SafeIOException("MediaStore 创建失败");
                }

                MessageDigest digest = sha256Digest();
                long written;
                try (OutputStream output = resolver.openOutputStream(pendingUri, "w")) {
                    if (output == null) {
                        throw new FileNotFoundException("MediaStore output unavailable");
                    }
                    output.write(prefix);
                    digest.update(prefix);
                    written = prefix.length;
                    callback.onProgress(written, expectedLength);

                    byte[] buffer = new byte[64 * 1024];
                    int read;
                    while ((read = input.read(buffer)) != -1) {
                        if (isCancelled(cancelled)) {
                            throw new InterruptedIOException("cancelled");
                        }
                        output.write(buffer, 0, read);
                        digest.update(buffer, 0, read);
                        written += read;
                        if (written > MAX_MEDIA_BYTES) {
                            throw new SafeIOException("媒体文件超过 4 GiB 安全限制");
                        }
                        callback.onProgress(written, expectedLength);
                    }
                    output.flush();
                }

                if (expectedLength >= 0L && written != expectedLength) {
                    throw new SafeIOException("Content-Length 校验失败：预期 "
                            + expectedLength + " 字节，实际 " + written + " 字节");
                }
                publish(pendingUri);
                published = true;
                return new Result(
                        pendingUri,
                        displayName,
                        detected.mimeType,
                        written,
                        toHex(digest.digest()),
                        mirrorIndex);
            }
        } finally {
            if (!published && pendingUri != null) {
                try {
                    resolver.delete(pendingUri, null, null);
                } catch (RuntimeException ignored) {
                    // Best effort removal of an incomplete pending row.
                }
            }
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    private byte[] readPrefix(InputStream input, int maximum, AtomicBoolean cancelled)
            throws IOException {
        byte[] buffer = new byte[maximum];
        int total = 0;
        while (total < buffer.length) {
            if (isCancelled(cancelled)) {
                throw new InterruptedIOException("cancelled");
            }
            int read = input.read(buffer, total, buffer.length - total);
            if (read == -1) {
                break;
            }
            total += read;
        }
        byte[] exact = new byte[total];
        System.arraycopy(buffer, 0, exact, 0, total);
        return exact;
    }

    private void validateExpectedKind(ExpectedKind kind, DetectedType detected) throws SafeIOException {
        boolean expectedImage = kind == ExpectedKind.STILL;
        if (expectedImage != detected.image) {
            throw new SafeIOException(expectedImage
                    ? "静态图地址返回的不是图片"
                    : "视频地址返回的不是 MP4");
        }
    }

    private void validateContentType(String contentType, DetectedType detected)
            throws SafeIOException {
        if (contentType.isEmpty()
                || "application/octet-stream".equals(contentType)
                || "binary/octet-stream".equals(contentType)) {
            return;
        }
        boolean matches = detected.mimeType.equals(contentType)
                || (detected == DetectedType.JPEG && "image/jpg".equals(contentType))
                || (detected == DetectedType.HEIC
                && ("image/heif".equals(contentType)
                || "image/heic-sequence".equals(contentType)
                || "image/heif-sequence".equals(contentType)))
                || (detected == DetectedType.MP4 && "application/mp4".equals(contentType));
        if (!matches) {
            throw new SafeIOException("Content-Type 与文件魔数不一致");
        }
    }

    private String normalizeContentType(String contentType) {
        if (contentType == null) {
            return "";
        }
        int separator = contentType.indexOf(';');
        String base = separator < 0 ? contentType : contentType.substring(0, separator);
        return base.trim().toLowerCase(Locale.US);
    }

    @SuppressLint("NewApi")
    private Uri createPendingItem(String displayName, DetectedType detected) {
        Uri collection = detected.image
                ? MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                : MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, displayName);
        values.put(MediaStore.MediaColumns.MIME_TYPE, detected.mimeType);
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, RELATIVE_DIRECTORY);
        values.put(MediaStore.MediaColumns.IS_PENDING, 1);
        return resolver.insert(collection, values);
    }

    private void publish(Uri uri) throws SafeIOException {
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.IS_PENDING, 0);
        if (resolver.update(uri, values, null, null) <= 0) {
            throw new SafeIOException("MediaStore 发布失败");
        }
    }

    private void rejectLocalNetworkTarget(String host) throws IOException {
        if (host == null || host.trim().isEmpty()) {
            throw new SafeIOException("媒体地址缺少主机名");
        }
        for (InetAddress address : InetAddress.getAllByName(host)) {
            byte[] raw = address.getAddress();
            boolean uniqueLocalV6 = raw.length == 16 && (raw[0] & 0xfe) == 0xfc;
            boolean carrierGradeNatV4 = raw.length == 4
                    && (raw[0] & 0xff) == 100
                    && ((raw[1] & 0xff) >= 64 && (raw[1] & 0xff) <= 127);
            if (address.isAnyLocalAddress()
                    || address.isLoopbackAddress()
                    || address.isLinkLocalAddress()
                    || address.isSiteLocalAddress()
                    || address.isMulticastAddress()
                    || uniqueLocalV6
                    || carrierGradeNatV4) {
                throw new SafeIOException("媒体地址指向本地或私有网络");
            }
        }
    }

    private HttpURLConnection openFollowingSafeRedirects(String mirror) throws IOException {
        return openFollowingSafeRedirects(mirror, false);
    }

    private HttpURLConnection openFollowingSafeRedirects(
            String mirror,
            boolean oneByteRange) throws IOException {
        URL current = normalizeHttpsUrl(new URL(mirror));
        for (int redirect = 0; redirect <= MAX_REDIRECTS; redirect++) {
            validateRemoteHttpsUrl(current);
            HttpURLConnection connection = (HttpURLConnection) current.openConnection();
            connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
            connection.setReadTimeout(READ_TIMEOUT_MS);
            connection.setInstanceFollowRedirects(false);
            connection.setUseCaches(false);
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept", "*/*");
            connection.setRequestProperty("Accept-Encoding", "identity");
            connection.setRequestProperty("Referer", "https://www.douyin.com/");
            connection.setRequestProperty("User-Agent", userAgent);
            if (oneByteRange) {
                connection.setRequestProperty("Range", "bytes=0-0");
            }

            int status = connection.getResponseCode();
            if (!isRedirect(status)) {
                return connection;
            }
            String location = connection.getHeaderField("Location");
            connection.disconnect();
            if (location == null || location.trim().isEmpty()) {
                throw new SafeIOException("媒体跳转缺少目标地址");
            }
            if (redirect == MAX_REDIRECTS) {
                throw new SafeIOException("媒体跳转次数超过安全限制");
            }
            current = normalizeHttpsUrl(new URL(current, location));
        }
        throw new SafeIOException("媒体跳转失败");
    }

    private long contentRangeTotal(String contentRange) {
        if (contentRange == null) {
            return -1L;
        }
        int slash = contentRange.lastIndexOf('/');
        if (slash < 0 || slash + 1 >= contentRange.length()) {
            return -1L;
        }
        String total = contentRange.substring(slash + 1).trim();
        if (total.isEmpty() || "*".equals(total)) {
            return -1L;
        }
        try {
            long parsed = Long.parseLong(total);
            return parsed > 0L ? parsed : -1L;
        } catch (NumberFormatException ignored) {
            return -1L;
        }
    }

    private URL normalizeHttpsUrl(URL source) throws IOException {
        if ("http".equalsIgnoreCase(source.getProtocol())) {
            return new URL("https", source.getHost(), -1, source.getFile());
        }
        return source;
    }

    private void validateRemoteHttpsUrl(URL parsed) throws IOException {
        if (!"https".equalsIgnoreCase(parsed.getProtocol())
                || parsed.getUserInfo() != null
                || (parsed.getPort() != -1 && parsed.getPort() != 443)) {
            throw new SafeIOException("媒体地址不是标准 HTTPS 地址");
        }
        rejectLocalNetworkTarget(parsed.getHost());
    }

    private boolean isRedirect(int status) {
        return status == HttpURLConnection.HTTP_MOVED_PERM
                || status == HttpURLConnection.HTTP_MOVED_TEMP
                || status == HttpURLConnection.HTTP_SEE_OTHER
                || status == 307
                || status == 308;
    }

    private MessageDigest sha256Digest() throws SafeIOException {
        try {
            return MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException exception) {
            throw new SafeIOException("设备不支持 SHA-256");
        }
    }

    private static boolean isCancelled(AtomicBoolean cancelled) {
        return cancelled != null && cancelled.get();
    }

    private static String toHex(byte[] value) {
        StringBuilder output = new StringBuilder(value.length * 2);
        for (byte item : value) {
            output.append(String.format(Locale.US, "%02x", item & 0xff));
        }
        return output.toString();
    }

    private static final class SafeIOException extends IOException {
        SafeIOException(String safeMessage) {
            super(safeMessage);
        }
    }

    private enum DetectedType {
        JPEG(".jpg", "image/jpeg", true),
        PNG(".png", "image/png", true),
        WEBP(".webp", "image/webp", true),
        GIF(".gif", "image/gif", true),
        AVIF(".avif", "image/avif", true),
        HEIC(".heic", "image/heic", true),
        MP4(".mp4", "video/mp4", false);

        final String extension;
        final String mimeType;
        final boolean image;

        DetectedType(String extension, String mimeType, boolean image) {
            this.extension = extension;
            this.mimeType = mimeType;
            this.image = image;
        }

        static DetectedType fromMagic(byte[] bytes) {
            if (startsWith(bytes, 0xff, 0xd8, 0xff)) {
                return JPEG;
            }
            if (startsWith(bytes, 0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a)) {
                return PNG;
            }
            if (bytes.length >= 12
                    && asciiAt(bytes, 0, "RIFF")
                    && asciiAt(bytes, 8, "WEBP")) {
                return WEBP;
            }
            if (asciiAt(bytes, 0, "GIF87a") || asciiAt(bytes, 0, "GIF89a")) {
                return GIF;
            }
            if (bytes.length >= 12 && asciiAt(bytes, 4, "ftyp")) {
                if (hasIsoBrand(bytes, "avif") || hasIsoBrand(bytes, "avis")) {
                    return AVIF;
                }
                if (hasIsoBrand(bytes, "heic")
                        || hasIsoBrand(bytes, "heix")
                        || hasIsoBrand(bytes, "hevc")
                        || hasIsoBrand(bytes, "hevx")
                        || hasIsoBrand(bytes, "heim")
                        || hasIsoBrand(bytes, "heis")
                        || hasIsoBrand(bytes, "mif1")
                        || hasIsoBrand(bytes, "msf1")) {
                    return HEIC;
                }
                return MP4;
            }
            return null;
        }

        private static boolean startsWith(byte[] value, int... prefix) {
            if (value.length < prefix.length) {
                return false;
            }
            for (int index = 0; index < prefix.length; index++) {
                if ((value[index] & 0xff) != prefix[index]) {
                    return false;
                }
            }
            return true;
        }

        private static boolean asciiAt(byte[] value, int offset, String expected) {
            if (value.length < offset + expected.length()) {
                return false;
            }
            for (int index = 0; index < expected.length(); index++) {
                if ((char) (value[offset + index] & 0xff) != expected.charAt(index)) {
                    return false;
                }
            }
            return true;
        }

        private static boolean hasIsoBrand(byte[] value, String brand) {
            for (int offset = 8; offset + 4 <= value.length; offset += 4) {
                if (asciiAt(value, offset, brand)) {
                    return true;
                }
            }
            return false;
        }
    }
}
