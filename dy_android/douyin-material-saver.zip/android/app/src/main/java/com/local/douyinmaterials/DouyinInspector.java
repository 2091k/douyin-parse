package com.local.douyinmaterials;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;

final class DouyinInspector {
    private static final String TAG = "DouyinInspector";
    private static final Pattern CHROME_VERSION_PATTERN = Pattern.compile(
            "Chrome/([0-9.]+)", Pattern.CASE_INSENSITIVE);
    private static final int MAX_CAPTURED_REQUESTS_PER_SESSION = 24;
    private static final int MAX_RESPONSE_BYTES = 16 * 1024 * 1024;
    private static final int MAX_PAGE_DETAIL_CHARS = 8 * 1024 * 1024;
    private static final String SILENCE_MEDIA_SCRIPT =
            "(function(){"
                    + "function mute(media){try{media.muted=true;media.volume=0;}catch(e){}}"
                    + "function muteAll(){"
                    + "var items=document.querySelectorAll('audio,video');"
                    + "for(var i=0;i<items.length;i++)mute(items[i]);"
                    + "}"
                    + "muteAll();"
                    + "if(!window.__douyinMaterialSaverMuteInstalled){"
                    + "window.__douyinMaterialSaverMuteInstalled=true;"
                    + "document.addEventListener('play',function(event){"
                    + "var target=event.target;"
                    + "if(target&&(target.tagName==='VIDEO'||target.tagName==='AUDIO'))mute(target);"
                    + "},true);"
                    + "new MutationObserver(muteAll).observe(document.documentElement,"
                    + "{childList:true,subtree:true});"
                    + "}"
                    + "return true;"
                    + "})()";
    private static final String PAUSE_MEDIA_SCRIPT =
            "(function(){"
                    + "var items=document.querySelectorAll('audio,video');"
                    + "for(var i=0;i<items.length;i++){"
                    + "try{items[i].muted=true;items[i].volume=0;items[i].pause();}catch(e){}"
                    + "}"
                    + "return true;"
                    + "})()";
    private static final Pattern CHARSET_PATTERN = Pattern.compile(
            "charset\\s*=\\s*[\\\"']?([^;\\s\\\"']+)",
            Pattern.CASE_INSENSITIVE);

    interface Listener {
        void onStep(String step);

        void onPagePath(String path);

        void onAwemeId(String awemeId);

        void onDetailCaptured(String path);

        void onDetailJson(String source, String expectedAwemeId, String rawJson);

        void onVerificationRequired(String message);

        void onParseFailure(String message);
    }

    private final Context appContext;
    private final WebView webView;
    private final Listener listener;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService ioExecutor = Executors.newSingleThreadExecutor();
    private final CookieManager cookieManager;
    private final Set<String> capturedRequestUrls = ConcurrentHashMap.newKeySet();

    private volatile String currentPageUrl;
    private volatile String currentAwemeId;
    private volatile long sessionGeneration;
    private final AtomicBoolean detailRequestInFlight = new AtomicBoolean(false);
    private final AtomicBoolean successfulDetailDelivered = new AtomicBoolean(false);
    private final AtomicBoolean verificationRequested = new AtomicBoolean(false);
    private volatile CaptureTask lastCaptureTask;
    private String userAgent;

    @SuppressLint({"SetJavaScriptEnabled", "ClickableViewAccessibility"})
    DouyinInspector(Context context, WebView webView, Listener listener) {
        this.appContext = context.getApplicationContext();
        this.webView = webView;
        this.listener = listener;
        this.cookieManager = CookieManager.getInstance();

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        userAgent = desktopUserAgent(settings.getUserAgentString());
        settings.setUserAgentString(userAgent);
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            settings.setSafeBrowsingEnabled(true);
        }
        settings.setGeolocationEnabled(false);

        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, false);
        webView.setOnTouchListener((view, event) -> {
            boolean multiTouch = event.getPointerCount() > 1;
            if (multiTouch) {
                view.getParent().requestDisallowInterceptTouchEvent(true);
            } else if (event.getActionMasked() == android.view.MotionEvent.ACTION_UP
                    || event.getActionMasked() == android.view.MotionEvent.ACTION_CANCEL) {
                view.getParent().requestDisallowInterceptTouchEvent(false);
            }
            return false;
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new InspectingWebViewClient());
    }

    void start(String url) {
        webView.onResume();
        capturedRequestUrls.clear();
        detailRequestInFlight.set(false);
        successfulDetailDelivered.set(false);
        verificationRequested.set(false);
        lastCaptureTask = null;
        currentAwemeId = ShareLinkParser.extractAwemeId(url);
        sessionGeneration++;
        currentPageUrl = url;
        postStep("已提取分享链接，WebView 正在展开短链");
        postPagePath(ShareLinkParser.pathOnly(url));
        webView.loadUrl(url);
    }

    void reload() {
        postStep("正在重载当前页面");
        webView.reload();
    }

    void pauseMedia() {
        evaluateMediaScript(PAUSE_MEDIA_SCRIPT);
    }

    void suspendAfterSuccess() {
        pauseMedia();
        webView.onPause();
    }

    void retryLastNativeFetch() {
        CaptureTask task = lastCaptureTask;
        if (task == null) {
            postParseFailure("尚未捕获详情接口；请重载网页后重试");
            return;
        }
        successfulDetailDelivered.set(false);
        postStep("正在重新读取接口和页面数据");
        ioExecutor.execute(() -> performNativeFetch(task));
        schedulePageDetailProbe(currentPageUrl, currentAwemeId, sessionGeneration, 0L);
    }

    void destroy() {
        ioExecutor.shutdownNow();
        webView.stopLoading();
        webView.setWebViewClient(null);
        webView.setWebChromeClient(null);
        webView.destroy();
    }

    private final class InspectingWebViewClient extends WebViewClient {
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            currentPageUrl = url;
            postPagePath(ShareLinkParser.pathOnly(url));
            detectVerificationPage(url);
            String awemeId = ShareLinkParser.extractAwemeId(url);
            if (awemeId != null) {
                currentAwemeId = awemeId;
                postAwemeId(awemeId);
                if (!detailRequestInFlight.get()) {
                    postStep("短链已展开，正在加载作品页并等待详情接口");
                }
            } else if (!detailRequestInFlight.get()) {
                postStep("WebView 正在跟随页面跳转");
            }
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            currentPageUrl = url;
            postPagePath(ShareLinkParser.pathOnly(url));
            evaluateMediaScript(SILENCE_MEDIA_SCRIPT);
            detectVerificationPage(url);
            String awemeId = ShareLinkParser.extractAwemeId(url);
            if (awemeId != null) {
                currentAwemeId = awemeId;
                postAwemeId(awemeId);
            }
            if (!successfulDetailDelivered.get()) {
                postStep("页面已加载，正在同时读取接口与页面图集数据");
            }
            long generation = sessionGeneration;
            schedulePageDetailProbe(url, awemeId, generation, 0L);
            schedulePageDetailProbe(url, awemeId, generation, 1_500L);
            schedulePageDetailProbe(url, awemeId, generation, 4_000L);
            schedulePageDetailProbe(url, awemeId, generation, 8_000L);
            scheduleParseTimeout(awemeId, generation, 12_000L);
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            if ("GET".equalsIgnoreCase(request.getMethod())
                    && ShareLinkParser.isWebDetailEndpoint(uri)) {
                captureDetailRequest(request);
            }
            return null;
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            if (!request.isForMainFrame()) {
                return false;
            }
            Uri uri = request.getUrl();
            if (ShareLinkParser.isTrustedHttpsDouyinUri(uri)) {
                return false;
            }
            postStep("已阻止作品页跳转到站外地址");
            return true;
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            if (request.isForMainFrame()) {
                postStep("页面加载失败，WebView 错误码 " + error.getErrorCode());
            }
        }

        @Override
        public void onReceivedHttpError(
                WebView view,
                WebResourceRequest request,
                WebResourceResponse errorResponse) {
            if (request.isForMainFrame()) {
                postStep("作品页返回 HTTP " + errorResponse.getStatusCode());
            }
        }
    }

    private void captureDetailRequest(WebResourceRequest request) {
        if (!"GET".equalsIgnoreCase(request.getMethod())
                || !ShareLinkParser.isWebDetailEndpoint(request.getUrl())) {
            return;
        }
        String url = request.getUrl().toString();
        String requestAwemeId = request.getUrl().getQueryParameter("aweme_id");
        String expectedAwemeId = currentAwemeId;
        if (expectedAwemeId == null
                || !expectedAwemeId.equals(requestAwemeId)
                || !detailRequestInFlight.compareAndSet(false, true)
                || capturedRequestUrls.size() >= MAX_CAPTURED_REQUESTS_PER_SESSION
                || !capturedRequestUrls.add(url)) {
            return;
        }

        String path = ShareLinkParser.pathOnly(url);
        // Privacy invariant: logcat contains the path only, never the signed query or cookies.
        Log.i(TAG, "Captured detail request path=" + path);

        Map<String, String> headers = request.getRequestHeaders() == null
                ? Collections.emptyMap()
                : new LinkedHashMap<>(request.getRequestHeaders());
        String cookie = null;
        try {
            cookie = cookieManager.getCookie(url);
        } catch (RuntimeException exception) {
            Log.w(TAG, "Cookie snapshot failed (" + exception.getClass().getSimpleName() + ")");
        }
        DetailCapture capture = new DetailCapture(url, request.getMethod(), headers, cookie);
        postStep("已捕获详情接口，正在原生复取 JSON");
        postPagePath(path);
        if (capture.awemeId != null) {
            postAwemeId(capture.awemeId);
        }

        CaptureTask task = new CaptureTask(capture);
        lastCaptureTask = task;
        mainHandler.post(() -> listener.onDetailCaptured(path));
        ioExecutor.execute(() -> performNativeFetch(task));
    }

    private void performNativeFetch(CaptureTask task) {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(task.capture.url).openConnection();
            connection.setRequestMethod("GET");
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(10_000);
            connection.setReadTimeout(18_000);
            connection.setUseCaches(false);
            connection.setRequestProperty("Accept-Encoding", "identity");
            replayHeaders(connection, task.capture.headers);
            if (!containsHeader(task.capture.headers, "User-Agent") && userAgent != null) {
                connection.setRequestProperty("User-Agent", userAgent);
            }
            if (task.capture.cookie != null && !task.capture.cookie.isEmpty()) {
                connection.setRequestProperty("Cookie", task.capture.cookie);
            }

            int statusCode = connection.getResponseCode();
            String contentType = connection.getContentType();
            String contentEncoding = connection.getContentEncoding();
            String responseBody = readResponseBody(connection, statusCode, contentEncoding, contentType);
            String responseAwemeId = ShareLinkParser.extractAwemeId(responseBody);
            if (responseAwemeId != null) {
                postAwemeId(responseAwemeId);
            }
            boolean json = isJson(responseBody);
            boolean success = statusCode >= 200 && statusCode < 300
                    && isExpectedDetailJson(responseBody, task.capture.awemeId);
            if (success) {
                deliverDetailJson("详情接口", task.capture.awemeId, responseBody);
            } else if (json && isFilteredDetailJson(responseBody)) {
                postStep("详情接口过滤了图集，正在改从作品页面读取");
            } else if (!json) {
                postStep("详情接口未返回 JSON，正在改从作品页面读取");
            } else {
                postStep("详情接口未返回当前作品，正在改从作品页面读取");
            }
        } catch (Exception exception) {
            Log.w(TAG, "Native detail fetch failed (" + exception.getClass().getSimpleName() + ")");
            postStep("接口读取失败，正在改从作品页面读取");
        } finally {
            detailRequestInFlight.set(false);
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    private void replayHeaders(HttpURLConnection connection, Map<String, String> headers) {
        for (Map.Entry<String, String> entry : headers.entrySet()) {
            String name = entry.getKey();
            String value = entry.getValue();
            if (name == null || value == null || !isAllowedReplayHeader(name)) {
                continue;
            }
            try {
                connection.setRequestProperty(name, value);
            } catch (IllegalArgumentException ignored) {
                // WebView may expose a transport-managed header that HttpURLConnection rejects.
            }
        }
    }

    private boolean isAllowedReplayHeader(String name) {
        return name.equalsIgnoreCase("Accept")
                || name.equalsIgnoreCase("Accept-Language")
                || name.equalsIgnoreCase("Referer")
                || name.equalsIgnoreCase("User-Agent")
                || name.equalsIgnoreCase("sec-ch-ua")
                || name.equalsIgnoreCase("sec-ch-ua-mobile")
                || name.equalsIgnoreCase("sec-ch-ua-platform")
                || name.equalsIgnoreCase("uifid");
    }

    private boolean containsHeader(Map<String, String> headers, String wanted) {
        for (String name : headers.keySet()) {
            if (name != null && name.equalsIgnoreCase(wanted)) {
                return true;
            }
        }
        return false;
    }

    private String readResponseBody(
            HttpURLConnection connection,
            int statusCode,
            String contentEncoding,
            String contentType) throws IOException {
        InputStream stream = statusCode >= 400 ? connection.getErrorStream() : connection.getInputStream();
        if (stream == null) {
            return "";
        }
        if ("gzip".equalsIgnoreCase(contentEncoding)) {
            stream = new GZIPInputStream(stream);
        }
        try (InputStream input = stream; ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[16 * 1024];
            int total = 0;
            int read;
            while ((read = input.read(buffer)) != -1) {
                total += read;
                if (total > MAX_RESPONSE_BYTES) {
                    throw new IOException("Response exceeded local safety limit");
                }
                output.write(buffer, 0, read);
            }
            return new String(output.toByteArray(), findCharset(contentType));
        }
    }

    private Charset findCharset(String contentType) {
        if (contentType != null) {
            Matcher matcher = CHARSET_PATTERN.matcher(contentType);
            if (matcher.find()) {
                try {
                    return Charset.forName(matcher.group(1));
                } catch (RuntimeException ignored) {
                    // UTF-8 is the correct fallback for the JSON endpoint.
                }
            }
        }
        return StandardCharsets.UTF_8;
    }

    private boolean isJson(String responseBody) {
        String trimmed = responseBody == null ? "" : responseBody.trim();
        if (trimmed.isEmpty()) {
            return false;
        }
        try {
            if (trimmed.charAt(0) == '{') {
                new JSONObject(trimmed);
                return true;
            }
            if (trimmed.charAt(0) == '[') {
                new JSONArray(trimmed);
                return true;
            }
        } catch (JSONException ignored) {
            return false;
        }
        return false;
    }

    private boolean isExpectedDetailJson(String responseBody, String expectedAwemeId) {
        try {
            JSONObject root = new JSONObject(responseBody);
            int statusCode = root.has("status_code")
                    ? root.optInt("status_code", -1)
                    : root.optInt("statusCode", 0);
            if (statusCode != 0) {
                return false;
            }
            JSONObject detail = root.optJSONObject("aweme_detail");
            if (detail == null) {
                detail = root.optJSONObject("awemeDetail");
            }
            if (detail == null) {
                return false;
            }
            String actualAwemeId = detail.optString(
                    "aweme_id",
                    detail.optString("awemeId", ""));
            return expectedAwemeId == null || expectedAwemeId.equals(actualAwemeId);
        } catch (JSONException exception) {
            return false;
        }
    }

    private boolean isFilteredDetailJson(String responseBody) {
        try {
            JSONObject root = new JSONObject(responseBody);
            return root.optInt("status_code", -1) == 0
                    && root.isNull("aweme_detail")
                    && root.optJSONObject("filter_detail") != null;
        } catch (JSONException exception) {
            return false;
        }
    }

    private void schedulePageDetailProbe(
            String pageUrl,
            String awemeId,
            long generation,
            long delayMs) {
        if (awemeId == null || !ShareLinkParser.isTrustedHttpsDouyinUri(Uri.parse(pageUrl))) {
            return;
        }
        mainHandler.postDelayed(() -> {
            if (generation != sessionGeneration
                    || successfulDetailDelivered.get()
                    || !awemeId.equals(currentAwemeId)
                    || !pageUrl.equals(currentPageUrl)) {
                return;
            }
            String script = buildPageDetailProbeScript(awemeId);
            webView.evaluateJavascript(script, encodedResult ->
                    acceptPageDetailResult(awemeId, generation, encodedResult));
        }, delayMs);
    }

    private String buildPageDetailProbeScript(String awemeId) {
        String quotedId = JSONObject.quote(awemeId);
        return "(function(){"
                + "var wanted=" + quotedId + ",seen=0,max=120000;"
                + "function find(v,d){"
                + "if(!v||d>25||seen++>max)return null;"
                + "if(typeof v==='string'){"
                + "if(v.indexOf(wanted)<0||v.length>" + MAX_PAGE_DETAIL_CHARS + ")return null;"
                + "var q=v.trim(),colon=q.indexOf(':');"
                + "if(colon>0&&/^\\d+$/.test(q.slice(0,colon)))q=q.slice(colon+1);"
                + "try{return find(JSON.parse(q),d+1);}catch(e){}"
                + "try{var decoded=decodeURIComponent(q);"
                + "if(decoded!==q)return find(JSON.parse(decoded),d+1);}catch(e){}"
                + "return null;}"
                + "if(typeof v!=='object')return null;"
                + "try{if(String(v.aweme_id||v.awemeId||'')===wanted"
                + "&&(v.video||v.images||v.image_list||v.imageList"
                + "||v.image_post_info||v.imagePostInfo))return v;}catch(e){}"
                + "if(Array.isArray(v)){for(var i=0;i<v.length;i++){var a=find(v[i],d+1);if(a)return a;}"
                + "return null;}"
                + "var p=['aweme_detail','awemeDetail','aweme','detail','aweme_list','awemeList',"
                + "'item_list','itemList','itemInfo','item','data','loaderData'];"
                + "for(var j=0;j<p.length;j++){if(Object.prototype.hasOwnProperty.call(v,p[j])){"
                + "var b=find(v[p[j]],d+1);if(b)return b;}}"
                + "var keys=Object.keys(v);for(var k=0;k<keys.length;k++){"
                + "if(p.indexOf(keys[k])>=0)continue;var c=find(v[keys[k]],d+1);if(c)return c;}"
                + "return null;}"
                + "var roots=[window.__pace_f,window._ROUTER_DATA,window.__INITIAL_STATE__,"
                + "window.__NEXT_DATA__,window.SSR_RENDER_DATA,window.EXPOSE_DATA];"
                + "for(var r=0;r<roots.length;r++){seen=0;var hit=find(roots[r],0);"
                + "if(hit)return JSON.stringify({aweme_detail:hit});}"
                + "var scripts=document.scripts||[];"
                + "for(var s=0;s<scripts.length;s++){var t=scripts[s].textContent||'';"
                + "if(t.indexOf(wanted)<0||t.length>" + MAX_PAGE_DETAIL_CHARS + ")continue;"
                + "try{var trimmed=t.trim(),marker='__pace_f.push(',markerAt=trimmed.indexOf(marker),parsed;"
                + "if(markerAt>=0&&markerAt<16){var open=markerAt+marker.length-1,close=trimmed.lastIndexOf(')');"
                + "if(close<=open)continue;parsed=JSON.parse(trimmed.slice(open+1,close));}"
                + "else{if(scripts[s].id==='RENDER_DATA')trimmed=decodeURIComponent(trimmed);"
                + "parsed=JSON.parse(trimmed);}"
                + "seen=0;var fromScript=find(parsed,0);"
                + "if(fromScript)return JSON.stringify({aweme_detail:fromScript});}catch(e){}}"
                + "return '';})()";
    }

    private void acceptPageDetailResult(String awemeId, long generation, String encodedResult) {
        if (generation != sessionGeneration
                || successfulDetailDelivered.get()
                || encodedResult == null
                || encodedResult.length() > MAX_PAGE_DETAIL_CHARS) {
            return;
        }
        try {
            Object decoded = new JSONTokener(encodedResult).nextValue();
            if (!(decoded instanceof String)) {
                return;
            }
            String rawJson = (String) decoded;
            if (rawJson.isEmpty() || !isExpectedDetailJson(rawJson, awemeId)) {
                return;
            }
            deliverDetailJson("作品页面", awemeId, rawJson);
        } catch (JSONException exception) {
            Log.w(TAG, "Page detail decode failed");
        }
    }

    private void scheduleParseTimeout(String awemeId, long generation, long delayMs) {
        if (awemeId == null) {
            return;
        }
        mainHandler.postDelayed(() -> {
            if (generation == sessionGeneration
                    && awemeId.equals(currentAwemeId)
                    && !successfulDetailDelivered.get()) {
                postVerificationRequired(
                        "未能读取当前作品。请完成页面中的验证码或登录，完成后会自动继续解析");
            }
        }, delayMs);
    }

    private void deliverDetailJson(String source, String awemeId, String rawJson) {
        if (!successfulDetailDelivered.compareAndSet(false, true)) {
            return;
        }
        postAwemeId(awemeId);
        postStep("已从" + source + "读取当前作品媒体信息");
        mainHandler.post(() -> listener.onDetailJson(source, awemeId, rawJson));
    }

    private void detectVerificationPage(String url) {
        if (url == null || successfulDetailDelivered.get()) {
            return;
        }
        String normalized = url.toLowerCase(Locale.US);
        if (normalized.contains("captcha")
                || normalized.contains("verify")
                || normalized.contains("/login")
                || normalized.contains("passport")) {
            postVerificationRequired(
                    "请在抖音页面完成验证码或登录，完成后会自动继续解析");
        }
    }

    private String desktopUserAgent(String defaultUserAgent) {
        String chromeVersion = "150.0.0.0";
        if (defaultUserAgent != null) {
            Matcher matcher = CHROME_VERSION_PATTERN.matcher(defaultUserAgent);
            if (matcher.find()) {
                chromeVersion = matcher.group(1);
            }
        }
        return "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                + "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/"
                + chromeVersion + " Safari/537.36";
    }


    private void postStep(String step) {
        mainHandler.post(() -> listener.onStep(step));
    }

    private void postPagePath(String path) {
        mainHandler.post(() -> listener.onPagePath(path));
    }

    private void postAwemeId(String awemeId) {
        mainHandler.post(() -> listener.onAwemeId(awemeId));
    }

    private void postParseFailure(String message) {
        mainHandler.post(() -> listener.onParseFailure(message));
    }

    private void postVerificationRequired(String message) {
        if (verificationRequested.compareAndSet(false, true)) {
            mainHandler.post(() -> listener.onVerificationRequired(message));
        }
    }

    private void evaluateMediaScript(String script) {
        try {
            webView.evaluateJavascript(script, null);
        } catch (RuntimeException exception) {
            Log.w(TAG, "Unable to control WebView media");
        }
    }

    private static final class CaptureTask {
        final DetailCapture capture;

        CaptureTask(DetailCapture capture) {
            this.capture = capture;
        }
    }
}
