# The diagnostic build intentionally keeps JavaScript bridge entry points.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
