plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val releaseStoreFile = providers.environmentVariable("DOUYIN_RELEASE_STORE_FILE").orNull
val releaseStorePassword = providers.environmentVariable("DOUYIN_RELEASE_STORE_PASSWORD").orNull
val releaseKeyAlias = providers.environmentVariable("DOUYIN_RELEASE_KEY_ALIAS").orNull
val releaseKeyPassword = providers.environmentVariable("DOUYIN_RELEASE_KEY_PASSWORD").orNull
val releaseSigningValues = listOf(
    releaseStoreFile,
    releaseStorePassword,
    releaseKeyAlias,
    releaseKeyPassword,
)

if (releaseSigningValues.any { !it.isNullOrBlank() } && releaseSigningValues.any { it.isNullOrBlank() }) {
    error("Release signing is only partially configured. Set all DOUYIN_RELEASE_* environment variables.")
}

android {
    namespace = "com.local.douyinmaterials"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.local.douyinmaterials"
        minSdk = 29
        targetSdk = 36
        versionCode = 13
        versionName = "1.1.1"
    }

    signingConfigs {
        if (releaseSigningValues.all { !it.isNullOrBlank() }) {
            create("release") {
                storeFile = file(releaseStoreFile!!)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.findByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2026.06.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)
    implementation("androidx.activity:activity-compose:1.13.0")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
}

// Kotlin/Compose adds a Kotlin test output directory even though this project keeps its
// business tests in Java. AGP 8.13 can then omit the Java test classes from the worker
// classpath, so keep that output explicit for the existing JUnit suite.
tasks.withType<Test>().configureEach {
    classpath += files(
        layout.buildDirectory.dir(
            "intermediates/javac/debugUnitTest/compileDebugUnitTestJavaWithJavac/classes"
        )
    )
}

tasks.withType<JavaCompile>().configureEach {
    options.encoding = "UTF-8"
}
