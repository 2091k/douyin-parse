# 抖音素材保存（Android）

[![Android CI](https://github.com/LeoChen-Tech/douyin-material-saver/actions/workflows/android-ci.yml/badge.svg)](https://github.com/LeoChen-Tech/douyin-material-saver/actions/workflows/android-ci.yml)
[![Android 10+](https://img.shields.io/badge/Android-10%2B-3DDC84?logo=android&logoColor=white)](android/)
[![License: GPL v3](https://img.shields.io/badge/License-GPLv3-blue.svg)](LICENSE)

一个完全在 Android 手机上运行的本地工具：粘贴抖音分享链接，预览并选择平台公开页面当前提供的最高可用媒体源，再保存到系统相册。不需要电脑常开、局域网服务或第三方上传站点。

[下载最新正式版 APK](https://github.com/LeoChen-Tech/douyin-material-saver/releases/latest) · [查看更新日志](CHANGELOG.md)

> [!IMPORTANT]
> 本项目是独立开发的非官方开源工具，与抖音、字节跳动及其关联公司不存在隶属、授权、认可或合作关系。“抖音”名称及相关商标归其权利人所有。请仅保存和使用你有权处理的内容，并自行遵守适用的法律法规与平台规则。

## 界面

<img src="docs/images/app-home.jpg" alt="抖音素材保存首页" width="360">

截图中没有使用真实作品链接或账号数据。

## 主要功能

- 支持普通视频、图集，以及“静态图 + 动态 MP4”形式的实况素材。
- 从抖音公开页面候选中选择最高分辨率、较高码率且无明确平台水印标记的媒体源，不转码。
- 保存前显示标题、作者、素材类型、缩略图、预计大小和文件数量。
- 图集支持逐项选择；实况静态图和动态视频保持成组选择。
- 解析 WebView 默认在后台运行，仅在抖音要求验证码或登录时显示验证入口。
- 验证页面音视频自动静音和暂停，支持深色模式及系统“减少动态效果”设置。
- 文件通过格式、大小和完整性检查后写入 `DCIM/抖音素材`。
- 不申请读取整个相册的权限，只创建用户确认下载的新媒体。

## 安装与使用

系统要求：Android 10（API 29）或更高版本。

1. 从 [GitHub Releases](https://github.com/LeoChen-Tech/douyin-material-saver/releases/latest) 下载最新版 APK，并核对发布页列出的 SHA-256。
2. 在 Android 系统提示时，允许当前文件管理器或浏览器安装未知来源应用。
3. 在抖音作品页依次点击“分享 → 分享链接”。
4. 打开“抖音素材保存”，点击“粘贴并解析”。
5. 在下载预览中核对素材并选择需要的项目。
6. 点击“保存到相册”，然后在相册或 `DCIM/抖音素材` 查看结果。

“粘贴并解析”只在用户点击时读取一次剪贴板，不在后台监听。也可以手动输入分享文案或 `douyin.com` 链接。

## 隐私与安全

- 应用没有广告、分析 SDK、遥测或开发者控制的中转服务器。
- 解析和下载会由手机直接连接抖音网页及其内容分发网络。
- 验证 Cookie、登录状态、网页存储和缓存可能保留在手机的系统 WebView 中。
- 签名媒体地址、请求头和 Cookie 不会写入应用日志或诊断摘要。
- 最近一次任务只保留经过截断和隐藏网址后的本机诊断摘要。

完整说明见[隐私说明](PRIVACY.md)。安全漏洞请通过 [GitHub 私密漏洞报告](https://github.com/LeoChen-Tech/douyin-material-saver/security/advisories/new)提交，不要在公开 Issue 中披露 Cookie、Token、验证码或签名网址。

## 能力边界

“最高可用源”是平台公开页面当前提供的最佳候选，不等同于作者上传前的母文件，也无法恢复平台已移除的 EXIF、HDR 或更高码率数据。应用不能去除作者已经烧录进画面的文字或标记，也不会绕过账号安全、访问控制、付费限制或平台保护机制。

平台网页结构变化、网络环境、账号验证状态或地区差异都可能影响解析结果。

## 从源码构建

需要 JDK 17 和 Android SDK 36。仓库已包含 Gradle 8.13 Wrapper，无需另外安装 Gradle。

Windows PowerShell：

```powershell
cd android
.\gradlew.bat --no-daemon :app:testDebugUnitTest :app:lintDebug :app:assembleDebug
```

macOS 或 Linux：

```bash
cd android
./gradlew --no-daemon :app:testDebugUnitTest :app:lintDebug :app:assembleDebug
```

Debug APK 输出到 `android/app/build/outputs/apk/debug/app-debug.apk`。正式签名构建方式见 [Android 正式签名说明](android/RELEASE_SIGNING.md)；不要提交签名密钥、密码或本机 `local.properties`。

## 参与项目

欢迎提交 Issue 和 Pull Request。开始前请阅读：

- [贡献指南](CONTRIBUTING.md)
- [安全政策](SECURITY.md)
- [社区行为准则](CODE_OF_CONDUCT.md)
- [更新日志](CHANGELOG.md)
- [第三方组件声明](THIRD_PARTY_NOTICES.md)

## 许可证

Copyright (C) 2026 LeoChen

本项目依据 [GNU General Public License v3.0](LICENSE)（`GPL-3.0-only`）发布。
