## 改动说明

请简要说明本 Pull Request 解决的问题和主要改动。

## 验证

请列出实际运行的测试、Lint、构建或真机检查。

## 检查清单

- [ ] 本 Pull Request 只处理一个清晰的问题。
- [ ] 已运行 `:app:testDebugUnitTest`、`:app:lintDebug` 和 `:app:assembleDebug`。
- [ ] 业务逻辑修改已补充或更新测试，或已说明不需要测试的原因。
- [ ] 未提交构建输出、签名密钥、密码、`local.properties` 或本机绝对路径。
- [ ] 未提交 Cookie、验证码、Token、完整作品链接、带签名的媒体网址或个人数据。
- [ ] 新增依赖已说明用途和许可证兼容性。
- [ ] 我有权提交这些代码和素材，并同意按 GPL-3.0-only 发布贡献。
