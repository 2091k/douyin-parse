# 第三方组件声明

本项目使用或在开发、测试过程中引用以下第三方组件。各组件仍受其原始许可证和版权声明约束；本项目的 GPL-3.0-only 许可证不会替代这些第三方许可证。

## 随正式 APK 分发的组件

以下组件及其传递依赖主要依据 Apache License 2.0 发布：

- AndroidX Activity、Core、Lifecycle、SavedState、Window、Profile Installer 等 AndroidX 组件；
- Jetpack Compose Runtime、UI、Foundation、Material 3、Animation 等组件；
- Kotlin 标准库；
- Kotlinx Coroutines 和 Serialization；
- JetBrains Annotations；
- JSpecify；
- Guava ListenableFuture。

正式 APK 内包含 `assets/third_party_licenses.txt`，其中列出组件家族并附有完整 Apache License 2.0 文本。

相关项目：

- [AndroidX 与 Jetpack Compose](https://source.android.com/docs/setup/about/licenses)
- [Kotlin](https://github.com/JetBrains/kotlin)
- [Kotlinx Coroutines](https://github.com/Kotlin/kotlinx.coroutines)
- [Kotlinx Serialization](https://github.com/Kotlin/kotlinx.serialization)
- [JetBrains Annotations](https://github.com/JetBrains/java-annotations)
- [JSpecify](https://github.com/jspecify/jspecify)
- [Guava](https://github.com/google/guava)

## 构建和测试组件

以下组件只用于构建或测试，不会作为应用业务代码打入正式 APK：

- Gradle Wrapper 与 Gradle：Apache License 2.0；
- Android Gradle Plugin：Apache License 2.0；
- JUnit 4.13.2：Eclipse Public License 1.0；
- JSON-java `org.json:json:20240303`：Public Domain。

相关项目：

- [Gradle](https://github.com/gradle/gradle)
- [Android Gradle Plugin](https://android.googlesource.com/platform/tools/base/)
- [JUnit 4](https://github.com/junit-team/junit4)
- [JSON-java](https://github.com/stleary/JSON-java)

## 完整依赖

Gradle 会解析传递依赖。可在 `android/` 目录运行以下命令查看当前正式运行时依赖树：

```powershell
.\gradlew.bat --no-daemon :app:dependencies --configuration releaseRuntimeClasspath
```

增加或升级依赖时，请同步检查并更新本文件及 APK 内的第三方许可证文本。
