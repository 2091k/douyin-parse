# 贡献指南

感谢你愿意帮助改进“抖音素材保存”。提交内容前，请先阅读本指南、[安全政策](SECURITY.md)和[隐私说明](PRIVACY.md)。

## 报告问题

- 普通 Bug 和功能建议请使用对应的 GitHub Issue 模板。
- 安全漏洞请使用 [GitHub 私密漏洞报告](https://github.com/LeoChen-Tech/douyin-material-saver/security/advisories/new)，不要创建公开 Issue。
- 请勿提交 Cookie、验证码、Token、完整分享文本、带签名查询参数的媒体网址、账号信息或完整作品 JSON。
- 如需提供日志或截图，请先移除个人信息和敏感请求数据。

## 开发环境

需要：

- JDK 17；
- Android SDK 36；
- Windows、macOS 或 Linux。

仓库已包含 Gradle Wrapper，无需单独安装 Gradle。进入 `android/` 后运行：

Windows PowerShell：

```powershell
.\gradlew.bat --no-daemon :app:testDebugUnitTest :app:lintDebug :app:assembleDebug
```

macOS 或 Linux：

```bash
./gradlew --no-daemon :app:testDebugUnitTest :app:lintDebug :app:assembleDebug
```

## 修改流程

1. 从最新 `main` 创建独立分支。
2. 每个 Pull Request 只处理一个清晰的问题。
3. 为业务逻辑修改补充或更新测试。
4. 在提交前运行单元测试、Lint 和 Debug 构建。
5. 在 Pull Request 中说明改动目的、验证方式和仍存在的限制。

不要提交构建输出、`local.properties`、下载内容、签名密钥、密码文件或本机工具路径。

## Android 真机测试

- 不要使用 `adb shell input text` 注入抖音网址；该命令可能静默丢失 `:`、`/`、`.` 等字符。
- 测试分享文本时，请使用 `ACTION_SEND`，或者在专门测试剪贴板流程时使用剪贴板。
- 开始解析前，应读取 UI 层级并确认界面中的原始网址完整无误。
- 仅测试解析和预览时，不要点击“保存到相册”；只有明确进行真实保存测试时才写入相册。
- 提交真机结果前，请移除作品链接、Cookie、账号信息、设备序列号及其他个人数据。

## 代码和授权

- 保持现有 Java、Kotlin 和资源文件的风格，避免与当前修改无关的大规模格式化。
- 新依赖必须说明用途，并使用与 GPL-3.0-only 兼容的许可证。
- 提交 Pull Request 即表示你有权提交相关代码和素材，并同意按本项目的 GPL-3.0-only 许可证发布该贡献。
